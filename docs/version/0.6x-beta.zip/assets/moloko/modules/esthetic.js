var Gi = Object.defineProperty;
var Vi = (e, s) => {
  for (var n in s)
    Gi(e, n, { get: s[n], enumerable: !0 });
};

// src/lexical/chars.ts
var p = "", Ce = '"', ze = ",", ve = "'", Y = " ";
var Z = `
`, oi = `\r
`;

// src/rules/language.ts
function Ze(e) {
  switch (e) {
    case "text":
      return "Plain Text";
    case "html":
      return "HTML";
    case "liquid":
      return "Liquid";
    case "xml":
      return "XML";
    case "json":
      return "JSON";
    case "jsx":
      return "JSX";
    case "tsx":
      return "TSX";
    case "typescript":
      return "TypeScript";
    case "javascript":
      return "JavaScript";
    case "less":
      return "LESS";
    case "scss":
      return "SCSS";
    case "sass":
      return "SASS";
    case "css":
      return "CSS";
  }
}
function Pe(e) {
  switch (e) {
    case "text":
      return "ignore";
    case "auto":
      return "auto";
    case "markup":
    case "html":
    case "liquid":
    case "xml":
      return "markup";
    case "json":
    case "jsx":
    case "tsx":
    case "typescript":
    case "javascript":
      return "script";
    case "less":
    case "scss":
    case "sass":
    case "css":
      return "style";
  }
}
function ht(e) {
  switch (e) {
    case "auto":
      return 5;
    case "markup":
    case "html":
    case "liquid":
    case "xml":
      return 1;
    case "json":
    case "jsx":
    case "tsx":
    case "typescript":
    case "javascript":
      return 2;
    case "less":
    case "scss":
    case "sass":
    case "css":
      return 3;
  }
  return 4;
}

// src/utils/helpers.ts
function Dt(e, s) {
  let n = {
    lexer: s,
    language: Ze(e),
    chars: 0,
    time: ""
  }, c = Date.now();
  return (O) => {
    let l = +(Date.now() - c).toFixed(0);
    return n.time = l > 1e3 ? `${l}s` : `${l}ms`, n.chars = O, n;
  };
}
function Ot(...e) {
  return e.join(Z);
}
function Xe(e, s = Y) {
  if (e <= 0)
    return s;
  let n = p, c = 1;
  do
    n += s;
  while (c++ < e);
  return n;
}
function i(e, s) {
  return e ? e.charCodeAt(0) === s : !1;
}
function $e(e, s) {
  return i(e[e.length - 1], s);
}
function ai(e, ...s) {
  let n = e.length - 1, c = s.length;
  for (; c--; )
    if (i(e[n--], s[c]) === !1)
      return !1;
  return !0;
}
function Je(e, s, n = 2) {
  return i(e[e.length - n], s);
}
function $(e, s) {
  return i(e, s) === !1;
}
function Qt(e, s) {
  return $e(e, s) === !1;
}
function le(e) {
  return /\s/.test(e);
}
function Ee(e) {
  return /\d/.test(e);
}
function Ft(e) {
  return `\\${e}`;
}
var { toString: it } = Object.prototype;
function nt(e) {
  return (s) => s in e;
}
function Re(e) {
  return it.call(e).slice(8, -1) === "Array";
}
function gt(e) {
  return it.call(e).slice(8, -1) === "Object";
}
function mt(e) {
  return it.call(e).slice(8, -1) === "String";
}
function Ke(e) {
  return it.call(e).slice(8, -1) === "Boolean";
}
function st(e) {
  return it.call(e).slice(8, -1) === "Number";
}
function De(e) {
  return it.call(e).slice(8, -1) === "Undefined";
}

// src/parse/sorting.ts
function bt(e) {
  let s = r.count, n = r.stack.index, c = 0, O = 0, l = 0, N = 0, o = 0, d = 0, b = 0, t = !0, { count: f } = r, W = r.stack.token, R = r.stack.index, u = r.lineOffset, h = e.lexer[f] === "style", w = h && W === "global", x = h ? [";", "separator"] : [",", "separator"], ae = [], z = {
    begin: [],
    ender: [],
    lexer: [],
    lines: [],
    stack: [],
    token: [],
    types: []
  };
  function a(C, F) {
    let B = C[0], G = F[0];
    if (e.types[B] === "comment") {
      do
        B = B + 1;
      while (B < f && e.types[B] === "comment");
      if (e.token[B] === void 0)
        return 1;
    }
    if (e.types[G] === "comment") {
      do
        G = G + 1;
      while (G < f && e.types[G] === "comment");
      if (e.token[G] === void 0)
        return 1;
    }
    if (h === !0) {
      if (e.token[B].indexOf("@import") === 0 || e.token[G].indexOf("@import") === 0)
        return B < G ? -1 : 1;
      if (e.types[B] !== e.types[G]) {
        if (e.types[B] === "function")
          return 1;
        if (e.types[B] === "variable")
          return -1;
        if (e.types[B] === "selector")
          return 1;
        if (e.types[B] === "property" && e.types[G] !== "variable" || e.types[B] === "mixin" && e.types[G] !== "property" && e.types[G] !== "variable")
          return -1;
      }
    }
    return e.token[B].toLowerCase() > e.token[G].toLowerCase() ? 1 : -1;
  }
  N = s;
  do {
    if (e.begin[s] === n || w && s < N && i(e.token[s], 125) && e.begin[e.begin[s]] === -1) {
      if (e.types[s].indexOf("liquid") > -1)
        return;
      if (e.token[s] === x[0] || h === !0 && i(e.token[s], 125) && $(e.token[s + 1], 59) ? (t = !0, o = s + 1) : h === !0 && i(e.token[s - 1], 125) && (t = !0, o = s), o === 0 && e.types[0] === "comment")
        do
          o = o + 1;
        while (e.types[o] === "comment");
      else
        e.types[o] === "comment" && e.lines[o] < 2 && (o = o + 1);
      t === !0 && (e.token[s] === x[0] || h === !0 && i(e.token[s - 1], 125)) && o <= N && ((h === !0 && "};".indexOf(e.token[N]) < 0 || h === !1 && $(e.token[N], 44)) && (N = N + 1), ae.push([o, N]), h === !0 && i(e.token[o], 125) ? N = o : N = o - 1);
    }
    s = s - 1;
  } while (s > n);
  if (ae.length > 0 && ae[ae.length - 1][0] > s + 1) {
    if (c = ae[ae.length - 1][0] - 1, e.types[c] === "comment" && e.lines[c] > 1) {
      do
        c = c - 1;
      while (c > 0 && e.types[c] === "comment");
      ae[ae.length - 1][0] = c + 1;
    }
    if (e.types[s + 1] === "comment" && s === -1)
      do
        s = s + 1;
      while (e.types[s + 1] === "comment");
    ae.push([s + 1, c]);
  }
  if (ae.length > 1 && (h === !0 || r.language === "json" || i(e.token[s - 1], 61) || i(e.token[s - 1], 58) || i(e.token[s - 1], 40) || i(e.token[s - 1], 91) || i(e.token[s - 1], 44) || e.types[s - 1] === "word" || s === 0)) {
    ae.sort(a), b = ae.length, t = !1, n = 0;
    do {
      if (d = ae[n][1], h === !0 && (l = d, e.types[l] === "comment" && (l = l - 1), i(e.token[l], 125) ? (d = d + 1, x[0] = "}", x[1] = "end") : (x[0] = ";", x[1] = "separator")), c = ae[n][0], h === !0 && e.types[d - 1] !== "end" && e.types[d] === "comment" && e.types[d + 1] !== "comment" && n < b - 1 && (d = d + 1), c < d)
        do
          h === !1 && n === b - 1 && c === d - 2 && i(e.token[c], 44) && e.lexer[c] === "script" && e.types[c + 1] === "comment" || r.push(z, {
            begin: e.begin[c],
            ender: e.begin[c],
            lexer: e.lexer[c],
            lines: e.lines[c],
            stack: e.stack[c],
            token: e.token[c],
            types: e.types[c]
          }, p), O = O + 1, e.token[c] === x[0] && (h === !0 || e.begin[c] === e.begin[ae[n][0]]) ? t = !0 : e.token[c] !== x[0] && e.types[c] !== "comment" && (t = !1), c = c + 1;
        while (c < d);
      if (t === !1 && z.token[z.token.length - 1] !== "x;" && (h === !0 || n < b - 1)) {
        if (c = z.types.length - 1, z.types[c] === "comment")
          do
            c = c - 1;
          while (c > 0 && z.types[c] === "comment");
        c = c + 1, r.splice({
          data: z,
          howmany: 0,
          index: c,
          record: {
            begin: R,
            stack: w ? "global" : W,
            ender: r.count,
            lexer: z.lexer[c - 1],
            lines: 0,
            token: x[0],
            types: x[1]
          }
        }), O = O + 1;
      }
      n = n + 1;
    } while (n < b);
    r.splice({ data: e, howmany: O, index: s + 1 }), r.lineOffset = u, r.concat(e, z);
  }
}
function Ht(e, s, n) {
  return Re(e) === !1 ? e : s === "normal" ? pi.call({ array: e, recursive: n }, e) : s === "descend" ? ci.call({ recursive: n }, e) : fi.call({ recursive: n }, e);
}
function vt(e, s) {
  let n = e, c = -1, { data: O } = r, l = [], N = r.stack.length < 2 ? [-1] : [r.stack[r.stack.length - 2][1]];
  do
    n > 0 && O.types[n].indexOf("attribute") > -1 && O.types[n].indexOf("end") < 0 && O.types[n - 1].indexOf("start") < 0 && O.types[n - 1].indexOf("attribute") < 0 && O.lexer[n] === "markup" && N.push(n - 1), n > 0 && O.types[n - 1].indexOf("attribute") > -1 && O.types[n].indexOf("attribute") < 0 && O.lexer[N[N.length - 1]] === "markup" && O.types[N[N.length - 1]].indexOf("start") < 0 && N.pop(), O.begin[n] !== N[N.length - 1] && (O.begin[n] = N.length > 0 ? N[N.length - 1] : -1), O.types[n].indexOf("else") > -1 && (N.length > 0 ? N[N.length - 1] = n : N.push(n)), O.types[n].indexOf("end") > -1 && N.pop(), O.types[n].indexOf("start") > -1 && N.push(n), n = n + 1;
  while (n < s);
  n = s;
  do
    n = n - 1, O.types[n].indexOf("end") > -1 && (l.push(n), c = c + 1), O.ender[n] = c > -1 ? l[c] : -1, O.types[n].indexOf("start") > -1 && (l.pop(), c = c - 1);
  while (n > e);
}
function fi(e) {
  let s = 0, n = e.length, c = e, O = c.map((o) => o[1]), l = () => {
    let o = 0, d = c.length;
    if (o < d)
      do
        Re(c[o]) === !0 && (c[o] = fi.apply(this, c[o])), o = o + 1;
      while (o < d);
  }, N = (o = p) => {
    let d = s, b = 0, t = 0, f = 0, W = [], R = c[s];
    if (d < n)
      do
        c[d] < R ? (R = c[d], W = [d]) : c[d] === R && W.push(d), d = d + 1;
      while (d < n);
    if (t = W.length, d = s, b = t + s, d < b)
      do
        R[1] = O[d], c[W[f]] = c[d], c[d] = R, f = f + 1, d = d + 1;
      while (d < b);
    return s = s + t, s < n ? N() : (this.recursive === !0 && l(), e = c), o;
  };
  return N(), e;
}
function ci(e) {
  let s = 0, n = e.length, c = e, O = () => {
    let N = c.length, o = 0;
    if (o < N)
      do
        Re(c[o]) && (c[o] = ci.apply(this, c[o])), o = o + 1;
      while (o < N);
  }, l = (N = "") => {
    let o = s, d = 0, b = 0, t = 0, f = c[s], W = [], R = p, u = typeof f;
    if (o < n)
      do
        R = typeof c[o], c[o] > f || R > u ? (f = c[o], W = [o]) : c[o] === f && W.push(o), o = o + 1;
      while (o < n);
    if (b = W.length, o = s, d = b + s, o < d)
      do
        c[W[t]] = c[o], c[o] = f, t = t + 1, o = o + 1;
      while (o < d);
    return s = s + b, s < n ? l() : (this.recursive === !0 && O(), e = c), N;
  };
  return l(), e;
}
function pi(e) {
  let s = e, n = [e[0]], c = () => {
    let l = 0, N = s.length;
    if (l < N)
      do
        Re(s[l]) && (s[l] = pi.apply(this, s[l])), l = l + 1;
      while (l < N);
  }, O = (l) => {
    let N = 0, o = [], d = s.length;
    if (N < d)
      do
        s[N] !== l && o.push(s[N]), N = N + 1;
      while (N < d);
    s = o, o.length > 0 ? (n.push(o[0]), O(o[0])) : (this.recursive === !0 && c(), e = s);
  };
  return O(this.array[0]), e;
}

// src/parse/grammar.ts
function Ji(e = {
  embedded: {
    schema: [
      {
        language: "json"
      }
    ],
    style: [
      {
        language: "css"
      }
    ],
    stylesheet: [
      {
        language: "css"
      },
      {
        language: "scss",
        argument: /['"]scss['"]/
      }
    ],
    javascript: [
      {
        language: "javascript"
      }
    ]
  },
  tags: [
    "form",
    "paginate",
    "capture",
    "case",
    "comment",
    "for",
    "if",
    "raw",
    "tablerow",
    "unless",
    "schema",
    "style",
    "script",
    "stylesheet",
    "javascript"
  ],
  control: [
    "if",
    "unless",
    "case"
  ],
  else: [
    "else",
    "elsif",
    "when"
  ],
  singletons: [
    "include",
    "layout",
    "section",
    "assign",
    "liquid",
    "break",
    "continue",
    "cycle",
    "decrement",
    "echo",
    "increment",
    "render"
  ]
}) {
  let s = new Set(e.else), n = new Set(e.control), c = new Set(e.tags), O = new Set(e.singletons), l = {};
  return N(e.embedded), {
    get grammar() {
      return e;
    },
    get tags() {
      return c;
    },
    get control() {
      return n;
    },
    get else() {
      return s;
    },
    get singleton() {
      return O;
    },
    get embed() {
      return l;
    },
    extend(o) {
      for (let d in o)
        if (Re(o[d]))
          for (let b of o[d])
            d === "tags" && c.has(b) === !1 ? (e.tags.push(b), c.add(b)) : d === "else" && s.has(b) === !1 ? (e.else.push(b), s.add(b)) : d === "control" && n.has(b) ? (e.control.push(b), n.add(b)) : d === "singletons" && O.has(b) === !1 && (e.singletons.push(b), O.add(b));
        else
          d === "embedded" && typeof o[d] == "object" && N(o[d]);
    }
  };
  function N(o) {
    for (let d in o)
      for (let { language: b, argument: t = null } of o[d])
        if (d in l || (l[d] = {
          tag: d,
          language: b,
          args: /* @__PURE__ */ new Map([[/* @__PURE__ */ new Set(), { tag: d, language: b }]])
        }), t) {
          for (let [f] of l[d].args)
            if (f !== null)
              if (Re(t))
                for (let W of t)
                  f.has(W) || f.add(W);
              else {
                let W = new RegExp(t);
                if (f.size > 0)
                  for (let R of f)
                    R instanceof RegExp && R.source !== W.source && f.add(W);
                else
                  f.add(W);
              }
        }
  }
}
function Ui(e = {
  tags: [
    "a",
    "altGlyph",
    "altGlyphDef",
    "altGlyphItem",
    "animate",
    "animateColor",
    "animateMotion",
    "animateTransform",
    "circle",
    "clipPath",
    "color-profile",
    "cursor",
    "defs",
    "desc",
    "ellipse",
    "feBlend",
    "feColorMatrix",
    "feComponentTransfer",
    "feComposite",
    "feConvolveMatrix",
    "feDiffuseLighting",
    "feDisplacementMap",
    "feDistantLight",
    "feFlood",
    "feFuncA",
    "feFuncB",
    "feFuncG",
    "feFuncR",
    "feGaussianBlur",
    "feImage",
    "feMerge",
    "feMergeNode",
    "feMorphology",
    "feOffset",
    "fePointLight",
    "feSpecularLighting",
    "feSpotLight",
    "feTile",
    "feTurbulence",
    "filter",
    "font",
    "font-face",
    "font-face-format",
    "font-face-name",
    "font-face-src",
    "font-face-uri",
    "foreignObject",
    "g",
    "glyph",
    "glyphRef",
    "hkern",
    "image",
    "line",
    "linearGradient",
    "marker",
    "mask",
    "metadata",
    "missing-glyph",
    "mpath",
    "path",
    "pattern",
    "polygon",
    "polyline",
    "radialGradient",
    "rect",
    // 'script',
    "set",
    "stop",
    //  'style',
    "switch",
    "symbol",
    "text",
    "textPath",
    "title",
    "tref",
    "tspan",
    "use",
    "view",
    "vkern"
  ]
}) {
  let s = new Set(e.tags);
  return {
    get grammar() {
      return e;
    },
    get tags() {
      return s;
    },
    extend(n) {
      for (let c in n)
        if (Re(n[c]))
          for (let O of n[c])
            c === "tags" && s.has(O) === !1 && (e.tags.push(O), s.add(O));
    }
  };
}
function Zi(e = {
  embedded: {
    script: [
      {
        language: "javascript"
      },
      {
        language: "json",
        attribute: {
          type: [
            "application/json",
            "application/ld+json"
          ]
        }
      },
      {
        language: "jsx",
        attribute: {
          type: [
            "text/jsx",
            "application/jsx"
          ]
        }
      }
    ],
    style: [
      {
        language: "css"
      }
    ]
  },
  voids: [
    "area",
    "base",
    "br",
    "col",
    "command",
    "embed",
    "hr",
    "img",
    "input",
    "keygen",
    "link",
    "menuitem",
    "meta",
    "param",
    "source",
    "track",
    "wbr"
  ],
  tags: [
    "a",
    "abbr",
    "acronym",
    "address",
    "applet",
    "article",
    "aside",
    "audio",
    "b",
    "basefont",
    "bdi",
    "bdo",
    "big",
    "blockquote",
    "body",
    "button",
    "canvas",
    "caption",
    "center",
    "cite",
    "code",
    "colgroup",
    "data",
    "datalist",
    "dd",
    "del",
    "details",
    "dfn",
    "dialog",
    "dir",
    "div",
    "dl",
    "dt",
    "em",
    "fieldset",
    "figcaption",
    "figure",
    "figure",
    "font",
    "footer",
    "form",
    "frame",
    "frameset",
    "h1",
    "h6",
    "head",
    "header",
    "html",
    "i",
    "iframe",
    "ins",
    "isindex",
    "kbd",
    "label",
    "legend",
    "fieldset",
    "li",
    "main",
    "map",
    "mark",
    "marquee",
    "menu",
    "meter",
    "nav",
    "noframes",
    "frame",
    "noscript",
    "object",
    "ol",
    "optgroup",
    "option",
    "output",
    "p",
    "object",
    "picture",
    "pre",
    "progress",
    "q",
    "rp",
    "rt",
    "ruby",
    "s",
    "samp",
    "script",
    "section",
    "select",
    "small",
    "picture",
    "video",
    "audio",
    "span",
    "strike",
    "strong",
    "style",
    "sub",
    "summary",
    "details",
    "sup",
    "svg",
    "table",
    "tbody",
    "td",
    "template",
    "textarea",
    "tfoot",
    "th",
    "thead",
    "time",
    "title",
    "tr",
    "audio",
    "video",
    "tt",
    "u",
    "ul",
    "var",
    "video"
  ]
}) {
  let s = new Set(e.tags), n = new Set(e.voids), c = {};
  return O(e.embedded), {
    get grammar() {
      return e;
    },
    get tags() {
      return s;
    },
    get voids() {
      return n;
    },
    get embed() {
      return c;
    },
    extend(l) {
      for (let N in l)
        if (Re(l[N]))
          for (let o of l[N])
            N === "tags" && s.has(o) === !1 ? (e.tags.push(o), s.add(o)) : N === "voids" && n.has(o) === !1 && (e.voids.push(o), n.add(o));
        else
          N === "embedded" && typeof l[N] == "object" && O(l[N]);
    }
  };
  function O(l) {
    for (let N in l) {
      N in c || (c[N] = { tag: N, attr: /* @__PURE__ */ new Map() });
      for (let { language: o, attribute: d } of l[N])
        if ("language" in c[N] || (c[N].language = o), c[N].attr.has(o) || c[N].attr.set(o, { tag: N, language: o, attr: /* @__PURE__ */ new Map() }), d) {
          let b = c[N].attr.get(o);
          for (let t in d) {
            b.attr.has(t) || b.attr.set(t, {
              tag: N,
              language: o,
              attr: t,
              value: /* @__PURE__ */ new Set()
            });
            let f = c[N].attr.get(o).attr.get(t);
            if (Re(d[t]))
              for (let W of d[t])
                f.value.has(W) || f.value.add(W);
            else {
              let W = new RegExp(d[t]);
              if (f.value.size > 0)
                for (let R of f.value)
                  R instanceof RegExp && R.source !== W.source && f.value.add(W);
              else
                f.value.add(W);
            }
          }
        }
    }
  }
}
function Xi(e = {
  units: [
    "%",
    "cap",
    "ch",
    "cm",
    "deg",
    "dpcm",
    "dpi",
    "dppx",
    "em",
    "ex",
    "fr",
    "grad",
    "Hz",
    "ic",
    "in",
    "kHz",
    "lh",
    "mm",
    "ms",
    "mS",
    "pc",
    "pt",
    "px",
    "Q",
    "rad",
    "rem",
    "rlh",
    "s",
    "turn",
    "vb",
    "vh",
    "vi",
    "vmax",
    "vmin",
    "vw"
  ],
  atrules: [
    "@charset",
    "@color-profile",
    "@counter-style",
    "@font-face",
    "@font-feature-values",
    "@font-palette-values",
    "@import",
    "@keyframes",
    "@layer",
    "@media",
    "@namespace",
    "@page",
    "@supports"
  ],
  webkit: {
    classes: [
      "webkit-any",
      "webkit-any-link*",
      "webkit-autofill"
    ],
    elements: [
      "webkit-file-upload-button",
      "webkit-inner-spin-button",
      "webkit-input-placeholder",
      "webkit-meter-bar",
      "webkit-meter-even-less-good-value",
      "webkit-meter-inner-element",
      "webkit-meter-optimum-value",
      "webkit-meter-suboptimum-value",
      "webkit-outer-spin-button",
      "webkit-progress-bar",
      "webkit-progress-inner-element",
      "webkit-progress-value",
      "webkit-search-cancel-button",
      "webkit-search-results-button",
      "webkit-slider-runnable-track",
      "webkit-slider-thumb"
    ]
  },
  pseudo: {
    classes: [
      "active",
      "any-link",
      "checked",
      "default",
      "defined",
      "disabled",
      "empty",
      "enabled",
      "first",
      "first-child",
      "first-of-type",
      "fullscreen",
      "focus",
      "focus-visible",
      "focus-within",
      "host",
      "hover",
      "indeterminate",
      "in-range",
      "invalid",
      "is",
      "lang",
      "last-child",
      "last-of-type",
      "left",
      "link",
      "modal",
      "not",
      "nth-child",
      "nth-col",
      "nth-last-child",
      "nth-last-of-type",
      "nth-of-type",
      "only-child",
      "only-of-type",
      "optional",
      "out-of-range",
      "picture-in-picture",
      "placeholder-shown",
      "paused",
      "playing",
      "read-only",
      "read-write",
      "required",
      "right",
      "root",
      "scope",
      "target",
      "valid",
      "visited",
      "where"
    ],
    elements: [
      "after",
      "backdrop",
      "before",
      "cue",
      "cue-region",
      "first-letter",
      "first-line",
      "file-selector-button",
      "marker",
      "part",
      "placeholder",
      "selection",
      "slotted"
    ],
    functions: [
      "after",
      "before",
      "first-letter",
      "first-line",
      "host",
      "host-context",
      "part",
      "slotted",
      "lang",
      "not",
      "nth-child",
      "nth-col",
      "nth-last-child",
      "nth-last-of-type",
      "nth-of-type",
      "where"
    ]
  }
}) {
  let s = new Set(e.units), n = new Set(e.atrules), c = new Set(e.pseudo.classes), O = new Set(e.pseudo.elements), l = new Set(e.pseudo.functions), N = new Set(e.webkit.elements), o = new Set(e.webkit.classes);
  return {
    get grammar() {
      return e;
    },
    get units() {
      return s;
    },
    get pseudoClasses() {
      return c;
    },
    get pseudoElements() {
      return O;
    },
    get pseudoFunctions() {
      return l;
    },
    get webkitElements() {
      return N;
    },
    get webkitClasses() {
      return o;
    },
    atrules(d) {
      return n.has(d.slice(0, d.indexOf("(")).trim());
    },
    extend(d) {
      for (let b in d) {
        if (Re(d[b]))
          for (let t of d[b])
            b === "units" && !s.has(t) ? (e[b].push(t), s.add(t)) : b === "atrules" && !n.has(t) && (e[b].push(t), n.add(t));
        if (typeof d[b] == "object") {
          for (let t in d[b])
            if (Re(d[b][t]))
              for (let f of d[b][t])
                b === "webkit" ? t === "elements" ? (e[b][t].push(f), N.add(f)) : t === "classes" && (e[b][t].push(f), o.add(f)) : b === "pseudo" && (t === "elements" ? (e[b][t].push(f), O.add(f)) : t === "classes" ? (e[b][t].push(f), c.add(f)) : t === "functions" && (e[b][t].push(f), l.add(f)));
        }
      }
    }
  };
}
function Ki(e = {
  keywords: [
    "ActiveXObject",
    "ArrayBuffer",
    "AudioContext",
    "Canvas",
    "CustomAnimation",
    "DOMParser",
    "DataView",
    "Date",
    "Error",
    "EvalError",
    "FadeAnimation",
    "FileReader",
    "Flash",
    "Float32Array",
    "Float64Array",
    "FormField",
    "Frame",
    "Generator",
    "HotKey",
    "Image",
    "Iterator",
    "Intl",
    "Int16Array",
    "Int32Array",
    "Int8Array",
    "InternalError",
    "Loader",
    "Map",
    "MenuItem",
    "MoveAnimation",
    "Notification",
    "ParallelArray",
    "Point",
    "Promise",
    "Proxy",
    "RangeError",
    "Rectangle",
    "ReferenceError",
    "Reflect",
    "RegExp",
    "ResizeAnimation",
    "RotateAnimation",
    "Set",
    "SQLite",
    "ScrollBar",
    "Set",
    "Shadow",
    "StopIteration",
    "Symbol",
    "SyntaxError",
    "Text",
    "TextArea",
    "Timer",
    "TypeError",
    "URL",
    "Uint16Array",
    "Uint32Array",
    "Uint8Array",
    "Uint8ClampedArray",
    "URIError",
    "WeakMap",
    "WeakSet",
    "Web",
    "Window",
    "XMLHttpRequest"
  ]
}) {
  let s = new Set(e.keywords);
  return {
    get grammar() {
      return e;
    },
    get keywords() {
      return s;
    },
    extend(n) {
      for (let c in n)
        if (Re(n[c]))
          for (let O of n[c])
            c === "keywords" && !s.has(O) && (e[c].push(O), s.add(O));
    }
  };
}
var ye = function() {
  let e = Xi(), s = Ji(), n = Ki(), c = Zi(), O = Ui();
  return {
    html: c,
    liquid: s,
    js: n,
    css: e,
    svg: O,
    /**
     * Extend Grammars
     */
    extend(l) {
      if (typeof l == "object")
        for (let N in l)
          N === "liquid" ? s.extend(l.liquid) : N === "html" ? c.extend(l.html) : N === "css" ? e.extend(l.css) : (N === "js" || N === "svg") && n.extend(l.js);
      return {
        get html() {
          return c.grammar;
        },
        get liquid() {
          return s.grammar;
        },
        get js() {
          return n.grammar;
        },
        get css() {
          return e.grammar;
        },
        get svg() {
          return e.grammar;
        }
      };
    }
  };
}();

// src/lexical/lexing.ts
function _e(e, s = NaN, n) {
  if (mt(e) === !1)
    return p;
  if ($(e, 60) && $(e, 123))
    return n || e;
  if (i(e, 60)) {
    let l = e.search(/[\s>]/), N = e.slice(i(e[1], 47) ? 2 : 1, l);
    return i(N, 63) && $e(N, 63) ? "xml" : isNaN(s) ? N : N.slice(s);
  }
  let O = (i(e[2], 45) ? e.slice(3).trimStart() : e.slice(2).trimStart()).split(/\s|-?[%}]}/).shift();
  return isNaN(s) ? O : O.slice(s);
}
function zt(e) {
  return (s, n, c) => {
    let O = e, l = e;
    return i(c[n - 1], 92) && (O = s[0]), i(s[s.length - 2], 92) && (l = s[s.length - 1]), O + s.slice(1, -1) + l;
  };
}

// src/config.ts
var Ne = {
  // @ts-ignore
  version: "0.5.6-beta.1",
  env: typeof process != "undefined" && process.versions != null ? "node" : "browser",
  lastUpdate: (/* @__PURE__ */ new Date()).toDateString(),
  cwd: null,
  reportStats: !0,
  editorConfig: !1,
  throwErrors: !0,
  globalThis: !0,
  persistRules: !0,
  logLevel: 2,
  logColors: !0,
  resolveConfig: "package.json"
};

// src/parse/errors.ts
function Ye(e, s, n) {
  n || (n = _e(s));
  let c = mi(e, n, r.lineNumber);
  c.language = Ze(r.language), r.error = Ot(
    c.message,
    Z,
    en(),
    Z,
    c.details,
    Z,
    `Language: ${Ze(r.language)} `,
    `Location: ${r.lineNumber}:${r.lineColumn}`,
    `\xC6sthetic: Parse Failed (Code: ${c})`
  );
}
function Rt(e, s, n) {
  n || (n = _e(s.token));
  let c = mi(e, n, s.line);
  c.language = Ze(r.language), r.error = Ot(
    c.message,
    Z,
    Yi(s),
    Z,
    c.details,
    Z,
    Oe(`Language: ${Ze(r.language)}`),
    Oe(`Location: ${s.line}`),
    Oe(`\xC6sthetic: Parse Failed (Code: ${e})`)
  );
}
function Ae(e) {
  return Ot(
    `Rule Error: ${e.message}`,
    Z,
    `Definition: ${e.option}`,
    `Provided: ${e.provided} `,
    `Expected: ${e.expected.join(", ")} `
  );
}
var hi = (e) => `\x1B[93m${"^".repeat(e)}\x1B[39m`;
function Yi(e) {
  let s = e.line - r.get(e.index).lines, n = 0, c = "", O = r.source.split(Z).slice(s, e.line), l = `${e.line + 1}`.length, N = [], { indentSize: o, indentChar: d } = r.rules;
  do {
    let b = `${s + 1}`, t = l - b.length > 0 ? ` \x1B[90m${b} |` : `\x1B[90m${b} |`;
    if (c = O[n], n === 0) {
      if (De(O[n])) {
        N.push(`${t} \x1B[31m${e.token}\x1B[39m`);
        break;
      }
      c = O[n].trimStart(), N.push(`${t} \x1B[31m${c}\x1B[39m`);
    } else {
      let f = c.match(/^\s*/);
      f !== null && f[0].length > o ? (c = d.repeat(o) + c.trimStart(), N.push(`${t} \x1B[31m${c}\x1B[39m`)) : N.push(`${t} \x1B[31m${c}\x1B[39m`);
    }
    n = n + 1, s = s + 1;
  } while (n < O.length);
  return N.join(Z);
}
function en(e = r.lineNumber) {
  let s = [], n = r.source.split(Z), c = e, O = `${c + 1}`.length, l = c - 1, N = "";
  n.length > 2 && (l = c - 3), n.length === 2 && (l = c - 2);
  do {
    let o = `${l + 1}`, d = O - o.length > 0 ? ` \x1B[90m${o} |` : `\x1B[90m${o} |`, b = n[l].trim();
    if (l > c)
      break;
    if (!b) {
      s.push(`${d} \x1B[90m${b || "\u2424"}`), l = l + 1;
      continue;
    }
    l === c - 1 ? b.length === 0 ? s.push(`${" ".repeat(O + 2)} ${hi(N.length)}`) : (s.push(`${d} \x1B[31m${b}\x1B[39m`), s.push(`${" ".repeat(O + 2)} ${hi(b.length)}`)) : s.push(`${d} \x1B[90m${b || "\u2424"}`), l = l + 1, N = b;
  } while (l < c);
  return s.join(Z);
}
function Oe(...e) {
  return Ne.logColors ? `${e.join(Z)}`.replace(/"(.*?)"/g, "\x1B[31m$1\x1B[39m") : e.join(Z);
}
function mi(e, s, n = r.lineNumber) {
  return {
    [105]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Missing HTML "${s}" end tag`),
      details: Oe(
        `The "<${s}>" tag type has an incomplete HTML syntactic structure resulting in a parse error.`,
        `To resolve the issue check that you have a closing "</${s}>" tag. For more information`,
        "see: https://www.w3.org/TR/html5/syntax.html#closing-elements-that-have-implied-end-tags"
      )
    },
    [112]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Missing Liquid "end${s}" tag`),
      details: Oe(
        `The Liquid "${s}" is a tag block type which requires an end tag be provided.`,
        "For more information, see: https://shopify.dev/api/liquid/tags"
      )
    },
    [104]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Missing HTML start "${s}" tag`),
      details: Oe(
        "There is an incorrect placement or an incomplete structure resulting in a parse error.",
        `To resolve the issue, you may need to provide a start \`<${s}>\` tag type or correct the placement. `
      )
    },
    [110]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Missing Liquid start "${s}" tag`),
      details: Oe(
        "The Liquid tag has incorrect placement or an incomplete structure resulting in a parse error.",
        "To resolve the issue, you may need to provide a start tag type or correct the placement. "
      )
    },
    [111]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Missing Close Delimiter "%}" or "}}" on liquid tag`),
      details: Oe(
        "The Liquid tag is missing its closing delimiter resulting in malformed syntax."
      )
    },
    [106]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Missing HTML ">" delimiter on end tag`),
      details: Oe(
        "The HTML tag is missing its closing delimiter resulting in malformed syntax.",
        'You can have Esthetic autofix syntax errors like this by setting the markup rule "correct" to true.'
      )
    },
    [107]: {
      code: e,
      message: Oe(`Illegal Syntax (line ${n}): Invalid HTML Comment Attribute`),
      details: Oe(
        "HTML comments are not allowed inside tags, start or end, at all.",
        "To resolve the issue, remove the comment or place it above the tag.",
        "For more information see: https://html.spec.whatwg.org/multipage/syntax.html#start-tags"
      )
    },
    [103]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Invalid quotation character`),
      details: Oe(
        `Bad quotation character (\u201C, &#x201c) provided. Only single ' or double "`,
        "quotations characters are valid in HTML (markup) languages. For more information see:",
        "https://html.spec.whatwg.org/multipage/parsing.html#attribute-value-(double-quoted)-state"
      )
    },
    [108]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Invalid CDATA Termination Sequence`),
      details: Oe(
        "The CDATA bracket state sequence provided is invalid resulting in a parse error.",
        "For more information see: https://html.spec.whatwg.org/multipage/parsing.html#cdata-section-bracket-state"
      )
    },
    [114]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Invalid character sequence in "${s}" token`),
      details: Oe(
        "An invalid sequence of characters defined"
      )
    },
    [101]: {
      code: e,
      message: Oe(`Syntax Error (line ${n}): Unterminated String`),
      details: Oe(
        "There is an unterminated string sequence resulting in a parse error."
      )
    }
  }[e];
}

// src/lexical/regex.ts
var kt = /\S/, rt = /^\s+$/;
var et = /\s+/g, ot = /^\s+/, Te = /\s+$/, lt = /^[\t\v\f\r \u00a0\u2000-\u200b\u2028-\u2029\u3000]+/, Gt = /[\t\v\f \u00a0\u2000-\u200b\u2028-\u2029\u3000]+$/, bi = /[\t\v\r \u00a0\u2000-\u200b\u2028-\u2029\u3000]+/g;
var Vt = /^\n+/;
var ki = /({%-?\s*(?:comment\s*-?%}|#)|<!-{2})\s*esthetic-ignore-(start|next|end)\b/;
var at = /(\/[*/]|{%-?\s*(?:comment\s*-?%}|#)|<!-{2})\s*esthetic-ignore-start\b/, qt = /^\/\/\s*esthetic-ignore-start\b/, yi = /^\/\*{1,2}(?:\s*|\n\s*\*\s*)esthetic-ignore-start\b/;
var xi = /(\/[*/]|{%-?\s*(?:comment\s*-?%}|#)|<!--)\s*esthetic-ignore-next\b/, wi = /^\s*[*-]\s/, At = /^\s*\d+\.\s/, Si = /^\s*(?:[*-]|\d+\.)\s/, yt = /^<!--+/, xt = /--+>$/, Li = /{%-?|-?%}/g;
var Ci = /^{%-?\s*#/;
var Jt = /(\/|\\|\||\*|\[|\]|\{|\})/g;

// src/comments/block.ts
function ut(e) {
  let { rules: s } = r, n = [], c = [], O = e.begin.replace(Jt, Ft), l = i(e.begin[0], 123) && i(e.begin[1], 37), N = l === !1 ? !1 : e.chars.slice(e.start + 2, e.chars.indexOf("%}", e.start + 2)).join(p).trimStart().charCodeAt(0) === 35, o = new RegExp(`^(${O}\\s*esthetic-ignore-start)`), d = new RegExp(`(${O}\\s*)`), b = l ? new RegExp(`\\s*${e.ender.replace(Li, (P) => i(P, 123) ? "{%-?\\s*" : "\\s*-?%}")}$`) : new RegExp(e.ender.replace(Jt, Ft)), t = e.start, f = 0, W = 0, R = 0, u = [], h = 0, w = p, x = !1, ae = !1, z = !1, a = p, C = e.ender.length - 1, F = e.ender.charAt(C), B = 0;
  function G() {
    if (rt.test(u[f + 1]) || u[f + 1] === p)
      do
        f = f + 1;
      while (f < h && (rt.test(u[f + 1]) || u[f + 1] === p));
    f < h - 1 && c.push(p);
  }
  function ie() {
    let P = Z;
    t = t + 1;
    do {
      if (n.push(e.chars[t]), n.slice(n.length - 19).join(p) === "esthetic-ignore-end") {
        if (l) {
          let ee = e.chars.indexOf("{", t);
          if (i(e.chars[ee + 1], 37)) {
            let ke = e.chars.slice(ee, e.chars.indexOf("}", ee + 1) + 1).join(p);
            b.test(ke) && (e.ender = ke);
          }
        }
        t = t + 1;
        break;
      }
      t = t + 1;
    } while (t < e.end);
    f = t, C = e.begin.length - 1, F = e.begin.charAt(C);
    do {
      if (e.begin === "/*" && i(e.chars[f - 1], 47) && (i(e.chars[f], 42) || i(e.chars[f], 47)) || e.begin !== "/*" && e.chars[f] === F && e.chars.slice(f - C, f + 1).join(p) === e.begin)
        break;
      f = f - 1;
    } while (f > e.start);
    if (e.begin === "/*" && i(e.chars[f], 42) ? P = "*/" : e.begin !== "/*" && (P = e.ender), C = P.length - 1, F = P.charAt(C), P !== Z || e.chars[t] !== Z)
      do {
        if (n.push(e.chars[t]), P === Z && e.chars[t + 1] === Z || e.chars[t] === F && e.chars.slice(t - C, t + 1).join(p) === P)
          break;
        t = t + 1;
      } while (t < e.end);
    return e.chars[t] === Z && (t = t - 1), a = n.join(p).replace(Gt, p), [a, t];
  }
  do {
    if (n.push(e.chars[t]), i(e.chars[t], 10) && (r.lineOffset = r.lines(t, r.lineOffset)), e.chars[t] === F && e.chars.slice(t - C, t + 1).join(p) === e.ender)
      break;
    t = t + 1;
  } while (t < e.end);
  if (a = n.join(p), o.test(a) === !0)
    return ie();
  if (l === !0 && s.liquid.preserveComment || l === !1 && s.markup.preserveComment || r.lexer === "style" && s.style.preserveComment || r.lexer === "script" && s.style.preserveComment || s.wrap < 1 && /comment\s*%}\n/.test(a) === !1 || t === e.end || a.length <= s.wrap && a.indexOf(Z) < 0 || e.begin === "/*" && a.indexOf(Z) > 0 && a.replace(Z, p).indexOf(Z) > 0 && /\n(?!\s*\*)/.test(a) === !1) {
    if (N) {
      u = a.replace(/\r\n/g, Z).split(Z);
      for (let P = 1, ee = u.length - 1; P < ee; P++)
        $(u[P].trimStart(), 35) && u[P].trimStart() !== "" && (u[P] = "# " + u[P].trimStart());
      return [u.join(r.crlf), t];
    }
    return [a, t];
  }
  if (f = e.start, f > 0 && $(e.chars[f - 1], 10) && le(e.chars[f - 1]))
    do
      f = f - 1;
    while (f > 0 && $(e.chars[f - 1], 10) && le(e.chars[f - 1]));
  let q = e.chars.slice(f, e.start).join(p), g = new RegExp(Z + q, "g");
  u = a.replace(/\r\n/g, Z).replace(g, Z).split(Z), h = u.length, u[0] = u[0].replace(d, p), u[h - 1] = u[h - 1].replace(b, p), h < 2 && (u = u[0].split(Y)), u[0] === p ? u[0] = e.begin : u.splice(0, 0, e.begin), h = u.length;
  let A = p, _ = h - 1;
  for (; _-- && u[_] === p; )
    A += Z;
  A !== p && (A = A.slice(0, s.preserveLine)), f = 0;
  do {
    if (w = f < h - 1 ? u[f + 1].replace(lt, p) : p, rt.test(u[f]) === !0 || u[f] === p)
      G();
    else {
      let P = u[f].replace(lt, p);
      if (s.wrap > 0 && P.length > s.wrap && P.indexOf(Y) > s.wrap)
        u[f] = P, W = u[f].indexOf(Y), c.push(u[f].slice(0, W)), u[f] = u[f].slice(W + 1), f = f - 1;
      else {
        if (f < 1 ? B = s.wrap - (e.begin.length + 1) : B = s.wrap, e.begin === "/*" && u[f].indexOf("/*") !== 0 ? u[f] = "   " : u[f] = u[f].replace(lt, p).replace(Gt, p).replace(et, Y), R = u[f].replace(lt, p).indexOf(Y), W = u[f].length, W > B && R > 0 && R < B) {
          W = B;
          do
            if (W = W - 1, le(u[f].charAt(W)) && W <= s.wrap)
              break;
          while (W > 0);
          At.test(u[f]) && At.test(u[f + 1]) === !1 && u.splice(f + 1, 0, "1. "), rt.test(u[f + 1]) === !0 || u[f + 1] === p ? (c.push(u[f].slice(0, W)), u[f] = u[f].slice(W + 1), x = !0, f = f - 1) : wi.test(u[f + 1]) ? (c.push(u[f].slice(0, W)), u[f] = u[f].slice(W + 1), ae = !0, f = f - 1) : At.test(u[f + 1]) ? (c.push(u[f].slice(0, W)), u[f] = u[f].slice(W + 1), z = !0, f = f - 1) : u[f].replace(lt, p).indexOf(Y) < s.wrap && (u[f].length > s.wrap ? u[f + 1] = u[f].slice(W + 1) + r.crlf + u[f + 1] : u[f + 1] = u[f].slice(W + 1) + Y + u[f + 1]), x === !1 && ae === !1 && z === !1 && (u[f] = u[f].slice(0, W));
        } else
          u[f + 1] !== void 0 && (u[f].length + w.indexOf(Y) > s.wrap && w.indexOf(Y) > 0 || u[f].length + w.length > s.wrap && w.indexOf(Y) < 0) ? (c.push(u[f]), s.wrap !== 0 && (f = f + 1), x = !0) : f > 0 && u[f + 1] !== void 0 && u[f + 1] !== p && u[f + 1].indexOf(Y) < 0 && rt.test(u[f + 1]) === !1 && Si.test(u[f + 1]) === !1 ? (u[f + 1] = `${u[f]} ${u[f + 1]}`, x = !0) : (c.push(u[f]), x = !0);
        ae = !1, z = !1;
      }
    }
    f = f + 1;
  } while (f < h);
  if (c.length > 0) {
    if (c[c.length - 1].length > s.wrap - (e.ender.length + 1) ? c.push(e.ender) : c.push(A + e.ender), N)
      for (let P = 1, ee = c.length - 1; P < ee; P++)
        $(c[P], 35) && c[P] !== "" && (c[P] = "# " + c[P]);
    a = c.join(r.crlf);
  } else
    u[u.length - 1] = u[u.length - 1] + e.ender, a = u.join(r.crlf);
  return [a, t];
}

// src/comments/line.ts
function Bt(e) {
  let { wrap: s } = r.rules, { preserveComment: n } = r.rules[r.lexer], c = e.start, O = 0, l = p, N = [];
  function o() {
    let b = p;
    do
      if (O = O + 1, i(e.chars[O + 1], 10))
        return;
    while (O < e.end && le(e.chars[O]));
    if (e.chars[O] + e.chars[O + 1] === "//") {
      N = [];
      do
        N.push(e.chars[O]), O = O + 1;
      while (O < e.end && $(e.chars[O], 10));
      b = N.join(p), /^\/\/ (?:[*-]|\d+\.)/.test(b) === !1 && /^\/\/\s*$/.test(b) === !1 && (l = `${l} ${b.replace(/(^\/\/\s*)/, p).replace(Te, p)}`, c = O - 1, o());
    }
  }
  function d() {
    let b = [], t = {
      ender: -1,
      types: "comment",
      lexer: e.lexer,
      lines: r.lineOffset
    };
    r.count > -1 ? (t.begin = r.stack.index, t.stack = r.stack.token, t.token = r.data.token[r.count]) : (t.begin = -1, t.stack = "global", t.token = p);
    let f = 0, W = 0;
    if (l = l.replace(/\s+/g, Y).replace(Te, p), W = l.length, !(s > W)) {
      do {
        if (f = s, $(l[f], 32)) {
          do
            f = f - 1;
          while (f > 0 && $(l[f], 32));
          if (f < 3) {
            f = s;
            do
              f = f + 1;
            while (f < W - 1 && $(l[f], 32));
          }
        }
        b.push(l.slice(0, f)), l = `// ${l.slice(f).replace(ot, p)}`, W = l.length;
      } while (s < W);
      f = 0, W = b.length;
      do
        t.token = b[f], r.push(r.data, t, p), t.lines = 2, r.lineOffset = 2, f = f + 1;
      while (f < W);
    }
  }
  do
    N.push(e.chars[c]), c = c + 1;
  while (c < e.end && $(e.chars[c], 10));
  if (c === e.end ? e.chars.push(Z) : c = c - 1, l = N.join(p).replace(Te, p), qt.test(l) === !0) {
    let b = Z;
    c = c + 1;
    do
      N.push(e.chars[c]), c = c + 1;
    while (c < e.end && ($(e.chars[c - 1], 100) || i(e.chars[c - 1], 100) && N.slice(N.length - 19).join(p) !== "esthetic-ignore-end"));
    O = c;
    do
      ;
    while (O > e.start && i(e.chars[O - 1], 47) && (i(e.chars[O], 42) || i(e.chars[O], 47)));
    if (i(e.chars[O], 42) && (b = "*/"), b !== Z || $(e.chars[c], 10))
      do {
        if (N.push(e.chars[c]), b === Z && i(e.chars[c + 1], 10))
          break;
        c = c + 1;
      } while (c < e.end && (b === Z || b === "*/" && (i(e.chars[c - 1], 42) || i(e.chars[c], 47))));
    return e.chars[c] === Z && (c = c - 1), l = N.join(p).replace(Te, p), [l, c];
  }
  return l === "//" || n === !0 ? [l, c] : (l = l.replace(/(\/\/\s*)/, "// "), s < 1 || c === e.end - 1 && r.data.begin[r.count] < 1 ? [l, c] : (O = c + 1, o(), d(), [l, c]));
}

// src/utils/native.ts
var Qe = Object.assign, Oi = Object.create;
var vi = Object.defineProperty;

// src/rules/definitions.ts
var Ut = {
  global: {
    preset: {
      description: "Use preset style guide as the base defaults",
      default: "default",
      type: "choice",
      values: [
        {
          rule: "default",
          description: "This is the default and the most unobtrusive."
        },
        {
          rule: "recommended",
          description: "This style guide is typically suited for most cases"
        },
        {
          rule: "strict",
          description: "This is a strict ruleset curated by the projects author."
        },
        {
          rule: "warrington",
          description: "This style guide preset is best suited for Shopify theme developers"
        },
        {
          rule: "prettier",
          description: "This preset replicates the Prettier style"
        }
      ]
    },
    correct: {
      default: !1,
      description: "Automatically correct some sloppiness in code.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !0,
        recommended: !0,
        strict: !0,
        warrington: !0
      }
    },
    crlf: {
      description: "If line termination should be Windows (CRLF) format. Unix (LF) format is the default.",
      type: "boolean",
      default: !1,
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    endNewline: {
      description: "Insert an empty line at the end of output.",
      type: "boolean",
      default: !1,
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    indentSize: {
      description: "The number of character values to comprise a single indentation.",
      type: "number",
      default: 2,
      preset: {
        default: 2,
        prettier: 2,
        recommended: 2,
        strict: 2,
        warrington: 2
      }
    },
    indentChar: {
      description: "The string characters to comprise a single indentation. Any string combination is accepted.",
      type: "string",
      default: " ",
      preset: {
        default: " ",
        prettier: " ",
        recommended: " ",
        strict: " ",
        warrington: " "
      }
    },
    indentLevel: {
      default: 0,
      type: "number",
      description: "How much indentation padding should be applied to beautification? This is typically used internally",
      preset: {
        default: 0,
        prettier: 0,
        recommended: 0,
        strict: 0,
        warrington: 0
      }
    },
    language: {
      description: "The language name",
      type: "choice",
      default: "auto",
      values: [
        {
          rule: "auto",
          description: "Detect Language"
        },
        {
          rule: "text",
          description: "Plain Text"
        },
        {
          rule: "html",
          description: "HTML"
        },
        {
          rule: "liquid",
          description: "HTML + Liquid"
        },
        {
          rule: "javascript",
          description: "JavaScript"
        },
        {
          rule: "jsx",
          description: "JSX"
        },
        {
          rule: "typescript",
          description: "TypeScript"
        },
        {
          rule: "tsx",
          description: "TSX"
        },
        {
          rule: "json",
          description: "JSON"
        },
        {
          rule: "css",
          description: "CSS"
        },
        {
          rule: "scss",
          description: "SCSS"
        },
        {
          rule: "less",
          description: "LESS"
        },
        {
          rule: "xml",
          description: "XML"
        }
      ]
    },
    preserveLine: {
      default: 2,
      description: "The maximum number of consecutive empty lines to retain.",
      type: "number",
      preset: {
        default: 2,
        prettier: 2,
        recommended: 3,
        strict: 1,
        warrington: 3
      }
    },
    wrap: {
      default: 0,
      description: "Character width limit before applying word wrap. A 0 value disables this option. A negative value concatenates script strings.",
      type: "number",
      preset: {
        default: 0,
        prettier: 80,
        recommended: 120,
        strict: 0,
        warrington: 100
      }
    },
    wrapFraction: {
      default: 0,
      description: "Wrap fraction is used on internal structures as a secondary point of control. By default, it will use a 75% metric according to `wrap` defined values.",
      type: "number",
      preset: {
        default: 0,
        prettier: 80,
        recommended: 80,
        strict: 80,
        warrington: 0
      }
    }
  },
  liquid: {
    commentNewline: {
      default: !1,
      description: "If a blank new line should be forced above comments.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !0,
        recommended: !0,
        strict: !0,
        warrington: !0
      }
    },
    commentIndent: {
      default: !1,
      description: "This will determine whether comments should always start at position 0 of each line or if comments should be indented according to the code.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !0,
        recommended: !0,
        strict: !0,
        warrington: !0
      }
    },
    delimiterTrims: {
      default: "preserve",
      description: "How delimiter whitespace trim dashes should handled on Liquid tokens. You should avoid setting this to force in order to avoid stripping whitespace between text content.",
      type: "choice",
      values: [
        {
          rule: "preserve",
          description: "All trim dash occurances of trims intact"
        },
        {
          rule: "never",
          description: "Removes all trim dash occurances for tags and output tokens"
        },
        {
          rule: "always",
          description: "Applies trime dashes to all tags and output tokens"
        },
        {
          rule: "tags",
          description: "Applies trim dashes to tags tokens only"
        },
        {
          rule: "outputs",
          description: "Applies trim dashes to output object tokens only"
        },
        {
          rule: "multiline",
          description: "Applies trim dashes to multline token expressions only"
        }
      ],
      preset: {
        default: "preserve",
        prettier: "preserve",
        recommended: "preserve",
        strict: "multiline",
        warrington: "preserve"
      }
    },
    ignoreTagList: {
      default: [],
      description: "A list of liquid tag to ignore",
      type: "array",
      preset: {
        default: [],
        prettier: ["javascript", "capture"],
        recommended: ["javascript"],
        strict: [],
        warrington: []
      }
    },
    indentAttribute: {
      default: !1,
      description: "Whether or not markup tags with Liquid contained attributes should apply indentation",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !0,
        recommended: !0,
        strict: !1,
        warrington: !0
      }
    },
    preserveComment: {
      default: !1,
      description: "Prevent comment reformatting due to option wrap.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    normalizeSpacing: {
      default: !0,
      description: "Whether or not to normalize the distributed spacing contained in Liquid tokens.",
      type: "boolean",
      preset: {
        default: !0,
        prettier: !0,
        recommended: !0,
        strict: !0,
        warrington: !0
      }
    },
    lineBreakSeparator: {
      default: "default",
      description: "Controls the placement of Liquid tag separator type characters in newline structures.",
      type: "choice",
      values: [
        {
          rule: "preserve",
          description: "Leave line break character intace"
        },
        {
          rule: "before",
          description: "Place line break character at the start of expressions"
        },
        {
          rule: "after",
          description: "Place line break character at the end of expressions"
        }
      ],
      preset: {
        default: "preserve",
        prettier: "after",
        recommended: "before",
        strict: "before",
        warrington: "after"
      }
    },
    dedentTagList: {
      default: [],
      description: "List of tags which will have their inner contents excluded from indentation",
      type: "array",
      preset: {
        default: [],
        prettier: ["schema"],
        recommended: [],
        strict: [],
        warrington: []
      }
    },
    forceArgument: {
      default: 0,
      description: "Forces arguments onto newlines. When this value is `0` then arguments will be forced according to wrap fraction limit.",
      type: "number",
      preset: {
        default: 0,
        prettier: 0,
        recommended: 3,
        strict: 3,
        warrington: 0
      }
    },
    forceFilter: {
      default: 0,
      description: "Forces filter pipes onto newlines. When this value is `0` then filters will be forced according to wrap fraction limit.",
      type: "number",
      preset: {
        default: 0,
        prettier: 0,
        recommended: 5,
        strict: 4,
        warrington: 0
      }
    },
    delimiterPlacement: {
      default: "preserve",
      description: "Controls the placement of Liquid delimiters",
      type: "choice",
      values: [
        {
          rule: "preserve",
          description: "Preserve delimiters"
        },
        {
          rule: "default",
          description: "Use defaults"
        },
        {
          rule: "consistent",
          description: "Place line break character at the start of expressions"
        },
        {
          rule: "inline",
          description: "Place line break character at the end of expressions"
        },
        {
          rule: "force-inline",
          description: "Place line break character at the end of expressions"
        },
        {
          rule: "force-multiline",
          description: "Place line break character at the end of expressions"
        }
      ],
      preset: {
        default: "preserve",
        prettier: "default",
        recommended: "consistent",
        strict: "force-multiline",
        warrington: "consistent"
      }
    },
    preserveInternal: {
      default: !1,
      description: "Whether or not to preserve the inner contents of tokens",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    quoteConvert: {
      description: "If the quotes should be converted to single quotes or double quotes.",
      type: "choice",
      default: "none",
      values: [
        {
          rule: "none",
          description: "Ignores this option"
        },
        {
          rule: "single",
          description: "Converts double quotes to single quotes"
        },
        {
          rule: "double",
          description: "Converts single quotes to double quotes"
        }
      ],
      preset: {
        default: "none",
        prettier: "double",
        recommended: "single",
        strict: "single",
        warrington: "single"
      }
    }
  },
  markup: {
    attributeSort: {
      default: !1,
      description: "Alphanumerically sort markup attributes. Attribute sorting is ignored on tags that contain attributes template attributes.",
      type: {
        array: "A list of attributes to begin sorting order with",
        boolean: "Whether or not to apply alphanumeric sorting"
      },
      preset: {
        default: !1,
        prettier: !1,
        recommended: !0,
        strict: ["id", "class", "type", "name", "value"],
        warrington: !1
      }
    },
    attributeCasing: {
      default: "preserve",
      description: "Controls the casing of attribute values and keys.",
      type: "choice",
      values: [
        {
          rule: "preserve",
          description: "All tag attribute keys/values are preserved and left intact."
        },
        {
          rule: "lowercase",
          description: "All tag attribute keys/values are converted to lowercase"
        },
        {
          rule: "lowercase-name",
          description: "Only attribute keys are converted to lowercase"
        },
        {
          rule: "lowercase-value",
          description: "Only attribute values are converted to lowercase"
        }
      ],
      preset: {
        default: "preserve",
        prettier: "preserve",
        recommended: "lowercase-name",
        strict: "lowercase-name",
        warrington: "preserve"
      }
    },
    commentNewline: {
      default: !1,
      description: "If a blank new line should be forced above comments.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !0,
        strict: !0,
        warrington: !1
      }
    },
    commentIndent: {
      default: !1,
      description: "This will determine whether comments should always start at position 0 of each line or if comments should be indented according to the code.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !0,
        strict: !0,
        warrington: !0
      }
    },
    delimiterTerminus: {
      description: "Whether or not ending HTML tag delimiters should be forced onto a newline. This will emulate the style of Prettier's singleAttributePerLine formatting option, wherein the last > delimiter character breaks itself onto a new line",
      default: "inline",
      type: "choice",
      values: [
        {
          rule: "inline",
          description: "Inline the ending delimiter"
        },
        {
          rule: "force",
          description: "Force the ending delimiter onto its own line"
        },
        {
          rule: "adapt",
          description: "adapt the delimiter in accordance with structure"
        }
      ],
      preset: {
        default: "inline",
        prettier: "force",
        recommended: "adapt",
        strict: "adapt",
        warrington: "adapt"
      }
    },
    forceAttribute: {
      default: !1,
      description: "If all markup attributes should be indented each onto their own line. This option accepts either a boolean or number value, depending on your preferences you can either force attributes based a count limit, disable forcing or always enable enforcing.",
      type: {
        number: "Optionally define an attribute force threshold. When the number of attributes exceeds this limit then they will be forced, otherwise they will be left intact.",
        boolean: "Whether or not to enforce the rule. A value of true will always force attributes, whereas a value of false will never force attributes."
      },
      preset: {
        default: !1,
        prettier: 1,
        recommended: 2,
        strict: 2,
        warrington: 2
      }
    },
    forceIndent: {
      default: !1,
      description: "Will force indentation upon all content and tags without regard for the creation of new text nodes.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !0,
        recommended: !0,
        strict: !0,
        warrington: !0
      }
    },
    ignoreJS: {
      default: !0,
      description: "Whether to ignore embedded regions of tags identified to contain JavaScript",
      type: "boolean",
      preset: {
        default: !0,
        prettier: !0,
        recommended: !0,
        strict: !1,
        warrington: !1
      }
    },
    ignoreCSS: {
      default: !1,
      description: "Whether to ignore embedded regions of tags identified to contain CSS",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !0,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    ignoreJSON: {
      default: !1,
      description: "Whether HTML <script> tags annotated with a JSON identifiable attribute should be ignored from beautification.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    preserveAttribute: {
      default: !1,
      description: "If markup tags should have their insides preserved. This option is only available to markup and does not support child tokens that require a different lexer.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    preserveComment: {
      default: !1,
      description: "Prevent comment reformatting due to option wrap.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    preserveText: {
      default: !1,
      description: "If text in the provided markup code should be preserved exactly as provided. This option eliminates beautification and wrapping of text content.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    lineBreakValue: {
      default: "preserve",
      description: "Determines how \xC6sthetic should handle line break occurance sequences within attribute values",
      type: "choice",
      values: [
        {
          rule: "preserve",
          description: "Preserve the supplied value structure sequences"
        },
        {
          rule: "align",
          description: "Align all line breaks to the starting point of attribute name"
        },
        {
          rule: "indent",
          description: "Indent all line breaks from the starting point of attribute name"
        },
        {
          rule: "force-preserve",
          description: "Force encapsulated values onto newlines but preserve inner contents"
        },
        {
          rule: "force-align",
          description: "Force encapsulated values onto newlines and apply aligned formatting"
        },
        {
          rule: "force-indent",
          description: "Force encapsulated values onto newlines and apply indentation formatting"
        }
      ],
      preset: {
        default: "preserve",
        prettier: "indent",
        recommended: "force-indent",
        strict: "force-indent",
        warrington: "force-indent"
      }
    },
    selfCloseSpace: {
      default: !1,
      description: 'Markup self-closing tags end will end with " />" instead of "/>".',
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !1,
        strict: !1,
        warrington: !1
      }
    },
    selfCloseSVG: {
      default: !0,
      description: "Whether or not SVG type tags should be converted to self closing void types.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !1,
        recommended: !0,
        strict: !0,
        warrington: !0
      }
    },
    stripAttributeLines: {
      default: !1,
      description: "Whether or not newlines contained within tag attributes should be removed or preserved.",
      type: "boolean",
      preset: {
        default: !1,
        prettier: !0,
        recommended: !0,
        strict: !0,
        warrington: !1
      }
    },
    quoteConvert: {
      description: "If the quotes should be converted to single quotes or double quotes.",
      type: "choice",
      default: "none",
      values: [
        {
          rule: "none",
          description: "Ignores this option"
        },
        {
          rule: "single",
          description: "Converts double quotes to single quotes"
        },
        {
          rule: "double",
          description: "Converts single quotes to double quotes"
        }
      ],
      preset: {
        default: "none",
        prettier: "double",
        recommended: "double",
        strict: "double",
        warrington: "double"
      }
    }
  },
  style: {
    classPadding: {
      description: "Inserts new line characters between every CSS code block.",
      default: !1,
      type: "boolean"
    },
    commentNewline: {
      default: !1,
      description: "If a blank new line should be forced above comments.",
      type: "boolean"
    },
    commentIndent: {
      default: !1,
      description: "This will determine whether comments should always start at position 0 of each line or if comments should be indented according to the code.",
      type: "boolean"
    },
    sortSelectors: {
      default: !1,
      type: "boolean",
      description: "If comma separated CSS selectors should present on a single line of code."
    },
    sortProperties: {
      description: "This option will alphabetically sort CSS properties contained within classes.",
      default: !1,
      type: "boolean"
    },
    noLeadZero: {
      description: "This will eliminate leading zeros from numbers expressed within values.",
      default: !1,
      type: "boolean"
    },
    preserveComment: {
      default: !1,
      description: "Prevent comment reformatting due to option wrap.",
      type: "boolean"
    },
    atRuleSpace: {
      default: !0,
      description: "Insert a single whitespace character betwen @ rules.",
      type: "boolean"
    },
    quoteConvert: {
      description: "If the quotes should be converted to single quotes or double quotes.",
      type: "choice",
      default: "none",
      values: [
        {
          rule: "none",
          description: "Ignores this option"
        },
        {
          rule: "single",
          description: "Converts double quotes to single quotes"
        },
        {
          rule: "double",
          description: "Converts single quotes to double quotes"
        }
      ]
    }
  },
  json: {
    arrayFormat: {
      description: "Determines if all array indexes should be indented, never indented, or left to the default",
      type: "choice",
      default: "default",
      values: [
        {
          rule: "default",
          description: "Default formatting"
        },
        {
          rule: "indent",
          description: "Always indent each index of an array"
        },
        {
          rule: "inline",
          description: "Ensure all array indexes appear on a single line"
        }
      ]
    },
    braceAllman: {
      default: !1,
      description: 'Determines if opening curly braces will exist on the same line as their condition or be forced onto a new line, otherwise known as "Allman Style" indentation.',
      type: "boolean"
    },
    bracePadding: {
      default: !1,
      description: "This will create a newline before and after objects values",
      type: "boolean"
    },
    objectIndent: {
      description: "This option will alphabetically sort object properties in JSON objects",
      type: "choice",
      default: "default",
      values: [
        {
          rule: "default",
          description: "Default formatting"
        },
        {
          rule: "indent",
          description: "Always indent each index of an array"
        },
        {
          rule: "inline",
          description: "Ensure all array indexes appear on a single line"
        }
      ]
    },
    objectSort: {
      default: !1,
      description: "This option will alphabetically sort object properties in JSON objects",
      type: "boolean"
    }
  },
  script: {
    arrayFormat: {
      description: "Determines if all array indexes should be indented, never indented, or left to the default",
      type: "choice",
      default: "default",
      values: [
        {
          rule: "default",
          description: "Default formatting"
        },
        {
          rule: "indent",
          description: "Always indent each index of an array"
        },
        {
          rule: "inline",
          description: "Ensure all array indexes appear on a single line"
        }
      ]
    },
    braceAllman: {
      default: !1,
      description: 'Determines if opening curly braces will exist on the same line as their condition or be forced onto a new line, otherwise known as "Allman Style" indentation.',
      type: "boolean"
    },
    bracePadding: {
      default: !1,
      description: "This will create a newline before and after objects values",
      type: "boolean"
    },
    braceNewline: {
      default: !1,
      description: "If true an empty line will be inserted after opening curly braces and before closing curly braces.",
      type: "boolean"
    },
    braceStyle: {
      default: "none",
      description: "Emulates JSBeautify's brace_style option using existing Prettify options",
      type: "choice",
      values: [
        {
          rule: "none",
          description: "Ignores this option"
        },
        {
          rule: "collapse",
          description: "Sets formatObject to indent and neverflatten to true."
        },
        {
          rule: "collapse-preserve-inline",
          description: "Sets formatObject to inline and bracePadding to true"
        },
        {
          rule: "expand",
          description: "Sets objectIndent to indent and braceNewline + neverflatten to true."
        }
      ]
    },
    caseSpace: {
      default: !1,
      type: "boolean",
      description: "If the colon separating a case's expression (of a switch/case block) from its statement should be followed by a space instead of indentation thereby keeping the case on a single line of code."
    },
    commentNewline: {
      default: !1,
      description: "If a blank new line should be forced above comments.",
      type: "boolean"
    },
    commentIndent: {
      default: !1,
      description: "This will determine whether comments should always start at position 0 of each line or if comments should be indented according to the code.",
      type: "boolean"
    },
    elseNewline: {
      default: !1,
      type: "boolean",
      description: 'If keyword "else" is forced onto a new line.'
    },
    endComma: {
      description: "If there should be a trailing comma in arrays and objects.",
      type: "choice",
      default: "none",
      values: [
        {
          rule: "none",
          description: "Ignore this option"
        },
        {
          rule: "always",
          description: "Always ensure there is a tailing comma"
        },
        {
          rule: "never",
          description: "Remove trailing commas"
        }
      ]
    },
    objectSort: {
      default: !1,
      description: "This option will alphabetically sort object properties in JSON objects",
      type: "boolean"
    },
    objectIndent: {
      description: "This option will alphabetically sort object properties in JSON objects",
      type: "choice",
      default: "default",
      values: [
        {
          rule: "default",
          description: "Default formatting"
        },
        {
          rule: "indent",
          description: "Always indent each index of an array"
        },
        {
          rule: "inline",
          description: "Ensure all array indexes appear on a single line"
        }
      ]
    },
    functionSpace: {
      default: !0,
      type: "boolean",
      description: "Inserts a space following the function keyword for anonymous functions."
    },
    functionNameSpace: {
      default: !0,
      type: "boolean",
      description: "If a space should follow a JavaScript function name."
    },
    methodChain: {
      default: -1,
      description: "When to break consecutively chained methods and properties onto separate lines. A negative value disables this option. A value of 0 ensures method chainsare never broken.",
      type: "number"
    },
    preserveComment: {
      default: !1,
      description: "Prevent comment reformatting due to option wrap.",
      type: "boolean"
    },
    ternaryLine: {
      description: "If ternary operators in JavaScript `?` and `:` should remain on the same line.",
      type: "boolean",
      default: !1
    },
    neverFlatten: {
      default: !0,
      description: "If destructured lists in script should never be flattend.",
      type: "boolean"
    },
    noCaseIndent: {
      description: "If the colon separating a case's expression (of a switch/case block) from its statement should be followed by a space instead of indentation, thereby keeping the case on a single line of code.",
      default: !1,
      type: "boolean"
    },
    noSemicolon: {
      description: "Removes semicolons that would be inserted by ASI. This option is in conflict with option `attemptCorrection` and takes precedence over conflicting features. Use of this option is a possible security/stability risk.",
      default: !1,
      type: "boolean"
    },
    quoteConvert: {
      description: "If the quotes should be converted to single quotes or double quotes.",
      type: "choice",
      default: "none",
      values: [
        {
          rule: "none",
          description: "Ignores this option"
        },
        {
          rule: "single",
          description: "Converts double quotes to single quotes"
        },
        {
          rule: "double",
          description: "Converts single quotes to double quotes"
        }
      ]
    },
    variableList: {
      description: "If consecutive JavaScript variables should be merged into a comma separated list or if variables in a list should be separated. each \u2014 Ensure each reference is a single declaration statement.",
      type: "choice",
      default: "none",
      values: [
        {
          rule: "none",
          description: "Ignores this option"
        },
        {
          rule: "each",
          description: "Ensure each reference is a single declaration statement"
        },
        {
          rule: "list",
          description: "Ensure consecutive declarations are a comma separated list"
        }
      ]
    },
    vertical: {
      description: "If lists of assignments and properties should be vertically aligned",
      type: "boolean",
      default: !1
    }
  }
};

// src/parse/external.ts
function Nt(e, s, n) {
  if (s === "html") {
    if (!(e in ye.html.embed))
      return !1;
    let c = ye.html.embed[e];
    if (c.attr.size > 0)
      for (let O of c.attr.values()) {
        if (!n)
          return O;
        if (O.attr.has(n[0]) && O.attr.get(n[0]).value.has(n[1]))
          return O.attr.get(n[0]);
      }
    return c.attr.has(n[0]) ? c.attr.get(n[0]).attr.has(n[1]) ? c.attr.get(n[0]).attr.get(n[1]) : c.attr.get(n[0]) : c;
  } else if (s === "liquid") {
    if (!(e in ye.liquid.embed))
      return !1;
    let c = ye.liquid.embed[e];
    if (c.args.size > 0 && n) {
      let O = n.slice(n.indexOf(e) + e.length).match(/\s*(.*)(?=\s)/)[0];
      for (let [l, N] of c.args) {
        if (l.has(O))
          return N;
        for (let o of l)
          if (o instanceof RegExp && o.test(O))
            return N;
      }
    }
    return c;
  }
}
function Ri(e, s) {
  return typeof s != "undefined" ? e in ye[s].embed : e in ye.html.embed || e in ye.liquid.embed;
}

// src/lexical/liquid.ts
function qi(e, s) {
  let n = i(e[2], 45) ? 3 : 2, c = e.slice(n), O;
  return s.delimiterTrims === "never" ? O = `{${e[1]}` : s.delimiterTrims === "always" || s.delimiterTrims === "outputs" && i(e[1], 123) || s.delimiterTrims === "tags" && i(e[1], 37) ? O = `{${e[1]}-` : O = e.slice(0, n), s.delimiterPlacement === "preserve" ? O += /^\s*\n/.test(c) ? Z : Y : s.delimiterPlacement === "force" ? O += Z : s.delimiterPlacement === "inline" || s.delimiterPlacement === "default" || s.delimiterPlacement === "force-multiline" ? O += Y : s.delimiterPlacement === "consistent" && (/^\s*\n/.test(c) ? O += Z : O += Y), O + c.trim();
}
function Ai(e, s) {
  let n = i(e[e.length - 3], 45) ? e.length - 3 : e.length - 2, c = e.slice(0, n) || p, O;
  return s.delimiterTrims === "never" ? O = `${e[e.length - 2]}}` : s.delimiterTrims === "always" || s.delimiterTrims === "outputs" && i(e[1], 123) || s.delimiterTrims === "tags" && i(e[1], 37) ? O = `-${e[e.length - 2]}}` : O = e.slice(n), s.delimiterPlacement === "preserve" ? O = (/\s*\n\s*$/.test(c) ? Z : Y) + O : s.delimiterPlacement === "force" ? O = Z + O : s.delimiterPlacement === "inline" || s.delimiterPlacement === "default" || s.delimiterPlacement === "force-multiline" ? O = Y + O : s.delimiterPlacement === "consistent" && (/^\s*\n/.test(c) ? O = Z + O : O = Y + O), c.trim() + O;
}
function jt(e, s, n) {
  let [c, O] = Ni(e), l, N = e.slice(c, O), o;
  return n.delimiterTrims === "never" ? (l = `{${e[1]}`, o = `${e[e.length - 2]}}`) : n.delimiterTrims === "always" || n.delimiterTrims === "outputs" && i(e[1], 123) || n.delimiterTrims === "tags" && i(e[1], 37) ? (l = `{${e[1]}-`, o = `-${e[e.length - 2]}}`) : (l = e.slice(0, c), o = e.slice(O)), s || (s = N.trimStart().split(/\s/)[0] || ""), s === "else" || s === "break" || s === "continue" || s === "increment" || s === "decrement" || s.startsWith("end") ? (l += Y, o = Y + o) : n.delimiterPlacement === "preserve" ? (l += /^\s*\n/.test(N) ? Z : Y, o = (/\s*\n\s*$/.test(N) ? Z : Y) + o) : n.delimiterPlacement === "force" ? (l += Z, o = Z + o) : n.delimiterPlacement === "inline" || n.delimiterPlacement === "default" || n.delimiterPlacement === "force-multiline" ? (l += Y, o = Y + o) : n.delimiterPlacement === "consistent" && (/^\s*\n/.test(N) ? (l += Z, o = Z + o) : (l += Y, o = Y + o)), N = N.trim(), l + N + o;
}
function Bi(e, s, n, {
  wrapFraction: c,
  liquid: {
    forceFilter: O,
    forceArgument: l,
    lineBreakSeparator: N,
    delimiterTrims: o,
    delimiterPlacement: d,
    preserveInternal: b
  }
}) {
  let [t, f] = Ni(e), W, R;
  if (o === "never" ? (W = `{${e[1]}`, R = `${e[e.length - 2]}}`) : o === "always" || o === "outputs" && i(e[1], 123) || o === "tags" && i(e[1], 37) ? (W = `{${e[1]}-`, R = `-${e[e.length - 2]}}`) : o === "preserve" ? (W = e.slice(0, t).join(p), R = e.slice(f).join(p)) : (W = `{${e[1]}`, R = `${e[e.length - 2]}}`), s === "else" || s === "break" || s === "continue" || s === "increment" || s === "decrement" || s.startsWith("end"))
    return W += Y, R = Y + R, W + e.slice(t, f).join(p).trim() + R;
  if (d === "preserve" ? (W += i(e[t], 10) ? Z : Y, R = (i(e[f - 1], 10) ? Z : Y) + R) : d === "force" ? (W += Z, R = Z + R) : d === "inline" || d === "default" ? (W += Y, R = Y + R) : d === "consistent" ? i(e[t], 10) ? (W += Z, R = Z + R) : (W += Y, R = Y + R) : (W += Y, R = Y + R), s === "liquid" || b === !0)
    return W + e.slice(t, f).join(p).trim() + R;
  if (c > 0 && e.length >= c && n.logic.length > 0 && (s === "if" || s === "elsif" || s === "unless" || s === "when")) {
    o === "multiline" && (W = `{${e[1]}-` + W[W.length - 1], R = R[0] + `-${e[e.length - 2]}}`), d === "force-multiline" && (W = W.trimEnd() + Z, R = Z + R.trimStart());
    let h = n.logic.length;
    for (let w = 0; w < h; w++) {
      let x = n.logic[w];
      e[x] = Z + e[x], i(e[x - 1], 32) && (e[x - 1] = p);
    }
    return W + e.slice(t, f).join(p).trim() + R;
  }
  let u = n.pipes.length;
  if (u > 0) {
    if (O > 0 && u >= O || O === 0 && c > 0 && e.length > c) {
      o === "multiline" && (W = `{${e[1]}-` + W[W.length - 1], R = R[0] + `-${e[e.length - 2]}}`), d === "force-multiline" && (W = W.trimEnd() + Z, R = Z + R.trimStart());
      for (let h = 0; h < u; h++) {
        let w = n.pipes[h];
        if (i(e[w - 1], 32) && (e[w - 1] = p), e[w] = Z + e[w], h === 0) {
          let x = w - 1;
          if (i(e[x - 1], 32))
            do
              e[x--] = p;
            while (i(e[x], 32));
        }
        if (n.fargs[h] && (l > 0 && n.fargs[h].length >= l || l === 0 && c > 0 && e.slice(
          n.fargs[h][0],
          n.fargs[h][n.fargs[h].length - 1]
        ).length > c)) {
          let x = n.fargs[h].length;
          for (let ae = 0; ae < x; ae++) {
            let z = n.fargs[h][ae];
            N === "after" ? e[i(e[z - 1], 44) ? z - 1 : z] = ae === 0 ? Z + "  " : ze + Z + " " : N === "before" ? i(e[z - 1], 44) ? e[z - 1] = ae === 0 ? "  " + Z : Z + "  " + ze : e[z] = ae === 0 ? Z + "  " : Z + "  " + ze : e[z] = Z + "  " + e[z];
          }
        }
      }
    }
    return W + e.slice(t, f).join(p).trim() + R;
  }
  if (n.targs.length >= l) {
    o === "multiline" && (W = `{${e[1]}-` + W[W.length - 1], R = R[0] + `-${e[e.length - 2]}}`);
    for (let h = 0; h < n.targs.length; h++) {
      let w = n.targs[h];
      N === "after" ? (i(e[w + 1], 32) && (e[w + 1] = p), i(e[w - 1], 32) && (e[w - 1] = p), e[w] = i(e[w], 44) ? ze + Z : Z) : N === "before" && (i(e[w - 1], 44) ? e[w - 1] = h === 0 ? Z + ze : Z + ze : e[w] = h === 0 ? Z + ze : Z + ze);
    }
  }
  return W + e.slice(t, f).join(p).trim() + R;
}
function Ni(e) {
  return [
    i(e[2], 45) ? 3 : 2,
    i(e[e.length - 3], 45) ? e.length - 3 : e.length - 2
  ];
}
function ji(e, s = !0) {
  return s ? new RegExp(`{%-?\\s*${e}\\s*-?%}`) : new RegExp(`{%-?\\s*${e}`);
}
function Pi(e) {
  let s = e.indexOf("{");
  return i(e[s + 1], 123);
}
function Zt(e) {
  let s = e.indexOf("{");
  if (i(e[s + 1], 37)) {
    let n;
    return n = e.slice(s + (i(e[s + 2], 45) ? 3 : 2)).trimStart(), n = n.slice(0, n.search(/[\s=|!<>,.[]|-?[%}]}/)), n.startsWith("end") ? !1 : ye.liquid.else.has(n);
  }
  return !1;
}
function Ei(e) {
  let s = e.indexOf("=");
  return s > -1 && (i(e[s + 1], 34) || i(e[s + 1], 39)) ? /{%-?\s*end[a-z]+/.test(e.slice(s, e.lastIndexOf(e[s + 1]))) : !1;
}
function Xt(e) {
  return ft(e) ? /{%-?\s*end\w+/.test(e) : !1;
}
function ft(e, s = !1) {
  let n;
  if (s)
    return i(e[0], 123) && i(e[1], 37) && i(e[e.length - 2], 37) && i(e[e.length - 1], 125) ? (n = e.slice(i(e[2], 45) ? 3 : 2).trimStart(), i(n, 34) || i(n, 39) ? !1 : (n = n.slice(0, n.search(/[\s=|!<"'>,.[]|-?[%}]}/)), n.startsWith("end") ? !1 : ye.liquid.tags.has(n))) : !1;
  let c = e.indexOf("{");
  if (c === -1)
    return !1;
  do {
    if (i(e[c + 1], 37))
      return n = e.slice(c + (i(e[c + 2], 45) ? 3 : 2)).trimStart(), n = n.slice(0, n.search(/[\s=|!<>,.[]|-?[%}]}/)), n.startsWith("end") ? !1 : ye.liquid.tags.has(n);
    c = e.indexOf("{", c + 1);
  } while (c > -1);
  return !1;
}
function Pt(e) {
  let s = e;
  Array.isArray(e) && (s = e.join(p));
  let n = s.indexOf("{");
  return i(s[n + 1], 37) ? i(s[n + 2], 45) ? s.slice(n + 3).trimStart().startsWith("end") : s.slice(n + 2).trimStart().startsWith("end") : !1;
}
function Et(e, s) {
  if (s === 1)
    return i(e[0], 123) && (i(e[1], 37) || i(e[1], 123));
  if (s === 6)
    return i(e[0], 123) && i(e[1], 37);
  if (s === 7)
    return i(e[0], 123) && i(e[1], 123);
  if (s === 8)
    return i(e[e.length - 2], 37) && i(e[e.length - 1], 125);
  if (s === 9)
    return i(e[e.length - 2], 125) && i(e[e.length - 1], 125);
  if (s === 4)
    return /{[{%]/.test(e);
  if (s === 5)
    return /{[{%]/.test(e) && /[%}]}/.test(e);
  if (s === 2) {
    let n = e.length;
    return i(e[n - 1], 125) && (i(e[n - 2], 37) || i(e[n - 2], 125));
  } else if (s === 3) {
    let n = e.length;
    return i(e[0], 123) && (i(e[1], 37) || i(e[1], 123)) && i(e[n - 1], 125) && (i(e[n - 2], 37) || i(e[n - 2], 125));
  }
}

// src/lexers/markup.ts
function Kt(e) {
  let { data: s, rules: n } = r, c = e || r.source, O = r.language === "jsx" || r.language === "tsx", l = new Set(n.liquid.ignoreTagList), N = Re(n.markup.attributeSort) ? n.markup.attributeSort.length : -1, o = Re(c) ? c : c.split(p), d = o.length, b = {
    start: -1,
    tname: [],
    index: []
  }, t = 0, f, W = !1, R = Kt ? r.language : "html", u = 0;
  function h(q, g = p, A) {
    if (g === p && A === void 0)
      r.push(s, q, p);
    else if (gt(g))
      Qe(q, g), r.push(s, q, p);
    else if (Re(g))
      for (let _ of g)
        Qe(q, _), r.push(s, q, p);
    else
      A ? (Qe(q, A), r.push(s, q, g)) : console.log("isssue");
  }
  function w(q, g = null) {
    return r.language !== "html" && r.language !== "liquid" && O === !1 || /(?:{[=#/]|%[>\]])|\}%[>\]]/.test(q) || !Et(q, 3) ? q : jt(q, g, n.liquid);
  }
  function x(q, g = p) {
    if (q < 1)
      return g;
    let A = p, _ = o.lastIndexOf(Z, q);
    return _ > -1 && (A = c.slice(_ + 1, q), A.length > 0 && A.trim().length < 1) ? g ? A + g : A : g;
  }
  function ae(q, g = o) {
    let A = q, _ = 1;
    for (; i(g[A++], 10); )
      _ = _ + 1;
    return _;
  }
  function z(q, g = -1, A = !1) {
    return A === !1 ? c.slice(q, g).trimStart() : c.slice(q, g);
  }
  function a(q) {
    let g = q;
    do
      g = g - 1;
    while (i(o[g], 92));
    return g = q - g, g % 2 === 1;
  }
  function C(q) {
    return n.correct === !1 || i(q[q.length - 2], 47) ? q : /\/\s+>$/.test(q) ? `${q.slice(0, q.lastIndexOf("/"))}${n.markup.selfCloseSpace ? "/>" : " />"}` : `${q.slice(0, -1)}${n.markup.selfCloseSpace ? "/>" : " />"}`;
  }
  function F(q, g = !0) {
    let A = q.indexOf("=");
    if (A > 0) {
      let _ = q.indexOf(Ce);
      if (A < _ && _ > 0)
        return g ? [q.slice(0, A), q.slice(A + 1)] : [q.slice(0, A), q.slice(A + 2, -1)];
      let P = q.indexOf(ve);
      if (A < P && P > 0)
        return g ? [q.slice(0, A), q.slice(A + 1)] : [q.slice(0, A), q.slice(A + 2, -1)];
    }
    return [q, p];
  }
  function B(q) {
    let g = {
      lexer: "markup",
      lines: r.lineOffset,
      stack: r.stack.token !== "global" ? r.stack.token : "global",
      begin: r.stack.index,
      token: p,
      types: p,
      ender: -1
    }, A = p, _ = p, P = p, ee = p, ke = p, we = !1, oe = !1, T = 0, J = !1, X = !1, V = !1, se = !1, D = [];
    function re() {
      return K();
    }
    function ge() {
      if (g.types.indexOf("liquid") < 0)
        return re();
      if (g.token === p && (g.token = A), i(A[0], 123) && i(A[1], 37))
        if (ye.liquid.else.has(ee))
          g.types = P = ee === "when" ? "liquid_when" : "liquid_else";
        else {
          if (ye.liquid.tags.has(ee))
            return g.types = P = "liquid_start", K();
          if (ee.startsWith("end")) {
            let S = ee.slice(3);
            if (ye.liquid.tags.has(S))
              g.types = P = "liquid_end";
            else {
              g.stack = S, g.types = P = "liquid_end";
              let E = 0;
              do {
                if (s.types[E] === "liquid" && s.stack[E] === S) {
                  s.types[E] = "liquid_start";
                  break;
                }
                E = s.stack.indexOf(S, E + 1);
              } while (E > -1);
            }
          } else
            g.stack = ee;
        }
      return n.liquid.quoteConvert === "double" ? g.token = A = g.token.replace(/'[^"]*?'/g, zt(Ce)) : n.liquid.quoteConvert === "single" && (g.token = A = g.token.replace(/"[^']*?"/g, zt(ve))), re();
    }
    function Be() {
      let S = A.indexOf("liquid") + 6, E = p, M = p, I = 1;
      h(g, {
        token: qi(A.slice(0, S), n.liquid),
        types: "liquid_start",
        stack: "liquid"
      });
      let H = A.slice(S).split(Z), fe = H.pop().trim(), ue = i(fe[fe.length - 3], 45) ? fe.length - 3 : fe.length - 2, de = fe.slice(0, ue), ne = fe.slice(ue);
      de.length !== 0 && H.push(de), S = 0;
      do
        E = H[S].trim(), M = E.split(/\s/)[0], M.startsWith("end") ? (g.token = E, g.types = "liquid_end", g.lines = I, h(g), I = 1) : M.startsWith("#") ? (g.token = E, g.types = "liquid", g.lines = I <= 1 ? 2 : I, h(g), I = 1) : M.startsWith("comment") || ye.liquid.tags.has(M) ? (g.token = E, g.types = "liquid_start", g.lines = I, h(g), I = 1) : ye.liquid.else.has(M) ? (g.token = E, g.types = M === "when" ? "liquid_when" : "liquid_else", g.lines = I, h(g), I = 1) : ye.liquid.singleton.has(M) ? (g.token = E, g.types = "liquid", g.lines = I <= 1 ? 2 : I, h(g), I = 1) : E.trim().length > 0 && (g.token = E, g.types = "content", g.lines = I, h(g), I = 1), S = S + 1, I = I + 1;
      while (S < H.length);
      n.liquid.delimiterPlacement === "default" || n.liquid.delimiterPlacement === "force-multiline" || n.liquid.delimiterPlacement === "preserve" && /\n-?%}$/.test(A) || n.liquid.delimiterPlacement === "consistent" && /^{%-?\n/.test(A) ? h(g, {
        token: ne,
        types: "liquid_end",
        lines: 2
      }) : r.replace({
        token: Ai(r.current.token + ne, n.liquid)
      });
    }
    function Se() {
      if (ee === "svg" && (b.start = r.count + 1), ye.svg.tags.has(ee) && b.start > 0) {
        if (g.types === "start")
          g.types = "singleton", b.tname.push(ee), b.index.push(r.count + 1);
        else if (g.types === "end") {
          let S = b.tname.indexOf(ee), E = b.tname.lastIndexOf(ee);
          S > -1 && (E === S ? (s.types[b.index[E]] = "start", b.tname.splice(E, 1), b.index.splice(E, 1)) : s.begin[r.count] === b.index[S] ? (s.types[s.begin[r.count]] = "start", b.tname.splice(S, 1), b.index.splice(S, 1)) : s.types[b.index[E]] = "start"), ee === "svg" && (b.start = -1);
        }
      }
      return ge();
    }
    function Q() {
      return se && oe === !1 && P !== "xml" && (ye.html.voids.has(ee) ? (g.types = P = "singleton", $(A[A.length - 2], 47) && (g.token = C(A))) : i(A[A.length - 2], 47) && i(A[A.length - 1], 62) ? g.types = P = "singleton" : g.types = P = "start"), Se();
    }
    function U() {
      if (r.count < 1 && W === !1)
        return Q();
      let S = p;
      if (xi.test(s.token[r.count])) {
        if (ye.html.voids.has(ee))
          return g.token = A.replace(">", D.map(([E]) => E).join(Y) + ">"), g.types = "ignore", h(g);
        P.indexOf("liquid") > -1 && ye.liquid.tags.has(ee) && (S = `end${ee}`), oe = !0, V = !1;
      } else
        Ri(ee, "liquid") && l.has(ee) && (S = null);
      if (S !== null && V === !1 && oe === !0 && (q === ">" || q === "}}" || q === "%}")) {
        let E = [];
        if (V = !0, t = t + 1, t < d) {
          P !== "json_preserve" && P !== "script_preserve" && P !== "style_preserve" && P !== "liquid_json_preserve" && P !== "liquid_script_preserve" && P !== "liquid_style_preserve" && (P = "ignore");
          let M = p, I = 0, H = -1, fe = p, ue = 0, de = 0, ne = !1;
          do {
            if (i(o[t], 10) && r.lines(t), E.push(o[t]), M === p) {
              if (M = i(o[t], 34) ? Ce : i(o[t], 39) ? ve : p, i(o[t], 123) && (i(o[t + 1], 123) || i(o[t + 1], 37))) {
                if (H = i(o[t + 1], 37) ? o.indexOf("}", t) + 1 : o.indexOf("}", t) + 2, fe = z(i(o[t + 2], 45) ? t + 3 : t + 2, H), fe.startsWith(ee))
                  I = I + 1;
                else if (fe.startsWith(S)) {
                  if (I > 0)
                    I = I - 1;
                  else if (i(o[t + 1], 123) && (H = H + 1), i(o[H - 2], 37)) {
                    E.push(...o.slice(t + 1, H)), P = "liquid_ignore", t = H - 1;
                    break;
                  }
                }
              } else if (i(o[t], 60) && se === !0)
                ne = i(o[t + 1], 47);
              else if (o[t] === _ && $(o[t - 1], 47))
                if (ne === !0) {
                  if (T = T - 1, T < 0)
                    break;
                } else
                  T = T + 1;
            } else if (i(o[t], M.charCodeAt(M.length - 1))) {
              if (de = 0, ue = M.length - 1, i(M[ue], 125)) {
                if (z(t + (i(o[t + 2], 45) ? 3 : 2), o.indexOf("%", t + 2)).startsWith(S))
                  break;
              } else if (ue > -1)
                do {
                  if ($(o[t - de], M.charCodeAt(ue)))
                    break;
                  de = de + 1, ue = ue - 1;
                } while (ue > -1);
              ue < 0 && (M = p);
            }
            t = t + 1;
          } while (t < d);
        }
        if (P === "ignore") {
          r.is("types", "ignore") || (s.types[r.count] = "ignore");
          let M = r.iterator + o.slice(r.iterator, t).join(p).search(kt), I = x(M);
          I === p && (I = s.token[r.count].search(kt) > 0 ? Xe(s.token[r.count].search(kt)) : p), D = [], A = I + o.slice(M, t - E.length + 1).join(p) + E.join(p), g.types = "ignore", g.token = A;
        } else if (P === "liquid_ignore")
          r.is("types", "ignore") || (s.types[r.count] = "ignore"), A = x(t - A.length - E.length + 1, A) + E.join(p), P = "ignore", g.types = "ignore", g.token = A;
        else if (!P.startsWith("liquid_")) {
          g.types = "start", K(!0);
          let M = E.lastIndexOf("<"), I = E.slice(0, M).join(p);
          return kt.test(I) ? h(g, [
            {
              lexer: "markup",
              types: P,
              token: I
            },
            {
              lexer: "markup",
              types: "end",
              token: E.slice(M).join(p).trim()
            }
          ]) : h(g, [
            {
              lexer: "markup",
              types: "end",
              token: E.slice(M).join(p).trim()
            }
          ]), W = !1, f = R, j();
        }
      } else if (ee === "script" && S !== null && V === !1 && oe === !1 && q === ">" && D.length > 0) {
        let E = 0;
        do {
          if (D[E][0].startsWith("src")) {
            W = c.slice(t + 1, c.indexOf("</script>") + 9).trim() !== "</script>";
            break;
          }
          E = E + 1;
        } while (E < D.length);
      }
      return Q();
    }
    function y() {
      if (i(A, 60) && i(A[1], 47))
        return U();
      let S = D.length - 1;
      if (i(A, 60))
        if (S > -1)
          do {
            let E = Nt(ee, "html", F(D[S][0], !1));
            if (E !== !1)
              if (E.language === "json" && n.markup.ignoreJSON) {
                P = "json_preserve", oe = !0;
                break;
              } else if (E.language === "javascript" && n.markup.ignoreJS) {
                P = "script_preserve", oe = !0;
                break;
              } else if (E.language === "css" && n.markup.ignoreCSS) {
                P = "style_preserve", oe = !0;
                break;
              } else {
                f = E.language, P = "start", W = !0, oe = !1;
                break;
              }
            S = S - 1;
          } while (S > -1);
        else {
          let E = Nt(ee, "html");
          E !== !1 && (E.language === "json" && n.markup.ignoreJSON ? (P = "json_preserve", oe = !0) : E.language === "javascript" && n.markup.ignoreJS ? (P = "script_preserve", oe = !0) : E.language === "css" && n.markup.ignoreCSS ? (P = "style_preserve", oe = !0) : (f = E.language, P = "start", W = !0, oe = !1));
        }
      else if (ft(A, !0)) {
        let E = Nt(ee, "liquid", A);
        if (E !== !1) {
          if (l.has(ee))
            return oe = !0, V = !1, U();
          W = !0, f = E.language;
        }
      }
      return U();
    }
    function K(S = !1) {
      if (S !== null && h(g), i(o[t], 62) && i(o[t + 1], 47))
        return;
      let E = r.count, M = ee.replace(/\/$/, p), I = n.markup.quoteConvert, H = 0, fe = 0, ue = 0, de = p, ne = p, te = D.length;
      function Me() {
        r.attributes.has(E) && H + 1 === te && Qt(g.token, 62) && (g.token = g.token + ">");
        let he = g.types.indexOf("liquid_attribute") > -1;
        if (oe === !0 || I === "none" || g.types.indexOf("attribute") < 0 || he === !1 && I === "single" && g.token.indexOf(Ce) < 0 || he === !1 && I === "double" && g.token.indexOf(ve) < 0)
          h(g);
        else {
          let Le = 0, We = !1, xe = g.token.split(p), ce = g.token.indexOf("="), dt = xe.length - 1;
          if ($(xe[ce + 1], 34) && $(xe[xe.length - 1], 34) && I === "single" && he === !1)
            h(g);
          else if ($(xe[ce + 1], 39) && $(xe[xe.length - 1], 39) && I === "double" && he === !1)
            h(g);
          else {
            if (Le = ce + 2, he === !1 && (I === "double" ? (g.token.slice(ce + 2, dt).indexOf(Ce) > -1 && (We = !0), xe[ce + 1] = Ce, xe[xe.length - 1] = Ce) : I === "single" && (g.token.slice(ce + 2, dt).indexOf(ve) > -1 && (We = !0), xe[ce + 1] = ve, xe[xe.length - 1] = ve)), We === !0 || he === !0) {
              he = !1;
              do
                i(xe[Le - 1], 123) && (i(xe[Le], 37) || i(xe[Le], 123)) ? he = !0 : i(xe[Le], 125) && (i(xe[Le - 1], 37) || i(xe[Le - 1], 125)) && (he = !1), he === !0 ? i(xe[Le], 34) && I === "double" ? xe[Le] = ve : i(xe[Le], 39) && I === "single" && (xe[Le] = Ce) : i(xe[Le], 39) && I === "double" ? xe[Le] = Ce : i(xe[Le], 34) && I === "single" && (xe[Le] = ve), Le = Le + 1;
              while (Le < dt);
            }
            g.token = xe.join(p), h(g);
          }
        }
      }
      function me() {
        if (!(!O && !J && !X))
          return;
        if (N === 0) {
          D = Ht(D, p, !1);
          return;
        }
        let he = [];
        ue = 0, fe = 0, te = D.length;
        do {
          fe = 0;
          do {
            if (D.length > 0 && (de = D[fe][0].split("=")[0], n.markup.attributeSort[ue] === de)) {
              he.push(D[fe]), D.splice(fe, 1), te = te - 1;
              break;
            }
            fe = fe + 1;
          } while (fe < te);
          ue = ue + 1;
        } while (ue < N);
        D = Ht(D, p, !1), D = he.concat(D), te = D.length;
      }
      function be() {
        h(g, "jsx_attribute", {
          token: `${de}={`,
          types: "jsx_attribute_start"
        }), r.external("jsx", ne.slice(1, ne.length - 1)), g.begin = r.count, /\s\}$/.test(ne) ? (ne = ne.slice(0, ne.length - 1), ne = Te.exec(ne)[0], g.lines = ne.indexOf(`
`) < 0 ? 1 : ne.split(`
`).length) : g.lines = 0, g.begin = r.stack.index, g.stack = r.stack.token, g.token = "}", g.types = "jsx_attribute_end", Me();
      }
      function je() {
        if (Xt(D[H][0]))
          g.types = "liquid_attribute_chain", g.token = D[H][0];
        else if (Pt(D[H][0]))
          g.token = D[H][0], g.types = "liquid_attribute_end", g.ender = g.begin;
        else {
          if (ft(D[H][0], !0))
            return g.types = "liquid_attribute_start", g.begin = r.count, g.token = D[H][0], Me(), !0;
          Zt(D[H][0]) ? (g.types = "liquid_attribute_else", g.token = D[H][0]) : (g.types = "attribute", g.token = D[H][0]);
        }
        return Me(), !1;
      }
      if (D.length < 1)
        return S !== !0 ? void 0 : j();
      if (i(D[D.length - 1][0], 47) && (D.pop(), A = A.replace(/>$/, "/>")), fe = D.length, ue = 1, ue < fe)
        do
          de = D[ue - 1][0], i(de[de.length - 1], 61) && D[ue][0].indexOf("=") < 0 && (D[ue - 1][0] = de + D[ue][0], D.splice(ue, 1), fe = fe - 1, ue = ue - 1), ue = ue + 1;
        while (ue < fe);
      if ((N > 0 || n.markup.attributeSort === !0) && me(), g.begin = E, g.stack = M, g.types = "attribute", H < te)
        do {
          if (D[H] === void 0)
            break;
          if (g.lines = D[H][1], D[H][0] = D[H][0].replace(Te, p), O === !0 && /^\/[/*]/.test(D[H][0])) {
            g.types = "comment_attribute", g.token = D[H][0], Me(), H = H + 1;
            continue;
          }
          if (D[H][1] <= 1 && Xt(D[H][0]) && !Ei(D[H][0])) {
            g.types = "liquid_attribute_chain", g.token = D[H][0], Me(), H = H + 1;
            continue;
          }
          fe = D[H][0].indexOf("="), ue = D[H][0].indexOf(Ce), fe < 0 ? (Pt(D[H][0]) ? (g.token = D[H][0], g.types = "liquid_attribute_end", g.ender = g.begin) : ft(D[H][0], !0) ? (g.types = "liquid_attribute_start", g.begin = r.count, g.token = D[H][0]) : Zt(D[H][0]) ? (g.types = "liquid_attribute_else", g.token = D[H][0]) : Pi(D[H][0]) ? (g.types = "liquid_attribute", g.token = D[H][0]) : i(D[H][0], 35) || i(D[H][0], 91) || i(D[H][0], 123) || i(D[H][0], 40) || O === !0 ? g.token = D[H][0] : (g.types = "liquid_attribute", g.token = n.markup.attributeCasing === "preserve" ? D[H][0] : D[H][0].toLowerCase()), Me()) : Et(D[H][0], 6) ? je() : (de = D[H][0].slice(0, fe), n.markup.lineBreakValue === "force-preserve" || n.markup.lineBreakValue === "force-indent" || n.markup.lineBreakValue === "force-align" ? ne = D[H][0][fe + 1] + Z + D[H][0].slice(fe + 2, -1).trim() + Z + D[H][0][D[H][0].length - 1] : ne = D[H][0].slice(fe + 1), n.markup.attributeCasing === "lowercase-name" ? (de = de.toLowerCase(), D[H][0] = de + "=" + ne) : n.markup.attributeCasing === "lowercase-value" ? (ne = ne.toLowerCase(), D[H][0] = de + "=" + ne) : (n.markup.attributeCasing === "lowercase" && (de = de.toLowerCase(), ne = ne.toLowerCase()), D[H][0] = de + "=" + ne), n.correct === !0 && $(ne, 60) && $(ne, 123) && $(ne, 61) && $(ne, 34) && $(ne, 39) && (ne = Ce + ne + Ce), O === !0 && /^\s*{/.test(ne) ? (be(), g.types = "attribute", g.begin = E, g.stack = M) : Et(de, 6) ? je() : (g.types = "attribute", g.token = D[H][0], Me())), H = H + 1;
        } while (H < te);
      if (!S)
        return j();
    }
    function k(S, E) {
      if (S = S.trimStart().split(/\s/)[0], S === "comment" || l.has(S)) {
        let M = c.indexOf("{%", E), I = M;
        o[M + 1].charCodeAt(0) === 45 && (I = M + 1), I = c.indexOf(`end${S}`, I), I > 0 && (I = o.indexOf("}", I), I > 0 && o[I - 1].charCodeAt(0) === 37 && (S !== "comment" ? (P = "ignore", oe = !0, ke = c.slice(t, E + 1), q = c.slice(M, I + 1)) : (P = "comment", ke = c.slice(t, E + 1), M = c.lastIndexOf("{%", I), q = c.slice(M, I + 1))));
      }
    }
    function m(S) {
      r.iterator = t;
      let E = ut({
        chars: o,
        end: d,
        lexer: "markup",
        begin: ke,
        start: t,
        ender: q
      });
      if (A = E[0], t = E[1], ki.test(A))
        if (at.test(A)) {
          let M;
          A.startsWith("<!--") ? M = A.indexOf("-->") + 3 : Ci.test(A) ? M = A.indexOf("%}") + 2 : M = A.indexOf("%}", A.indexOf("%}") + 2) + 2, h(g, [
            {
              token: x(r.iterator, A.slice(0, M)),
              types: "ignore"
            },
            {
              token: A.slice(M).replace(Vt, p),
              types: "ignore",
              lines: ae(M, A)
            }
          ]);
        } else
          h(g, {
            token: x(r.iterator, A),
            types: "ignore"
          }), r.iterator = t + 1;
      else {
        if (i(A[0], 123) && i(A[1], 37) && S === !1) {
          let M = A.indexOf("%}", 2) + 2, I = A.lastIndexOf("{%");
          A = w(A.slice(0, M), ee) + A.slice(M, I) + w(A.slice(I), ee);
        }
        return g.token = A, g.types = "comment", y();
      }
    }
    function v(S) {
      let E = t, M = t + S;
      do {
        if (i(o[M], 62))
          return t = M, c.slice(E, M + 1);
        M = M + 1;
      } while (M < d);
    }
    function L() {
      if (q === "---")
        ke = "---", P = "ignore", V = !0;
      else if (i(o[t], 60))
        if (i(o[t + 1], 123) && (i(o[t + 2], 123) || i(o[t + 2], 37))) {
          let S = v(3);
          we = !0, r.stack.push(["liquid_bad", r.count]), h(g, { token: S, types: "liquid_start_bad" });
          return;
        } else if (i(o[t + 1], 47))
          if (i(o[t + 2], 123) && (i(o[t + 3], 123) || i(o[t + 3], 37))) {
            let S = v(3);
            h(g, { token: S, types: "liquid_end_bad" });
            return;
          } else
            P = "end", q = ">";
        else
          i(o[t + 1], 33) ? (i(o[t + 2], 100) || i(o[t + 2], 68)) && (i(o[t + 3], 111) || i(o[t + 3], 79)) && (i(o[t + 4], 99) || i(o[t + 4], 67)) && (i(o[t + 5], 116) || i(o[t + 5], 84)) && (i(o[t + 6], 121) || i(o[t + 6], 89)) && (i(o[t + 7], 112) || i(o[t + 7], 80)) && (i(o[t + 8], 101) || i(o[t + 8], 69)) ? (q = ">", P = "doctype", V = !0) : i(o[t + 2], 45) && i(o[t + 3], 45) ? (q = "-->", ke = "<!--", P = "comment") : i(o[t + 2], 91) && o[t + 3].charCodeAt(0) === 67 && // C
          o[t + 4].charCodeAt(0) === 68 && // D
          o[t + 5].charCodeAt(0) === 65 && // A
          o[t + 6].charCodeAt(0) === 84 && // T
          o[t + 7].charCodeAt(0) === 65 && // A
          i(o[t + 8], 91) && (q = "]]>", P = "cdata", V = !0) : i(o[t + 1], 63) ? (q = "?>", o[t + 2].charCodeAt(0) === 120 && // x
          o[t + 3].charCodeAt(0) === 109 && // m
          o[t + 4].charCodeAt(0) === 109 ? (P = "xml", se = !0) : (V = !0, P = "liquid")) : i(o[t + 1], 112) && //   p
          i(o[t + 2], 114) && //   r
          i(o[t + 3], 101) && // e
          (i(o[t + 4], 62) || le(o[t + 4])) ? (q = "</pre>", P = "ignore", V = !0) : (se = !0, q = ">");
      else if (i(o[t], 123)) {
        if (O) {
          W = !0, we = !0, r.stack.push(["script", r.count]), h(g, { token: "{", types: "script_start" });
          return;
        }
        if (i(o[t + 1], 123))
          V = !0, q = "}}", P = "liquid";
        else if (i(o[t + 1], 37)) {
          V = !0, q = "%}", P = "liquid";
          let S = o.indexOf("}", t + 2);
          if (i(o[S - 1], 37)) {
            let E = c.slice(t + 2, S - 1);
            if (i(E, 45) ? (ke = "{%-", E = E.slice(1).trimStart()) : (ke = "{%", E = E.trimStart()), ee = E.slice(0, E.search(/[\s%}-]/)), i(E[E.length - 1], 45) ? (q = "-%}", E = E.slice(0, E.length - 1).trimEnd()) : (q = "%}", E = E.trimEnd()), k(E, S), i(E, 35))
              return P = "comment", q = "%}", _ = q.charAt(q.length - 1), m(!0);
          } else
            V = !0, q = "%}", P = "liquid";
        } else
          V = !0, q = o[t + 1] + "}", P = "liquid";
      }
      return V !== !0 && n.markup.preserveAttribute === !0 && (V = !0), we ? y() : (_ = q.charAt(q.length - 1), P === "comment" && (i(o[t], 60) || i(o[t], 123) && i(o[t + 1], 37)) ? m() : t < d ? pe() : y());
    }
    function j() {
      if (n.wrap > 0 && O === !0) {
        let S = 0, E = r.count, M = 0;
        if (s.types[E].indexOf("attribute") > -1) {
          do
            S = S + s.token[E].length + 1, E = E - 1;
          while (s.lexer[E] !== "markup" || s.types[E].indexOf("attribute") > -1);
          s.lines[E] === 1 && (S = S + s.token[E].length + 1);
        } else
          s.lines[E] === 1 && (S = s.token[E].length + 1);
        if (M = E - 1, S > 0 && s.types[M] !== "script_end")
          if (s.types[M].indexOf("attribute") > -1) {
            do
              S = S + s.token[M].length + 1, M = M - 1;
            while (s.lexer[M] !== "markup" || s.types[M].indexOf("attribute") > -1);
            s.lines[M] === 1 && (S = S + s.token[M].length + 1);
          } else
            s.lines[M] === 1 && (S = s.token[M].length + 1);
      }
      r.lineOffset = 0;
    }
    function pe() {
      let S = [], E = {
        pipes: [],
        fargs: [],
        targs: [],
        logic: []
      }, M = 0, I = 0, H = p, fe = 0, ue = 0, de = 0, ne = 0, te = p, Me = p, me = 0, be = !1, je = !1, he = !1, Le = !1, We = !1, xe = NaN, ce = [];
      function dt() {
        if ($e(S, 44)) {
          if (ee === "when" && E.logic.push(S.length - 1), n.correct === !0 && /^,\s*-?[%}]}/.test(c.slice(t)))
            return S.pop(), t = t + 1, !0;
          xe === 44 ? E.fargs[E.fargs.length - 1].push(S.length - 1) : xe === 58 ? (E.fargs[E.fargs.length - 1][0] += 1, E.fargs[E.fargs.length - 1].push(S.length - 1), xe = 44) : E.targs.push(S.length - 1);
        } else
          $e(S, 124) ? (E.pipes.push(S.length - 1), xe = 124) : $e(S, 58) && xe === 124 && (E.fargs.push([S.length - 1]), xe = 58);
        if (i(o[t], 10) && ee !== "liquid" && je === !1 && n.liquid.preserveInternal === !1 && S.length > 3 && !(i(o[t + 1], 45) && i(o[t + 2], 37) && i(o[t + 3], 125) || i(o[t + 1], 37) && i(o[t + 2], 125)) ? S.pop() : n.liquid.normalizeSpacing === !0 && ($(o[t], 32) && (Je(S, 39) || Je(S, 34)) ? $(o[t], 44) && $(o[t], 93) ? (S.splice(S.length - 1, 1, Y, o[t]), $(o[t + 1], 32) && $(o[t + 1], 61) && $(o[t + 1], 125) && S.push(Y)) : $(o[t + 1], 32) && S.push(Y) : i(o[t], 32) && i(o[t - 1], 93) ? S.pop() : S.length > 3 && i(o[t + 1], 10) && $(o[t + 2], 32) ? S.push(Y) : i(o[t], 32) && i(o[t + 1], 32) ? S.pop() : Je(S, 93) && $e(S, 32) && $(o[t], 32) && $(o[t], 44) && $(o[t], 46) ? S.splice(S.length - 1, 1, Y, o[t]) : Je(S, 32) && i(o[t], 32) && i(o[t + 1], 32) ? S.pop() : i(o[t], 44) && $(o[t + 1], 32) ? S.push(Y) : i(o[t], 58) && $(o[t + 1], 32) ? S.push(Y) : i(o[t], 32) && Je(S, 46) || ai(S, 91, 32) ? S.pop() : $(o[t], 32) && i(o[t + 1], 124) ? S.push(Y) : i(o[t], 124) && $(o[t + 1], 32) ? S.push(Y) : i(o[t], 32) && (i(o[t + 1], 46) || i(o[t + 1], 93) || i(o[t + 1], 91) || i(o[t + 1], 58) || i(o[t + 1], 44)) ? S.pop() : ee === "assign" && ($(o[t], 32) && i(o[t + 1], 61) || i(o[t], 61) && $(o[t + 1], 32)) ? S.push(Y) : (ee === "if" || ee === "unless" || ee === "elsif") && (($(o[t], 32) || i(o[t], 10)) && (i(o[t + 1], 33) || i(o[t + 1], 60) || i(o[t + 1], 62) || i(o[t + 1], 61) && i(o[t + 2], 61)) ? S.push(Y) : i(o[t], 61) && ($(o[t + 1], 32) || i(o[t + 1], 10)) && (i(o[t - 1], 61) || i(o[t - 1], 60) || i(o[t - 1], 62) || i(o[t - 1], 33)) ? S.push(Y) : $(o[t + 1], 32) && $(o[t + 1], 61) && (i(o[t], 60) || i(o[t], 62)) && S.push(Y))), le(o[t - 1])) {
          if (H = c.slice(t), ee === "if" || ee === "elsif" || ee === "unless") {
            if (le(o[t + 2]) && H.startsWith("or"))
              return E.logic.push(S.length - 1), S.pop(), S.push(H.slice(0, 2)), t = t + 2, !0;
            if (le(o[t + 3]) && H.startsWith("and"))
              return E.logic.push(S.length - 1), S.pop(), S.push(H.slice(0, 3)), t = t + 3, !0;
            if (le(o[t + 8]) && H.startsWith("contains"))
              return E.logic.push(S.length - 1), S.pop(), S.push(H.slice(0, 8)), t = t + 8, !0;
          } else if (ee === "when" && le(o[t + 2]) && H.startsWith("or"))
            return E.logic.push(S.length - 1), S.pop(), S.push(H.slice(0, 2)), t = t + 2, !0;
        }
        if (i(S[S.length - 1], 44) && i(S[S.length - 2], 44))
          return Ye(
            114,
            S.join(p),
            _e(S.join(p))
          );
        je = !1;
      }
      function Ge(ri) {
        let Ct, qe = p;
        if (ri === !0 ? (qe = ce.join(p), Ct = F(qe), te = p, Ct[0] === "data-esthetic-ignore" && (oe = !0)) : (qe = ce.join(p), (O === !1 || O && Qt(qe, 125)) && (qe = qe.replace(et, Y)), Ct = F(qe), Ct[0] === "data-esthetic-ignore" && (oe = !0), O && i(ce[0], 123) && i(ce[ce.length - 1], 125) && (me = 0)), i(qe[0], 123) && i(qe[1], 37) && (X = !0), qe = qe.replace(/^\u0020/, p).replace(/\u0020$/, p), ce = qe.replace(/\r\n/g, Z).split(Z), ce.length < 1 && (ce[0] = ce[0].replace(Te, p)), qe = w(ce.join(r.crlf), ee), n.markup.stripAttributeLines === !0 && ne >= 1 && (ne = 1), D.length > 0) {
          let Ve = D.length - 1;
          u === 0 && (i(qe, 61) || i(qe, 45)) && (D[Ve][0] = D[Ve][0] + qe, D[Ve][1] = ne, qe = p);
        }
        if (ri === !1 && (ft(qe) && (u = u + 1), Pt(qe) && (u = u - 1)), qe !== p && qe !== Y && D.push([qe, ne]), D.length > 0) {
          let [Ve] = D[D.length - 1];
          if (Ve.indexOf("=\u201C") > 0)
            return Ye(103, Ve);
          if (Ve.indexOf("=\u201D") > 0)
            return Ye(103, Ve);
        }
        ce = [], ne = i(o[t], 10) ? 1 : 0;
      }
      if (!r.error) {
        do {
          if (i(o[t], 10) && (ne = r.lines(t, ne)), ke === "---" && q === "---" && P === "ignore") {
            if (S.push(o[t]), t > 3 && i(o[t], 45) && i(o[t - 1], 45) && i(o[t - 2], 45))
              break;
            t = t + 1;
            continue;
          }
          if (V === !0 || le(o[t]) === !1 && $(te, 125) || i(te, 125)) {
            if (S.push(o[t]), be === !1 && i(o[t - 1], 123) && (i(o[t], 123) || i(o[t], 37)))
              be = !0;
            else if (be === !0 && i(o[t], 125)) {
              if (i(o[t - 1], 125) || i(o[t - 1], 37))
                be = !1;
              else if ((i(o[t - 2], 125) || i(o[t - 2], 37)) && le(o[t - 1]))
                return Ye(111, S.join(p));
            } else if (be === !0 && i(o[t], 10) && n.liquid.preserveInternal === !1 && (n.liquid.delimiterPlacement === "preserve" || n.liquid.delimiterPlacement === "consistent")) {
              if (i(o[t - 1], 45) && i(o[t - 3], 123) && (i(o[t - 2], 123) || i(o[t - 2], 37)) || i(o[t - 2], 123) && (i(o[t - 1], 123) || i(o[t - 1], 37)))
                je = !0;
              else if (/^\s*-?[%}]}/.test(c.slice(t)) === !0) {
                for (; le(o[t]) === !0; )
                  t = t + 1, i(o[t], 10) && (ne = r.lines(t, ne));
                S.push(o[t]), je = !0;
              }
            }
            if (P === "end" && S.length > 2 && i(S[0], 60) && i(S[1], 47) && (i(S[S.length - 1], 47) || i(S[S.length - 1], 60))) {
              if (n.correct)
                S.pop(), S.push(">");
              else
                return Ye(106, S.join(p));
              break;
            }
            if (i(S[0], 60) && i(S[1], 62) && i(q, 62))
              return h(g, "(empty)", {
                token: "<>",
                types: "start"
              });
            if (i(S[0], 60) && i(S[1], 47) && i(S[2], 62) && i(q, 62))
              return g.token = "</>", g.token = "end", h(g);
          }
          if (P === "cdata" && i(o[t], 62) && i(o[t - 1], 93) && $(o[t - 2], 93))
            return Ye(103, S.join(p));
          if (P === "comment") {
            if (te = p, o[t] === _ && S.length > q.length + 1) {
              if (I = S.length, M = q.length - 1, M > -1)
                do {
                  if (I = I - 1, $(S[I], q.charCodeAt(M)))
                    break;
                  M = M - 1;
                } while (M > -1);
              if (M < 0)
                break;
            }
          } else if (te === p) {
            if (i(S[0], 60) && i(S[1], 33) && P !== "cdata") {
              if (P === "doctype" && i(o[t], 62))
                break;
              if (i(o[t], 91)) {
                if (i(o[t + 1], 60)) {
                  P = "start";
                  break;
                }
                if (le(o[t + 1]))
                  do
                    t = t + 1, i(o[t], 10) && (ne = r.lines(t, ne));
                  while (t < d - 1 && le(o[t + 1]));
                if (i(o[t + 1], 60)) {
                  P = "start";
                  break;
                }
              }
            }
            if (O && (i(o[t], 123) ? me = me + 1 : i(o[t], 125) && (me = me - 1)), i(o[t], 60) && se === !0 && V === !1 && S.length > 1 && />{2,3}/.test(q) === !1) {
              r.error = `Invalid structure detected ${o.slice(t, t + 8).join(p)}`;
              break;
            }
            if (le(o[t]) === !1 && he === !0 && o[t] !== _) {
              if (T = 0, he = !1, te = Me, S.pop(), t < d)
                do {
                  if (i(o[t], 10) && We === !1 && (ne = r.lines(t, ne)), n.markup.preserveAttribute === !0 ? S.push(o[t]) : ce.push(o[t]), ($(te, 34) || $(te, 39)) && (i(o[t - 1], 123) && (i(o[t], 37) || i(o[t], 123)) ? be = !0 : i(o[t], 125) && (i(o[t - 1], 125) || i(o[t - 1], 37)) && (be = !1)), O === !1 && We === !1 && be === !0 && n.markup.preserveAttribute === !1)
                    for (; t < d; ) {
                      if (t = t + 1, i(o[t], 10) && (ne = r.lines(t, ne)), i(ce[0], 61) && (i(ce[1], 123) || i(ce[1], 37)) && (i(ce[ce.length - 2], 125) || i(ce[ce.length - 2], 37)) && i(ce[ce.length - 1], 125)) {
                        be = !1, te = p, Ge(!1);
                        break;
                      }
                      if (i(ce[0], 61) && $(ce[1], 123)) {
                        be = !1, te = p, Ge(!1);
                        break;
                      }
                      if (ce.push(o[t]), i(ce[0], 61) && i(o[t + 1], 62)) {
                        be = !1, D[D.length - 1][0] += ce.join(p), ce = [], te = p;
                        break;
                      }
                      if ($(ce[0], 61) && i(o[t], 125) && (i(o[t - 1], 125) || i(o[t - 1], 37))) {
                        be = !1, te = p, Ge(!1);
                        break;
                      }
                    }
                  if (O === !1 && (i(o[t], 60) || i(o[t], 62)) && (te === p || i(te, 62))) {
                    if (te === p && i(o[t], 60))
                      te = ">", fe = 1;
                    else if (i(te, 62)) {
                      if (i(o[t], 60))
                        fe = fe + 1;
                      else if (i(o[t], 62) && (fe = fe - 1, fe === 0)) {
                        te = p, T = 0, Ge(!1);
                        break;
                      }
                    }
                  } else if (te === p) {
                    if (o[t + 1] === _) {
                      ($e(ce, 47) || $e(ce, 63) && P === "xml") && (ce.pop(), V === !1 || S.pop(), t = t - 1), ce.length > 0 && Ge(!1);
                      break;
                    }
                    if (O === !1 && i(o[t], 123) && i(o[t - 1], 61) ? te = "}" : i(o[t], 34) || i(o[t], 39) ? (te = o[t], We === !1 && be === !1 && (We = !0), i(o[t - 1], 61) && (i(o[t + 1], 60) || i(o[t + 1], 123) && i(o[t + 2], 37) || le(o[t + 1]) && $(o[t - 1], 61)) && (T = t)) : i(o[t], 40) ? (te = ")", de = 1) : O ? (i(o[t - 1], 61) || le(o[t - 1])) && i(o[t], 123) ? (te = "}", ue = 1) : i(o[t], 47) && (i(o[t + 1], 42) ? te = "*/" : i(o[t + 1], 47) && (te = Z)) : i(S[0], 123) && i(o[t], 123) && (i(o[t + 1], 123) || i(o[t + 1], 37)) && (te = i(o[t + 1], 123) ? "}}" : o[t + 1] + "}"), le(o[t]) && te === p) {
                      if (i(ce[ce.length - 2], 61) && (M = t + 1, M < d))
                        do {
                          if (le(o[M]) === !1) {
                            (i(o[M], 34) || i(o[M], 39)) && (t = M - 1, Le = !0, ce.pop());
                            break;
                          }
                          M = M + 1;
                        } while (M < d);
                      if (Le === !0)
                        Le = !1;
                      else if (me === 0 || me === 1 && i(ce[0], 123)) {
                        ce.pop(), ce.length > 0 && Ge(!1), he = !0;
                        break;
                      }
                    }
                  } else if (i(o[t], 40) && i(te, 41))
                    de = de + 1;
                  else if (i(o[t], 41) && i(te, 41)) {
                    if (de = de - 1, de === 0 && (te = p, i(o[t + 1], q.charCodeAt(0)))) {
                      Ge(!1);
                      break;
                    }
                  } else if (O === !0 && (i(te, 125) || i(te, 10) && i(o[t], 10) || i(te, 42) && i(o[t - 1], 42) && i(o[t], 47))) {
                    if (i(o[t], 96)) {
                      t = t + 1;
                      do {
                        if (ce.push(o[t]), i(o[t], 96))
                          break;
                        t = t + 1;
                      } while (t < o.length);
                    }
                    if (i(te, 125)) {
                      if (i(o[t], 125) && o[t] !== te)
                        ue = ue + 1;
                      else if (o[t] === te && (ue = ue - 1, ue === 0)) {
                        me = 0, te = p, A = ce.join(p), n.markup.preserveAttribute === !1 && (O ? /^\s*$/.test(A) || D.push([A, ne]) : (A = A.replace(et, Y), A !== Y && D.push([A, ne]))), ce = [], ne = 1;
                        break;
                      }
                    } else {
                      Me = p, J = !0, A = ce.join(p), A !== Y && D.push([A, ne]), ce = [], ne = i(te, 10) ? 2 : 1, te = p;
                      break;
                    }
                  } else if (i(o[T - 1], 61) && i(o[t], 123) && i(o[t + 1], 37) && (i(te, 34) || i(te, 39)))
                    te = te + "{%", T = 0;
                  else if (i(o[t - 1], 37) && i(o[t], 125) && (te === '"{%' || te === "'{%"))
                    te = te[0], T = 0;
                  else if (i(o[t], 60) && i(q, 62) && i(o[T - 1], 61) && (i(te, 34) || i(te, 39)))
                    te = te + "<", T = 0;
                  else if (i(o[t], 62) && (te === '"<' || te === "'<"))
                    te = te.charAt(0), T = 0;
                  else if (T === 0 && $(te, 62) && (te.length < 2 || $(te, 34) && $(te, 39))) {
                    if (I = 0, M = te.length - 1, M > -1)
                      do {
                        if ($(o[t - I], te.charCodeAt(M)))
                          break;
                        I = I + 1, M = M - 1;
                      } while (M > -1);
                    if (M < 0 && be === !1 && We === !0 && (We = !1, Ge(!0), o[t + 1] === _))
                      break;
                    M === 0 && i(o[t], 62);
                  } else
                    T > 0 && le(o[t]) === !1 && (T = 0);
                  t = t + 1;
                } while (t < d);
            } else if (i(q, 10) === !1 && (i(o[t], 34) || i(o[t], 39)))
              te = o[t];
            else if (t > 0 && be === !0 && $(te, 34) && $(te, 39)) {
              if (dt() === !0)
                continue;
            } else if (P !== "comment" && $(q, 10) && i(o[t], 60) && i(o[t + 1], 33) && i(o[t + 2], 45) && i(o[t + 3], 45) && s.types[r.count] !== "conditional")
              te = "-->";
            else if (i(o[t], 123) && $(S[0], 123) && $(q, 10) && (i(o[t + 1], 123) || i(o[t + 1], 37))) {
              if (i(o[t + 1], 123))
                te = "}}";
              else if (te = o[t + 1] + "}", ce.length < 1 && (D.length < 1 || le(o[t - 1]))) {
                S.pop();
                do
                  i(o[t], 10) && (ne = ne + 1), ce.push(o[t]), t = t + 1;
                while (t < d && o[t - 1] + o[t] !== te);
                ce.push("}"), D.push([ce.join(p), ne]), ce = [], ne = 1, te = p;
              }
              te === q && (te = p);
            } else if (se && $(q, 10) && $(o[t - 1], 60) && le(o[t]))
              he = !0;
            else if (se && O && i(o[t], 47) && (i(o[t + 1], 42) || i(o[t + 1], 47)))
              he = !0, S[S.length - 1] = Y, Me = i(o[t + 1], 42) ? "*/" : Z, ce.push(o[t]);
            else if (be === !1 && (o[t] === _ || i(q, 10) && i(o[t + 1], 60)) && (S.length > q.length + 1 || i(S[0], 93)) && (O === !1 || me === 0)) {
              if (i(q, 10)) {
                if (le(S[S.length - 1]))
                  do
                    S.pop(), t = t - 1;
                  while (le(S[S.length - 1]));
                break;
              }
              if (I = S.length, M = q.length - 1, M > -1)
                do {
                  if (I = I - 1, S[I] !== q.charAt(M))
                    break;
                  M = M - 1;
                } while (M > -1);
              if (M < 0) {
                i(S[I], 62) && i(o[t], 62) && i(o[t - 1], 125) && le(o[t + 1]) && D.length > 0 && D[D.length - 1][1] === 0 && (D[D.length - 1][1] = i(o[t + 1], 32) ? 1 : 2);
                break;
              }
            }
          } else if (i(o[t], te.charCodeAt(te.length - 1)) && $(o[t - 1], 92) && (O === !0 && i(q, 125) && a(t) === !1 || O === !1 || $(q, 125))) {
            if (I = 0, M = te.length - 1, M > -1)
              do {
                if ($(o[t - I], te.charCodeAt(M)))
                  break;
                I = I + 1, M = M - 1;
              } while (M > -1);
            M < 0 && (te = p);
          }
          t = t + 1;
        } while (t < d);
        if (T = 0, ee || (ee = _e(S.join(p))), oe === !1)
          if (P === "liquid") {
            if (A = Bi(S, ee, E, n), n.liquid.normalizeSpacing && (A = A.replace(/\] \[/g, "][").replace(/(\])(\w+:)/, "$1 $2"), ee === "render" && A.indexOf("]as") > -1 && (A = A.replace(/\]as(?=\s+)/, "] as"))), ee === "liquid")
              return Be();
          } else
            A = S.join(p);
        else
          A = S.join(p);
        return ee === "xml" ? R = "xml" : R === p && ee === "html" && (R = "html"), g.token = A, g.types = P, V === !1 && O === !1 && (A = A.replace(et, Y)), y();
      }
    }
    return L();
  }
  function G() {
    let q = [], g = t, A = O === !0 && i(s.token[r.count], 123), _ = "([{!=,;.?:&<>", P = p, ee = r.lineOffset, ke = p;
    W === !0 && (A === !0 ? ke = "script" : r.stack.index > -1 ? ke = _e(s.token[r.stack.index]) : ke = _e(s.token[s.begin[r.count]]));
    let we = {
      begin: r.stack.index,
      ender: -1,
      lexer: "markup",
      lines: ee,
      stack: _e(r.stack.token) || "global",
      token: p,
      types: "content"
    };
    function oe() {
      return s.types[r.count] === "liquid_start" && s.token[r.count].indexOf("<!") === 0 && s.token[r.count].indexOf("<![") < 0 && s.token[r.count].charCodeAt(s.token[r.count].length - 1) === 91;
    }
    function T() {
      let X = t - 1, V = 0;
      if ($(o[t - 1], 92))
        return !1;
      if (X > -1)
        do {
          if ($(o[X], 92))
            break;
          V = V + 1, X = X - 1;
        } while (X > -1);
      return V % 2 === 1;
    }
    if (t < d) {
      let X = p, V = p, se = p, D = 0;
      do {
        if (i(o[t], 10) && (ee = r.lines(t, ee)), W === !0) {
          if (s.types[r.count] === "liquid_start") {
            let re = `end${ke}`, ge = c.indexOf(`end${ke}`, t);
            if (ge > -1) {
              let Be = o.lastIndexOf("{", ge), Se = o.indexOf("}", ge + re.length) + 1, Q = o.slice(Be, Se).join(p);
              if (ji(re).test(Q)) {
                ee = 1, se = o.slice(t, Be).join(p), r.external(f, se);
                let U = Se;
                do
                  i(o[U], 10) && (ee = ee + 1);
                while (le(o[U--]));
                h(we, {
                  token: w(Q),
                  types: "liquid_end",
                  lines: ee
                }), t = Se;
                break;
              }
            }
          }
          if (V === p) {
            if (i(o[t], 47))
              i(o[t + 1], 42) ? V = "*" : i(o[t + 1], 47) ? V = "/" : !O && ke === "script" && $(o[t - 1], 60) && _.indexOf(o[t - 1]) > -1 && (V = "r");
            else if (T() === !1 && (i(o[t], 34) || i(o[t], 39) || i(o[t], 96)))
              V = o[t];
            else if (i(o[t], 123) && A === !0)
              D = D + 1;
            else if (i(o[t], 125) && A === !0) {
              if (D === 0) {
                se = q.join(p).replace(ot, p).replace(Te, p), r.external(f, se), r.stack.update(r.stack.index + 1), s.types[r.count] === "end" && s.lexer[s.begin[r.count] - 1] === "script" && (h(we, {
                  lexer: "script",
                  types: "separator",
                  token: n.correct === !0 ? ";" : "x;"
                }), we.lexer = "markup"), h(we, {
                  token: "}",
                  types: "script_end"
                }), r.stack.pop();
                break;
              }
              D = D - 1;
            }
            if (ke === "script") {
              if (X = o.slice(t, t + 9).join(p).toLowerCase(), X === "</script") {
                if (se = q.join(p).trimEnd(), q.length < 1)
                  break;
                yt.test(se) && xt.test(se) ? (h(we, { token: "<!--", types: "comment" }), se = se.replace(yt, p).replace(xt, p), r.external("javascript", se), h(we, { token: "-->" })) : r.external(f, se);
                break;
              }
            } else if (ke === "style" && i(o[t + 1], 60) && i(o[t + 2], 47) && (X = o.slice(t + 1, t + 8).join(p).toLowerCase(), X === "</style")) {
              if (se = q.join(p).trimEnd(), i(se, 62) && (se = se.slice(1)), q.length < 1)
                break;
              yt.test(se) && xt.test(se) ? (h(we, { token: "<!--", types: "comment" }), se = se.replace(yt, p).replace(xt, p), r.external("css", se), h(we, { token: "-->" })) : r.external(f, se);
              break;
            }
          } else
            V === o[t] && T() === !1 && (i(V, 34) || i(V, 39) || i(V, 96) || i(V, 42) && i(o[t + 1], 47)) ? V = p : i(V, 96) && i(o[t], 36) && i(o[t + 1], 123) && T() === !1 ? V = "}" : i(V, 125) && i(o[t], 125) && T() === !1 ? V = "`" : i(V, 47) && (i(o[t], 10) || i(o[t], 13)) ? V = p : V === "r" && i(o[t], 47) && T() === !1 ? V = p : i(V, 47) && i(o[t], 62) && i(o[t - 1], 45) && i(o[t - 2], 45) && (X = c.slice(t + 1, t + 11).toLowerCase(), X = X.slice(0, X.length - 2), ke === "script" && X === "</script" && (V = p), X = X.slice(0, X.length - 1), ke === "style" && X === "</style" && (V = p));
        }
        if (oe() === !0 && i(o[t], 93)) {
          t = t - 1, ee = 0, P = q.join(p).replace(Te, p), h(we, { token: P });
          break;
        }
        if (W === !1 && q.length > 0 && (i(o[t], 60) && $(o[t + 1], 61) && Ee(o[t + 1]) === !1 && le(o[t + 1]) === !1 || i(o[t], 91) && i(o[t + 1], 37) || i(o[t], 123) && (O === !0 || i(o[t + 1], 123) || i(o[t + 1], 37)))) {
          if (t = t - 1, ee = 0, P = r.stack.token === "comment" ? q.join(p) : q.join(p).replace(Te, p), we.token = P, n.wrap > 0 && n.markup.preserveText === !1) {
            let Se = function() {
              if (i(P[re], 32)) {
                Be.push(P.slice(0, re)), P = P.slice(re + 1), ge = P.length, re = n.wrap;
                return;
              }
              do
                re = re - 1;
              while (re > 0 && $(P[re], 32));
              if (re > 0)
                Be.push(P.slice(0, re)), P = P.slice(re + 1), ge = P.length, re = n.wrap;
              else {
                re = n.wrap;
                do
                  re = re + 1;
                while (re < ge && $(P[re], 32));
                Be.push(P.slice(0, re)), P = P.slice(re + 1), ge = P.length, re = n.wrap;
              }
            };
            let re = n.wrap, ge = P.length, Be = [];
            if (s.token[s.begin[r.count]] === "<a>" && s.token[s.begin[s.begin[r.count]]] === "<li>" && s.lines[s.begin[r.count]] === 0 && r.lineOffset === 0 && P.length < n.wrap) {
              h(we);
              break;
            }
            if (ge < n.wrap) {
              h(we);
              break;
            }
            if (r.lineOffset < 1 && r.count > -1) {
              let Q = r.count;
              do {
                if (re = re - s.token[Q].length, s.types[Q].indexOf("attribute") > -1 && (re = re - 1), s.lines[Q] > 0 && s.types[Q].indexOf("attribute") < 0)
                  break;
                Q = Q - 1;
              } while (Q > 0 && re > 0);
              re < 1 && (re = P.indexOf(Y));
            }
            P = q.join(p).replace(ot, p).replace(Te, p).replace(et, Y);
            do
              Se();
            while (re < ge);
            P !== p && $(P, 32) && Be.push(P), P = Be.join(r.crlf), P = p + P + p;
          } else {
            let re = P.indexOf(Z);
            re > -1 && (h(we, { token: P.slice(0, re) }), P = P.slice(re), Vt.test(P) ? we.lines = 1 : (we.lines = 2, P = P.replace(ot, p)));
          }
          ee = 0, h(we, { token: P });
          break;
        }
        q.push(o[t]), t = t + 1;
      } while (t < d);
    }
    if (t > g && t < d)
      if (le(o[t])) {
        let X = t;
        r.lineOffset = r.lineOffset + 1;
        do
          i(o[X], 10) && (r.lineNumber = r.lineNumber + 1, r.lineOffset = r.lineOffset + 1), X = X - 1;
        while (X > g && le(o[X]));
      } else
        r.lineOffset = 0;
    else
      (t !== g || t === g && W === !1) && (P = q.join(p).replace(Te, p), ee = 0, we.token !== P && (h(we, { token: P }), r.lineOffset = 0));
    W = !1;
  }
  function ie() {
    r.lineOffset = 1;
    do {
      if (i(o[t], 10) && (r.lineIndex = t, r.lineOffset = r.lineOffset + 1, r.lineNumber = r.lineNumber + 1), le(o[t + 1]) === !1)
        break;
      t = t + 1;
    } while (t < d);
  }
  (r.language === "html" || r.language === "liquid") && (R = "html");
  do {
    if (r.error)
      return s;
    if (le(o[t]) ? ie() : W === !1 ? i(o[t], 60) ? B(p) : i(o[t], 123) && (O || i(o[t + 1], 123) || i(o[t + 1], 37)) ? B(p) : i(o[t], 45) && i(o[t + 1], 45) && i(o[t + 2], 45) ? B("---") : G() : G(), t = t + 1, t === d && r.pairs.size > 0 && r.pairs.has(r.stack.index)) {
      console.log(r.pairs);
      let q = r.pairs.get(r.stack.index);
      q.type === 2 && Rt(105, q);
    }
  } while (t < d);
  return s;
}

// src/lexers/script.ts
function Wi() {
  let { data: e, references: s, rules: n, source: c } = r, O = r.language === "json" ? n.json : n.script, l = Re(c) ? c : c.split(p), N = l.length, o = [], d = [], b = [], t = [0, p], f = [!1], W = { count: [], index: [], word: [] }, R = -1, u = 0, h = p, w = p, x = [], ae = 0, z = -1, a = -1, C = [], F, B, G, ie = [
    "autoescape",
    "block",
    "capture",
    "case",
    "comment",
    "embed",
    "filter",
    "for",
    "form",
    "if",
    "macro",
    "paginate",
    "raw",
    "sandbox",
    "spaceless",
    "tablerow",
    "unless",
    "verbatim"
  ];
  function q() {
    W.count.pop(), W.index.pop(), W.word.pop(), R = R - 1;
  }
  function g(k = p) {
    let m = {
      begin: r.stack.index,
      ender: -1,
      lexer: "script",
      lines: r.lineOffset,
      stack: r.stack.token,
      token: h,
      types: w
    };
    r.push(e, m, k);
  }
  function A(k, m) {
    let v = m === !0 ? u : u + 1, L = p;
    if ((typeof k != "number" || k < 1) && (k = 1), i(l[u], 47) && (i(l[u + 1], 47) ? L = Z : i(l[u + 1], 42) && (L = "/")), v < N)
      do {
        if (le(l[v]) === !1) {
          if (i(l[v], 47) && (L === p ? i(l[v + 1], 47) ? L = Z : i(l[v + 1], 42) && (L = "/") : i(L, 47) && i(l[v - 1], 42) && (L = p)), L === p && l[v - 1] + l[v] !== "*/")
            return l.slice(v, v + k).join(p);
        } else
          i(L, 10) && i(l[v], 10) && (L = p);
        v = v + 1;
      } while (v < N);
    return p;
  }
  function _(k) {
    let m = k;
    do
      k = k - 1;
    while (i(l[k], 92) && k > 0);
    return (m - k) % 2 === 1;
  }
  function P(k) {
    let m = A(1, !1), v = r.stack.length === 0 ? p : r.stack.token, L = {
      begin: e.begin[r.count],
      ender: e.begin[r.count],
      lexer: e.lexer[r.count],
      lines: e.lines[r.count],
      stack: e.stack[r.count],
      token: e.token[r.count],
      types: e.types[r.count]
    };
    if (at.test(h) || w === "start" || w === "type_start" || r.language === "json" || i(m, 123) || i(L.token, 59) || i(L.token, 44) || L.stack === "class" || L.stack === "map" || L.stack === "attribute" || e.types[L.begin - 1] === "generic" || v === "initializer" || i(L.token, 125) && e.stack[L.begin - 1] === "global" && e.types[L.begin - 1] !== "operator" && L.stack === e.stack[r.count - 1] || L.stack === "array" && $(L.token, 93) || i(e.token[e.begin[r.count]], 123) && L.stack === "data_type" || L.types !== void 0 && L.types.indexOf("liquid") > -1 && L.types.indexOf("template_string") < 0 || i(m, 59) && k === !1 || e.lexer[r.count - 1] !== "script" && (u < N && N === c.length - 1 || N < c.length - 1))
      return;
    let j = 0;
    if (i(L.token, 125) && (L.stack === "function" || L.stack === "if" || L.stack === "else" || L.stack === "for" || L.stack === "do" || L.stack === "while" || L.stack === "switch" || L.stack === "class" || L.stack === "try" || L.stack === "catch" || L.stack === "finally" || L.stack === "block")) {
      if (L.stack === "function" && (e.stack[L.begin - 1] === "data_type" || e.types[L.begin - 1] === "type")) {
        j = L.begin;
        do
          j = j - 1;
        while (j > 0 && $(e.token[j], 41) && e.stack[j] !== "arguments");
        j = e.begin[j];
      } else
        j = e.begin[L.begin - 1];
      if (i(e.token[j], 40)) {
        if (j = j - 1, e.token[j - 1] === "function" && (j = j - 1), e.stack[j - 1] === "object" || e.stack[j - 1] === "switch" || $(e.token[j - 1], 61) && $(e.token[j - 1], 58) && e.token[j - 1] !== "return")
          return;
      } else
        return;
    }
    if (!(L.types === "comment" || v === "method" || v === "paren" || v === "expression" || v === "array" || v === "object" || v === "switch" && L.stack !== "method" && i(e.token[e.begin[r.count]], 40) && e.token[e.begin[r.count] - 1] !== "return" && e.types[e.begin[r.count] - 1] !== "operator") && !(e.stack[r.count] === "expression" && (e.token[e.begin[r.count] - 1] !== "while" || e.token[e.begin[r.count] - 1] === "while" && e.stack[e.begin[r.count] - 2] !== "do")) && !(m !== p && "=<>+*?|^:&%~,.()]".indexOf(m) > -1 && k === !1)) {
      if (L.types === "comment") {
        j = r.count;
        do
          j = j - 1;
        while (j > 0 && e.types[j] === "comment");
        if (j < 1)
          return;
        L.token = e.token[j], L.types = e.types[j], L.stack = e.stack[j];
      }
      L.token === void 0 || L.types === "start" || L.types === "separator" || L.types === "operator" && L.token !== "++" && L.token !== "--" || L.token === "x}" || L.token === "var" || L.token === "let" || L.token === "const" || L.token === "else" || L.token.indexOf("#!/") === 0 || L.token === "instanceof" || L.stack === "method" && (e.token[L.begin - 1] === "function" || e.token[L.begin - 2] === "function") || (O.variableList === "list" && (W.index[R] = r.count), h = n.correct === !0 ? ";" : "x;", w = "separator", j = r.lineOffset, r.lineOffset = 0, g(), r.lineOffset = j, ge());
    }
  }
  function ee() {
    let k = r.count;
    if (e.types[k] === "comment")
      do
        k = k - 1;
      while (k > 0 && e.types[k] === "comment");
    e.token[k] === "from" && (k = k - 2), e.token[k] === "x;" && r.splice({ data: e, howmany: 1, index: k });
  }
  function ke() {
    let k = r.count;
    do
      k = k - 1;
    while (k > -1 && e.token[k] === "x}");
    if (e.stack[k] === "else")
      return g();
    k = k + 1, r.splice({
      data: e,
      howmany: 0,
      index: k,
      record: {
        begin: e.begin[k],
        ender: -1,
        lexer: "script",
        lines: r.lineOffset,
        stack: e.stack[k],
        token: h,
        types: w
      }
    }), g();
  }
  function we() {
    P(!1), z > -1 && y(), G = ut({
      chars: l,
      end: N,
      lexer: "script",
      begin: "/*",
      start: u,
      ender: "*/"
    }), u = G[1], e.token[r.count] === "var" || e.token[r.count] === "let" || e.token[r.count] === "const" ? (F = r.pop(e), g(), r.push(e, F, p), e.lines[r.count - 2] === 0 && (e.lines[r.count - 2] = e.lines[r.count]), e.lines[r.count] = 0) : G[0] !== p && (h = G[0], w = at.test(h) ? "ignore" : "comment", h.indexOf("# sourceMappingURL=") === 2 && (t[0] = r.count + 1, t[1] = h), r.push(e, {
      begin: r.stack.index,
      ender: -1,
      lexer: "script",
      lines: r.lineOffset,
      stack: r.stack.token,
      token: h,
      types: w
    }, p)), /\/\*\s*global\s+/.test(e.token[r.count]) && e.types.indexOf("word") < 0 && (s[0] = e.token[r.count].replace(/\/\*\s*global\s+/, p).replace("*/", p).replace(/,\s+/g, ",").split(","));
  }
  function oe() {
    P(!1), ge(), z > -1 && y(), G = Bt({
      chars: l,
      end: N,
      lexer: "script",
      begin: "//",
      start: u,
      ender: Z
    }), u = G[1], G[0] !== p && (h = G[0], w = at.test(h) ? "ignore" : "comment", h.indexOf("# sourceMappingURL=") === 2 && (t[0] = r.count + 1, t[1] = h), r.push(e, {
      begin: r.stack.index,
      ender: -1,
      lexer: "script",
      lines: r.lineOffset,
      stack: r.stack.token,
      token: h,
      types: w
    }, p));
  }
  function T() {
    let k = 0, m = 0, v = u + 1, L = !1, j = N, pe = ["/"];
    if (v < j)
      do {
        if (pe.push(l[v]), ($(l[v - 1], 92) || i(l[v - 2], 92)) && (i(l[v], 91) && (L = !0), i(l[v], 93) && (L = !1)), i(l[v], 47) && L === !1)
          if (i(l[v - 1], 92)) {
            if (m = 0, k = v - 1, k > 0)
              do {
                if (i(l[k], 92))
                  m = m + 1;
                else
                  break;
                k = k - 1;
              } while (k > 0);
            if (m % 2 === 0)
              break;
          } else
            break;
        v = v + 1;
      } while (v < j);
    return l[v + 1] === "g" || l[v + 1] === "i" || l[v + 1] === "m" || l[v + 1] === "y" || l[v + 1] === "u" ? (pe.push(l[v + 1]), l[v + 2] !== l[v + 1] && (l[v + 2] === "g" || l[v + 2] === "i" || l[v + 2] === "m" || l[v + 2] === "y" || l[v + 2] === "u") ? (pe.push(l[v + 2]), l[v + 3] !== l[v + 1] && l[v + 3] !== l[v + 2] && (l[v + 3] === "g" || l[v + 3] === "i" || l[v + 3] === "m" || l[v + 3] === "y" || l[v + 3] === "u") ? (pe.push(l[v + 3]), l[v + 4] !== l[v + 1] && l[v + 4] !== l[v + 2] && l[v + 4] !== l[v + 3] && (l[v + 4] === "g" || l[v + 4] === "i" || l[v + 4] === "m" || l[v + 4] === "y" || l[v + 4] === "u") ? (pe.push(l[v + 4]), l[v + 5] !== l[v + 1] && l[v + 5] !== l[v + 2] && l[v + 5] !== l[v + 3] && l[v + 5] !== l[v + 4] && (l[v + 5] === "g" || l[v + 5] === "i" || l[v + 5] === "m" || l[v + 5] === "y" || l[v + 5] === "u") ? (pe.push(l[v + 4]), u = v + 5) : u = v + 4) : u = v + 3) : u = v + 2) : u = v + 1) : u = v, pe.join(p);
  }
  function J() {
    let k = [l[u]], m = 0, v = i(k[0], 46), L = /zz/;
    if (u < N - 2 && l[u] === "0" && (l[u + 1] === "x" ? L = /[0-9a-fA-F]/ : l[u + 1] === "o" ? L = /[0-9]/ : l[u + 1] === "b" && (L = /0|1/), L.test(l[u + 2]))) {
      k.push(l[u + 1]), m = u + 1;
      do
        m = m + 1, k.push(l[m]);
      while (L.test(l[m + 1]));
      return u = m, k.join(p);
    }
    if (m = u + 1, m < N)
      do {
        if (Ee(l[m]) || i(l[m], 46) && v === !1)
          k.push(l[m]), i(l[m], 46) && (v = !0);
        else
          break;
        m = m + 1;
      } while (m < N);
    if (m < N - 1 && (Ee(l[m - 1]) || Ee(l[m - 2]) && (i(l[m - 1], 45) || i(l[m - 1], 43))) && (l[m] === "e" || l[m] === "E") && (k.push(l[m]), (i(l[m + 1], 45) || i(l[m + 1], 43)) && (k.push(l[m + 1]), m = m + 1), v = !1, m = m + 1, m < N))
      do {
        if (Ee(l[m]) || i(l[m], 46) && v === !1)
          k.push(l[m]), i(l[m], 46) && (v = !0);
        else
          break;
        m = m + 1;
      } while (m < N);
    return u = m - 1, k.join(p);
  }
  function X() {
    let k = 0, m = 0, v = N, L = p, j = [
      "=",
      "<",
      ">",
      "+",
      "*",
      "?",
      "|",
      "^",
      ":",
      "&",
      "%",
      "~"
    ], pe = j.length;
    if (z > -1 && y(), i(l[u], 47) && r.count > -1 && (w !== "word" && w !== "reference" || h === "typeof" || h === "return" || h === "else") && w !== "number" && w !== "string" && w !== "end")
      return h === "return" || h === "typeof" || h === "else" || w !== "word" ? (h = T(), w = "regex") : (h = "/", w = "operator"), g(), "regex";
    if (i(l[u], 63) && ("+-*/.?".indexOf(l[u + 1]) > -1 || i(l[u + 1], 58) && j.join(p).indexOf(l[u + 2]) < 0) && (i(l[u + 1], 46) && Ee(l[u + 2]) === !1 ? L = "?." : i(l[u + 1], 63) && (L = "??"), L === p))
      return "?";
    if (i(l[u], 58) && "+-*/".indexOf(l[u + 1]) > -1)
      return ":";
    if (u < N - 1) {
      if ($(l[u], 60) && i(l[u + 1], 60))
        return l[u];
      if (i(l[u], 33) && i(l[u + 1], 47))
        return "!";
      if (i(l[u], 45) && (f[f.length - 1] = !1, i(l[u + 1], 45) ? L = "--" : i(l[u + 1], 61) ? L = "-=" : i(l[u + 1], 62) && (L = "->"), L === p))
        return "-";
      if (i(l[u], 43) && (f[f.length - 1] = !1, i(l[u + 1], 43) ? L = "++" : i(l[u + 1], 61) && (L = "+="), L === p))
        return "+";
      if (i(l[u], 61) && $(l[u + 1], 61) && $(l[u + 1], 33) && $(l[u + 1], 62))
        return f[f.length - 1] = !1, "=";
    }
    if (i(l[u], 59))
      if (r.language === "typescript") {
        if (e.stack[r.count] === "arguments")
          e.token[r.count] === "?" && (r.pop(e), L = "?:", u = u - 1), f[f.length - 1] = !0;
        else if (i(h, 41) && (e.token[e.begin[r.count] - 1] === "function" || e.token[e.begin[r.count] - 2] === "function"))
          f[f.length - 1] = !0;
        else if (w === "reference") {
          k = r.count;
          let S = !1;
          do {
            if (e.begin[k] === e.begin[r.count]) {
              if (k < r.count && e.token[k] === ":" && e.types[k + 1] !== "type" && (S = !0), e.token[k] === "?" && S === !1 || e.token[k] === ";" || e.token[k] === "x;")
                break;
              if (e.token[k] === "var" || e.token[k] === "let" || e.token[k] === "const" || e.types[k] === "type") {
                f[f.length - 1] = !0;
                break;
              }
            } else {
              if (e.types[k] === "type_end") {
                f[f.length - 1] = !0;
                break;
              }
              k = e.begin[k];
            }
            k = k - 1;
          } while (k > e.begin[r.count]);
        }
      } else
        e.token[r.count - 1] === "[" && (e.types[r.count] === "word" || e.types[r.count] === "reference") && (r.stack.update("attribute"), e.stack[r.count] = "attribute");
    if (L === p)
      if (i(l[u + 1], 43) && i(l[u + 2], 43) || i(l[u + 1], 45) && i(l[u + 2], 45))
        L = l[u];
      else {
        let S = [l[u]];
        if (k = u + 1, k < v)
          do {
            if (i(l[k], 43) && i(l[k + 1], 43) || i(l[k], 45) && i(l[k + 1], 45))
              break;
            if (m = 0, m < pe)
              do {
                if (l[k] === j[m]) {
                  S.push(j[m]);
                  break;
                }
                m = m + 1;
              } while (m < pe);
            if (m === pe)
              break;
            k = k + 1;
          } while (k < v);
        L = S.join(p);
      }
    if (u = u + (L.length - 1), L === "=>" && i(h, 41)) {
      k = r.count, v = e.begin[k];
      do
        e.begin[k] === v && (e.stack[k] = "method"), k = k - 1;
      while (k > v - 1);
    }
    return L;
  }
  function V() {
    let k = [l[u]];
    if (u = u + 1, u < N)
      do {
        if (k.push(l[u]), i(l[u], 96) && ($(l[u - 1], 92) || !_(u - 1)) || i(l[u - 1], 36) && i(l[u], 123) && ($(l[u - 2], 92) || !_(u - 2)))
          break;
        u = u + 1;
      } while (u < N);
    return k.join(p);
  }
  function se() {
    let k = 0, m = !1, v = !1, L = 0, j = 0, pe = 0, S = p, E = p, M = p, I = [], H = f[f.length - 1], fe = "0123456789=<>+-*?|^:&.,;%(){}[]~";
    function ue() {
      i(h, 40) && r.stack.update("paren", r.count), r.external("html", I.join(p));
    }
    if (z > -1 && y(), E = r.count > 0 ? e.token[r.count - 1] : p, M = r.count > 0 ? e.types[r.count - 1] : p, S = A(1, !1), r.language !== "jsx" && r.language !== "tsx" && Ee(S) === !1 && (h === "function" || E === "=>" || E === "void" || E === "." || h === "return" || w === "operator" || e.stack[r.count] === "arguments" || w === "type" && E === "type" || w === "reference" && (M === "operator" || E === "function" || E === "class" || E === "new") || w === "type" && M === "operator")) {
      let de = [], ne = 0, te = 0;
      k = u;
      do {
        if (de.push(l[k]), i(l[k], 60))
          ne = ne + 1;
        else if (i(l[k], 62) && (ne = ne - 1, ne < 1))
          break;
        k = k + 1;
      } while (k < N);
      if (te = u, u = k, S = A(1, !1), i(l[k], 62) && (H === !0 || E === "=>" || E === "." || M !== "operator" || M === "operator" && (i(S, 40) || i(S, 61)))) {
        w = "generic", h = de.join(p).replace(/^<\s+/, "<").replace(/\s+>$/, ">").replace(/,\s*/g, ", "), g();
        return;
      }
      u = te;
    }
    if (k = r.count, e.types[k] === "comment")
      do
        k = k - 1;
      while (k > 0 && e.types[k] === "comment");
    if (H === !1 && A(1, !1) !== ">" && ($(l[u], 60) && fe.indexOf(l[u + 1]) > -1 || e.token[k] === "++" || e.token[k] === "--" || le(l[u + 1]) === !0 || Ee(l[u + 1]) === !0 && (w === "operator" || w === "string" || w === "number" || w === "reference" || w === "word" && h !== "return")))
      return w = "operator", h = X(), g();
    if (r.language !== "typescript" && (e.token[k] === "return" || e.types[k] === "operator" || e.types[k] === "start" || e.types[k] === "separator" || e.types[k] === "jsx_attribute_start" || i(e.token[k], 125) && r.stack.token === "global")) {
      w = "markup", r.language = "jsx";
      do {
        if (I.push(l[u]), i(l[u], 123))
          j = j + 1, m = !0;
        else if (i(l[u], 125))
          j = j - 1, j === 0 && (m = !1);
        else if (i(l[u], 60) && m === !1) {
          if (i(l[u + 1], 60))
            do
              I.push(l[u]), u = u + 1;
            while (u < N && i(l[u + 1], 60));
          L = L + 1, i(A(1, !1), 47) && (v = !0);
        } else if (i(l[u], 62) && m === !1) {
          if (i(l[u + 1], 62))
            do
              I.push(l[u]), u = u + 1;
            while (i(l[u + 1], 62));
          if (L = L - 1, v === !0 ? pe = pe - 1 : $(l[u - 1], 47) && (pe = pe + 1), L === 0 && j === 0 && pe < 1) {
            if (S = A(2, !1), $(S, 60))
              return ue();
            if (i(S, 60) && fe.indexOf(S.charAt(1)) < 0 && le(S.charAt(1)) === !1) {
              k = u + 1;
              do {
                if (k = k + 1, i(l[k], 62) || le(l[k - 1]) && fe.indexOf(l[k]) < 0)
                  break;
                if (fe.indexOf(l[k]) > -1)
                  return ue();
              } while (k < N);
            } else
              return ue();
          }
          v = !1;
        }
        u = u + 1;
      } while (u < N);
      return ue();
    }
    w = "operator", h = X(), g();
  }
  function D() {
    let k = !0, m = "+", v = p, L = p, j = p, pe = p, S = 0, E = 0, M = 0, I = [];
    function H() {
      E = e.begin[E] - 1, e.types[E] === "end" ? H() : i(e.token[E - 1], 46) && fe();
    }
    function fe() {
      E = E - 2, e.types[E] === "end" ? H() : i(e.token[E - 1], 46) && fe();
    }
    function ue() {
      let ne = 0;
      if (ne < I.length)
        do
          r.push(e, I[ne], p), ne = ne + 1;
        while (ne < I.length);
    }
    function de(ne) {
      return {
        begin: e.begin[ne],
        ender: e.ender[ne],
        lexer: e.lexer[ne],
        lines: e.lines[ne],
        stack: e.stack[ne],
        token: e.token[ne],
        types: e.types[ne]
      };
    }
    if (v = e.token[r.count], L = e.token[r.count - 1], j = e.token[r.count - 2], v !== "++" && v !== "--" && L !== "++" && L !== "--" && (E = r.count, e.types[E] === "end" ? H() : i(e.token[E - 1], 46) && fe()), e.token[E - 1] === "++" || e.token[E - 1] === "--") {
      if ("startendoperator".indexOf(e.types[E - 2]) > -1)
        return;
      if (M = E, M < r.count + 1) {
        do
          I.push(de(M)), M = M + 1;
        while (M < r.count + 1);
        r.splice({ data: e, howmany: r.count - E, index: E });
      }
    } else {
      if (n.correct === !1 || v !== "++" && v !== "--" && L !== "++" && L !== "--")
        return;
      if (pe = A(1, !1), (v === "++" || v === "--") && (i(l[u], 59) || i(pe, 59) || i(l[u], 125) || i(pe, 125) || i(l[u], 41) || i(pe, 41))) {
        if (m = e.stack[r.count], m === "array" || m === "method" || m === "object" || m === "paren" || m === "notation" || e.token[e.begin[r.count] - 1] === "while" && m !== "while")
          return;
        M = r.count;
        do {
          if (M = M - 1, e.token[M] === "return")
            return;
          if (e.types[M] === "end")
            do
              M = e.begin[M] - 1;
            while (e.types[M] === "end" && M > 0);
        } while (M > 0 && (i(e.token[M], 46) || e.types[M] === "word" || e.types[M] === "reference" || e.types[M] === "end"));
        if (i(e.token[M], 44) && $(l[u], 59) && $(pe, 59) && $(l[u], 125) && $(pe, 125) && $(l[u], 41) && $(pe, 41))
          return;
        if (e.types[M] === "operator")
          if (e.stack[M] === "switch" && i(e.token[M], 58))
            do {
              if (M = M - 1, e.types[M] === "start") {
                if (S = S - 1, S < 0)
                  break;
              } else
                e.types[M] === "end" && (S = S + 1);
              if (i(e.token[M], 63) && S === 0)
                return;
            } while (M > 0);
          else
            return;
        k = !1, m = v === "--" ? "-" : "+";
      } else if (i(j, 91) || i(j, 59) || i(j, 123) || i(j, 125) || i(j, 40) || i(j, 41) || i(j, 44) || j === "return" || j === "x;")
        if (v === "++" || v === "--") {
          if (i(j, 91) || i(j, 40) || i(j, 44) || j === "return")
            return;
          v === "--" && (m = "-"), k = !1;
        } else
          (L === "--" || v === "--") && (m = "-");
      else
        return;
      if (k === !1 && (F = r.pop(e)), E = r.count, e.types[E] === "end" ? H() : i(e.token[E - 1], 46) && fe(), M = E, M < r.count + 1)
        do
          I.push(de(M)), M = M + 1;
        while (M < r.count + 1);
    }
    k === !0 ? (r.splice({
      data: e,
      howmany: 1,
      index: E - 1
    }), h = "=", w = "operator", g(), ue(), h = m, w = "operator", g(), h = "1", w = "number", g()) : (h = "=", w = "operator", g(), ue(), h = m, w = "operator", g(), h = "1", w = "number", g()), h = e.token[r.count], w = e.types[r.count], i(pe, 125) && $(l[u], 59) && P(!1);
  }
  function re(k, m, v) {
    let L = 0, j = !1, pe = !1, S = [k], E, M = m.split(p), I = M.length, H = u, fe = u + k.length, ue = O.quoteConvert;
    function de() {
      let te = 0;
      if (S = [], w = v, L = u, v === "string" && le(l[L + 1])) {
        te = 1;
        do
          L = L + 1, i(l[L], 10) && (te = te + 1);
        while (L < N && le(l[L + 1]) === !0);
        r.lineOffset = te;
      }
    }
    function ne() {
      let te = p;
      function Me(me) {
        if (r.language !== "javascript" && r.language !== "typescript" && r.language !== "jsx" && r.language !== "tsx") {
          let be = (he) => he.replace(/\s*$/, " "), je = (he) => he.replace(/^\s*/, " ");
          return /\{(#|\/|(%>)|(%\]))/.test(me) || /\}%(>|\])/.test(me) || (me = me.replace(/\{((\{+)|%-?)\s*/g, be), me = me.replace(/\s*((\}\}+)|(-?%\}))/g, je)), me;
        }
        return me;
      }
      if (i(k, 34) && ue === "single" ? (S[0] = ve, S[S.length - 1] = ve) : i(k, 39) && ue === "double" ? (S[0] = Ce, S[S.length - 1] = Ce) : j === !0 && (te = S[S.length - 1], S.pop(), S.pop(), S.push(te)), u = L, m === Z && (u = u - 1, S.pop()), h = S.join(p), (i(k, 34) || i(k, 39) || k === "{{" || k === "{%") && (h = Me(h)), k === "{%" || k === "{{") {
        E = U(h), w = E[0], g(E[1]);
        return;
      }
      if (v === "string") {
        if (w = "string", r.language === "json")
          h = h.replace(/\\u[\dA-F]{4}/gi, (me) => String.fromCharCode(parseInt(me.replace(/\\u/g, ""), 16)));
        else if (k.indexOf("#!") === 0)
          h = h.slice(0, h.length - 1), r.lineOffset = 2;
        else if ((r.stack.token !== "object" || r.stack.token === "object" && $(A(1, !1), 58) && $(e.token[r.count], 44) && $(e.token[r.count], 123)) && (h.length > n.wrap && n.wrap > 0 || n.wrap !== 0 && i(e.token[r.count], 43) && (i(e.token[r.count - 1], 46) || i(e.token[r.count - 1], 39)))) {
          let me = h, be = p, je = ue === "double" ? Ce : ue === "single" ? ve : me.charAt(0), he = n.wrap, Le = /u[0-9a-fA-F]{4}/, We = /x[0-9a-fA-F]{2}/;
          if (me = me.slice(1, me.length - 1), i(e.token[r.count], 43) && (i(e.token[r.count - 1], 46) || i(e.token[r.count - 1], 39)) && (r.pop(e), je = e.token[r.count].charAt(0), me = e.token[r.count].slice(1, e.token[r.count].length - 1) + me, r.pop(e)), me.length > he && he > 0)
            do
              be = me.slice(0, he), i(be[he - 5], 92) && Le.test(me.slice(he - 4, he + 1)) ? be = be.slice(0, he - 5) : i(be[he - 4], 92) && Le.test(me.slice(he - 3, he + 2)) ? be = be.slice(0, he - 4) : i(be[he - 3], 92) && (Le.test(me.slice(he - 2, he + 3)) || We.test(me.slice(he - 2, he + 1))) ? be = be.slice(0, he - 3) : i(be[he - 2], 92) && (Le.test(me.slice(he - 1, he + 4)) || We.test(me.slice(he - 1, he + 2))) ? be = be.slice(0, he - 2) : i(be[he - 1], 92) && (be = be.slice(0, he - 1)), be = je + be + je, me = me.slice(be.length - 2), h = be, w = "string", g(p), r.lineOffset = 0, h = "+", w = "operator", g(p);
            while (me.length > he);
          h = me === p ? je + je : je + me + je, w = "string";
        }
      } else
        /\{\s*\?>$/.test(h) ? w = "liquid_start" : w = v;
      h.length > 0 && g(p);
    }
    if (z > -1 && y(), i(l[u - 1], 92) && _(u - 1) === !0 && (i(l[u], 34) || i(l[u], 39)))
      if (r.pop(e), i(e.token[0], 123))
        i(l[u], 34) ? (k = Ce, m = '\\"', S = [Ce]) : (k = ve, m = "\\'", S = [ve]), j = !0;
      else {
        if (i(l[u], 34)) {
          S = ['\\"'], ne();
          return;
        }
        S = ["\\'"], ne();
        return;
      }
    if (L = fe, L < N)
      do {
        if ($(e.token[0], 123) && $(e.token[0], 91) && ue !== "none" && (i(l[L], 34) || i(l[L], 39)) ? (i(l[L - 1], 92) ? _(L - 1) === !0 && (ue === "double" && i(l[L], 39) || ue === "single" && i(l[L], 34)) && S.pop() : ue === "double" && i(l[L], 34) && i(l[u], 39) ? l[L] = Ce : ue === "single" && i(l[L], 39) && i(l[u], 34) && (l[L] = ve), S.push(l[L])) : L > H ? (pe = !0, i(l[L], 123) && i(l[L + 1], 37) && l[L + 2] !== k ? (ne(), re("{%", "%}", "liquid"), de()) : i(l[L], 123) && i(l[L + 1], 123) && l[L + 2] !== k ? (ne(), re("{{", "}}", "liquid"), de()) : (pe = !1, S.push(l[L]))) : S.push(l[L]), r.language !== "json" && r.language !== "javascript" && (i(k, 34) || i(k, 39)) && (pe === !0 || L > H) && $(l[L - 1], 92) && $(l[L], 34) && $(l[L], 39) && (i(l[L], 10) || L === N - 1)) {
          r.error = "Unterminated string in script on line number " + r.lineNumber;
          break;
        }
        if (l[L] === M[I - 1] && ($(l[L - 1], 92) || _(L - 1) === !1) && (I === 1 || S[L - fe] === M[0] && S.slice(L - fe - I + 2).join(p) === m))
          break;
        L = L + 1;
      } while (L < N);
    ne();
  }
  function ge() {
    let k = p, m = A(5, !1), v = r.count, L = r.lineOffset;
    if (!(r.language === "json" || d.length < 1 || d[d.length - 1].charAt(0) !== "x" || /^x?(;|\}|\))$/.test(h) === !1) && !(e.stack[r.count] === "do" && m === "while" && i(e.token[r.count], 125))) {
      if (i(h, 59) && e.token[v - 1] === "x{") {
        if (k = e.token[e.begin[v - 2] - 1], e.token[v - 2] === "do" || i(e.token[v - 2], 41) && "ifforwhilecatch".indexOf(k) > -1) {
          F = r.pop(e), h = n.correct === !0 ? "}" : "x}", w = "end", B = r.stack.entry, g(), d.pop(), r.lineOffset = L;
          return;
        }
        F = r.pop(e), h = n.correct === !0 ? "}" : "x}", w = "end", B = r.stack.entry, g(), d.pop(), h = ";", w = "end", r.push(e, F, p), r.lineOffset = L;
        return;
      }
      if (h = n.correct === !0 ? "}" : "x}", w = "end", e.token[r.count] !== "x}") {
        if (m === "else" && e.stack[r.count] === "if" && (i(e.token[r.count], 59) || e.token[r.count] === "x;")) {
          B = r.stack.entry, g(), d.pop(), r.lineOffset = L;
          return;
        }
        do
          if (B = r.stack.entry, g(), d.pop(), e.stack[r.count] === "do")
            break;
        while (d[d.length - 1] === "x{");
        r.lineOffset = L;
      }
    }
  }
  function Be() {
    let k = r.count;
    if (e.stack[k] === "object" && O.objectSort === !0)
      h = ",", w = "separator", ee(), g();
    else {
      do
        k = k - 1;
      while (k > 0 && e.types[k - 1] === "comment");
      r.splice({
        data: e,
        howmany: 0,
        index: k,
        record: {
          begin: e.begin[k],
          ender: -1,
          lexer: "script",
          lines: r.lineOffset,
          stack: e.stack[k],
          token: ",",
          types: "separator"
        }
      }), g();
    }
  }
  function Se(k) {
    let m = !1, v = !1, L = A(1, !1), j = i(e.token[r.count], 40) ? r.count : e.begin[r.count];
    function pe() {
      let S = 0, E = e.token[j - 1] === "Array", M = E ? "[" : "{", I = E ? "]" : "}", H = E ? "array" : "object";
      if (E === !0 && e.types[r.count] === "number" && (S = Number(e.token[r.count]), F = r.pop(e)), F = r.pop(e), F = r.pop(e), F = r.pop(e), r.stack.pop(), h = M, w = "start", g(H), S > 0) {
        h = ",", w = "separator";
        do
          g(), S = S - 1;
        while (S > 0);
      }
      h = I, w = "end", g();
    }
    if (z > -1 && y(), b.length > 0 && (b[b.length - 1] === 0 ? b.pop() : b[b.length - 1] = b[b.length - 1] - 1), (i(k, 41) || k === "x)" || i(k, 93)) && (n.correct === !0 && D(), ee()), (i(k, 41) || k === "x)") && P(!1), R > -1 && (i(k, 125) && (O.variableList === "list" && W.count[R] === 0 || e.token[r.count] === "x;" && O.variableList === "each") && q(), W.count[R] = W.count[R] - 1, W.count[R] < 0 && q()), i(h, 44) && e.stack[r.count] !== "initializer" && (i(k, 93) && i(e.token[r.count - 1], 91) || i(k, 125)) && (F = r.pop(e)), i(k, 41) || k === "x)" ? (h = k, o.length > 0 && (x = o[o.length - 1], x.length > 1 && $(L, 123) && (x[0] === "if" || x[0] === "for" || x[0] === "with" || x[0] === "while" && e.stack[x[1] - 2] !== void 0 && e.stack[x[1] - 2] !== "do") && (m = !0))) : i(k, 93) ? h = "]" : i(k, 125) && ($(h, 44) && n.correct === !0 && D(), r.stack.length > 0 && r.stack.token !== "object" && P(!0), O.objectSort === !0 && r.stack.token === "object" && bt(e), w === "comment" && (h = e.token[r.count], w = e.types[r.count]), h = "}"), r.stack.token === "data_type" ? w = "type_end" : w = "end", o.pop(), B = r.stack.entry, i(k, 41) && n.correct === !0 && j - r.count < 2 && (i(e.token[r.count], 40) || e.types[r.count] === "number") && (e.token[j - 1] === "Array" || e.token[j - 1] === "Object") && e.token[j - 2] === "new" && (pe(), v = !0), d[d.length - 1] === "x{" && i(k, 125) ? (ge(), d.pop(), e.stack[r.count] !== "try" && $(L, 58) && $(L, 59) && e.token[e.begin[u] - 1] !== "?" && ge(), h = "}") : d.pop(), O.endComma !== void 0 && O.endComma !== "none" && r.stack.token === "array" || r.stack.token === "object" || r.stack.token === "data_type")
      if (O.endComma === "always" && $(e.token[r.count], 44)) {
        let S = r.stack.index, E = r.count;
        do {
          if (e.begin[E] === S) {
            if (i(e.token[E], 44))
              break;
          } else
            E = e.begin[E];
          E = E - 1;
        } while (E > S);
        if (E > S) {
          let M = w, I = h;
          h = ",", w = "separator", g(), h = I, w = M;
        }
      } else
        O.endComma === "never" && i(e.token[r.count], 44) && r.pop(e);
    v === !1 && (g(), i(h, 125) && e.stack[r.count] !== "object" && e.stack[r.count] !== "class" && e.stack[r.count] !== "data_type" && (s.pop(), ge())), m === !0 && (h = n.correct === !0 ? "{" : "x{", w = "start", g(x[0]), d.push("x{"), x[1] = r.count), f.pop(), r.stack.token !== "data_type" && (f[f.length - 1] = !1);
  }
  function Q(k) {
    let m = r.count, v = p, L = p, j = p, pe = !1;
    if (d.push(k), i(k, 123) && (e.types[r.count] === "type" || e.types[r.count] === "type_end" || e.types[r.count] === "generic")) {
      let S = 0;
      e.types[r.count] === "type_end" && (m = e.begin[r.count]), S = m;
      do
        if (m = m - 1, e.begin[m] !== S && e.begin[m] !== -1 || i(e.token[m], 58))
          break;
      while (m > e.begin[m]);
      i(e.token[m], 58) && e.stack[m - 1] === "arguments" ? (f.push(!1), pe = !0) : f.push(f[f.length - 1]), m = r.count;
    } else
      i(k, 91) && e.types[r.count] === "type_end" ? f.push(!0) : f.push(f[f.length - 1]);
    if (z > -1 && (y(), m = r.count), R > -1 && (W.count[R] = W.count[R] + 1), e.token[m - 1] === "function" ? o.push(["function", m + 1]) : o.push([h, m + 1]), h = k, f[f.length - 1] === !0 ? w = "type_start" : w = "start", i(k, 40) || k === "x(" ? ee() : i(k, 91) && (a > -1 ? (e.begin[a - 1] === e.begin[e.begin[m] - 1] || e.token[e.begin[m]] === "x(") && (a = -1, n.correct === !0 ? Se(")") : Se("x)"), ee(), h = "{", w = "start") : i(h, 41) && ee(), w === "comment" && i(e.token[m - 1], 41) && (h = e.token[m], e.token[m] = "{", w = e.types[m], e.types[m] = "start")), v = (() => {
      let S = r.count;
      if (e.types[S] === "comment")
        do
          S = S - 1;
        while (S > 0 && e.types[S] === "comment");
      return e.token[S];
    })(), L = e.stack[m] === void 0 ? p : (() => {
      let S = r.count;
      if (e.types[S] === "comment")
        do
          S = S - 1;
        while (S > 0 && e.types[S] === "comment");
      return e.token[e.begin[S] - 1];
    })(), i(h, 123) && (e.types[m] === "word" || i(e.token[m], 93))) {
      let S = m;
      if (i(e.token[S], 93))
        do
          S = e.begin[S] - 1;
        while (i(e.token[S], 93));
      do {
        if (e.types[S] === "start" || e.types[S] === "end" || e.types[S] === "operator")
          break;
        S = S - 1;
      } while (S > 0);
      i(e.token[S], 58) && e.stack[S - 1] === "arguments" && (j = "function", s.push(C), C = []);
    }
    if (w === "type_start")
      j = "data_type";
    else if (j === p && (i(h, 123) || h === "x{")) {
      if (v === "else" || v === "do" || v === "try" || v === "finally" || v === "switch")
        j = v;
      else if (b[b.length - 1] === 0 && v !== "return")
        b.pop(), j = "class";
      else if (e.token[m - 1] === "class")
        j = "class";
      else if (i(e.token[m], 93) && i(e.token[m - 1], 91))
        j = "array";
      else if ((e.types[m] === "word" || e.types[m] === "reference") && (e.types[m - 1] === "word" || e.types[m - 1] === "reference" || e.token[m - 1] === "?" && (e.types[m - 2] === "word" || e.types[m - 2] === "reference")) && e.token[m] !== "in" && e.token[m - 1] !== "export" && e.token[m - 1] !== "import")
        j = "map";
      else if (e.stack[m] === "method" && e.types[m] === "end" && (e.types[e.begin[m] - 1] === "word" || e.types[e.begin[m] - 1] === "reference") && e.token[e.begin[m] - 2] === "new")
        j = "initializer";
      else if (i(h, 123) && (i(v, 41) || v === "x)") && (e.types[e.begin[m] - 1] === "word" || e.types[e.begin[m] - 1] === "reference" || e.token[e.begin[m] - 1] === "]"))
        L === "if" ? j = "if" : L === "for" ? j = "for" : L === "while" ? j = "while" : L === "class" ? j = "class" : L === "switch" || e.token[e.begin[m] - 1] === "switch" ? j = "switch" : L === "catch" ? j = "catch" : j = "function";
      else if (i(h, 123) && (i(v, 59) || v === "x;"))
        j = "block";
      else if (i(h, 123) && i(e.token[m], 58) && e.stack[m] === "switch")
        j = "block";
      else if (e.token[m - 1] === "import" || e.token[m - 2] === "import" || e.token[m - 1] === "export" || e.token[m - 2] === "export")
        j = "object";
      else if (i(v, 41) && (x[0] === "function" || x[0] === "if" || x[0] === "for" || x[0] === "class" || x[0] === "while" || x[0] === "switch" || x[0] === "catch"))
        j = x[0];
      else if (e.stack[m] === "notation")
        j = "function";
      else if ((e.types[m] === "number" || e.types[m] === "string" || e.types[m] === "word" || e.types[m] === "reference") && (e.types[m - 1] === "word" || e.types[m - 1] === "reference") && e.token[e.begin[m] - 1] !== "for")
        j = "function";
      else if (r.stack.length > 0 && $(e.token[m], 58) && r.stack.token === "object" && (i(e.token[e.begin[m] - 2], 123) || i(e.token[e.begin[m] - 2], 44)))
        j = "function";
      else if (e.types[x[1] - 1] === "markup" && e.token[x[1] - 3] === "function")
        j = "function";
      else if (v === "=>")
        j = "function";
      else if (pe === !0 || e.types[r.count] === "type_end" && e.stack[e.begin[r.count] - 2] === "arguments")
        j = "function";
      else if (i(v, 41) && e.stack[m] === "method" && (e.types[e.begin[m] - 1] === "word" || e.types[e.begin[m] - 1] === "property" || e.types[e.begin[m] - 1] === "reference"))
        j = "function";
      else if (i(h, 123) && e.types[m] === "word" && e.token[m] !== "return" && e.token[m] !== "in" && e.token[m] !== "import" && e.token[m] !== "const" && e.token[m] !== "let" && e.token[m] !== p)
        j = "block";
      else if (i(h, 123) && "if|else|for|while|function|class|switch|catch|finally".indexOf(e.stack[m]) > -1 && (e.token[m] === "x}" || i(e.token[m], 125)))
        j = "block";
      else if (e.stack[m] === "arguments")
        j = "function";
      else if (e.types[m] === "generic")
        do {
          if (m = m - 1, e.token[m] === "function" || e.stack[m] === "arguments") {
            j = "function";
            break;
          }
          if (e.token[m] === "interface") {
            j = "map";
            break;
          }
          if (i(e.token[m], 59)) {
            j = "object";
            break;
          }
        } while (m > e.begin[r.count]);
      else
        j = "object";
      j !== "object" && j !== "class" && (j === "function" ? (s.push(C), C = []) : s.push([]));
    } else
      i(h, 91) ? j = "array" : (i(h, 40) || h === "x(") && (v === "function" || e.token[m - 1] === "function" || e.token[m - 1] === "function*" || e.token[m - 2] === "function" ? j = "arguments" : i(e.token[m - 1], 46) || i(e.token[e.begin[m] - 2], 46) || e.types[m] === "generic" || i(e.token[m], 125) && e.stack[m] === "function" ? j = "method" : v === "if" || v === "for" || v === "class" || v === "while" || v === "catch" || v === "finally" || v === "switch" || v === "with" ? j = "expression" : e.types[m] === "word" || e.types[m] === "property" || e.types[m] === "reference" ? j = "method" : j = "paren");
    g(j), b.length > 0 && (b[b.length - 1] = b[b.length - 1] + 1);
  }
  function U(k) {
    let m = 2, v = 0, L = p, j = k.slice(0, 2), pe = k.length;
    if (i(k[2], 45) && (m = m + 1), le(k.charAt(m)) === !0)
      do
        m = m + 1;
      while (le(k.charAt(m)) === !0 && m < pe);
    v = m;
    do
      v = v + 1;
    while (le(k.charAt(v)) === !1 && k.charAt(v) !== "(" && v < pe);
    if (v === pe && (v = k.length - 2), L = k.slice(m, v), L === "else" || j === "{%" && (L === "elseif" || L === "when" || L === "elif" || L === "elsif"))
      return ["liquid_else", `liquid_${L}`];
    if (j === "{{")
      return L === "end" ? ["liquid_end", p] : (
        //  (name === 'block' && (/\{%\s*\w/).test(source) === false) ||
        L === "define" || L === "form" || L === "if" || L === "unless" || L === "range" || L === "with" ? ["liquid_start", `liquid_${L}`] : ["liquid", p]
      );
    if (v = ie.length - 1, v > -1)
      do {
        if (L === ie[v] && L !== "block")
          return ["liquid_start", `liquid_${L}`];
        if (L === "end" + ie[v])
          return [
            "liquid_end",
            p
          ];
        v = v - 1;
      } while (v > -1);
    return ["liquid", p];
  }
  function y() {
    let k = z, m = 1, v = p, L = p, j = h, pe = w, S = [];
    function E() {
      d.push("x{"), r.splice({
        data: e,
        howmany: 1,
        index: r.count - 3
      });
    }
    function M(I, H, fe) {
      let ue = e.begin[I], de = 0;
      do {
        if (e.token[I] === H && e.types[I] === "word") {
          if (fe === !0)
            e.types[I] = "reference";
          else if (e.begin[I] > ue && e.token[e.begin[I]] === "{" && e.stack[I] !== "object" && e.stack[I] !== "class" && e.stack[I] !== "data_type")
            if (e.stack[I] === "function")
              e.types[I] = "reference";
            else {
              de = e.begin[I];
              do {
                if (e.stack[de] === "function") {
                  e.types[I] = "reference";
                  break;
                }
                de = e.begin[de];
              } while (de > ue);
            }
        }
        I = I - 1;
      } while (I > ue);
    }
    do
      S.push(l[k]), i(l[k], 92), k = k + 1;
    while (k < u);
    if (h.charAt(0) === "\u201C" ? r.error = `Quote looking character (\u201C, \\u201c) used instead of actual quotes on line number ${r.lineNumber}` : h.charAt(0) === "\u201D" && (r.error = `Quote looking character (\u201D, \\u201d) used instead of actual quotes on line number ${r.lineNumber}`), v = S.join(p), z = -1, r.count > 0 && v === "function" && i(e.token[r.count], 40) && (i(e.token[r.count - 1], 123) || e.token[r.count - 1] === "x{") && (e.types[r.count] = "start"), r.count > 1 && v === "function" && i(h, 40) && (i(e.token[r.count - 1], 125) || e.token[r.count - 1] === "x}"))
      if (i(e.token[r.count - 1], 125)) {
        if (k = r.count - 2, k > -1)
          do {
            if (e.types[k] === "end" ? m = m + 1 : (e.types[k] === "start" || e.types[k] === "end") && (m = m - 1), m === 0)
              break;
            k = k - 1;
          } while (k > -1);
        if (i(e.token[k], 123) && i(e.token[k - 1], 41)) {
          if (m = 1, k = k - 2, k > -1)
            do {
              if (e.types[k] === "end" ? m = m + 1 : (e.types[k] === "start" || e.types[k] === "end") && (m = m - 1), m === 0)
                break;
              k = k - 1;
            } while (k > -1);
          e.token[k - 1] !== "function" && e.token[k - 2] !== "function" && (e.types[r.count] = "start");
        }
      } else
        e.types[r.count] = "start";
    if (n.correct === !0 && (v === "Object" || v === "Array") && i(l[u + 1], 40) && i(l[u + 2], 41) && i(e.token[r.count - 1], 61) && e.token[r.count] === "new")
      v === "Object" ? (e.token[r.count] = "{", h = "}", e.stack[r.count] = "object", r.stack.update("object")) : (e.token[r.count] = "[", h = "]", e.stack[r.count] = "array", r.stack.update("array")), e.types[r.count] = "start", w = "end", l[u + 1] = p, l[u + 2] = p, u = u + 2;
    else {
      if (m = r.count, k = m, O.variableList !== "none" && (v === "var" || v === "let" || v === "const")) {
        if (e.types[m] === "comment")
          do
            m = m - 1;
          while (m > 0 && e.types[m] === "comment");
        if (O.variableList === "list" && R > -1 && W.index[R] === m && v === W.word[R]) {
          h = ",", w = "separator", e.token[m] = h, e.types[m] = w, W.count[R] = 0, W.index[R] = m, W.word[R] = v;
          return;
        }
        R = R + 1, W.count.push(0), W.index.push(m), W.word.push(v), m = k;
      } else
        R > -1 && v !== W.word[R] && r.count === W.index[R] && i(e.token[W.index[R]], 59) && h !== W.word[R] && O.variableList === "list" && q();
      if (v === "from" && e.token[r.count] === "x;" && i(e.token[r.count - 1], 125) && ee(), v === "while" && e.token[r.count] === "x;" && i(e.token[r.count - 1], 125)) {
        let I = 0, H = r.count - 2;
        if (H > -1)
          do {
            if (e.types[H] === "end" ? I = I + 1 : e.types[H] === "start" && (I = I - 1), I < 0) {
              i(e.token[H], 123) && e.token[H - 1] === "do" && ee();
              return;
            }
            H = H - 1;
          } while (H > -1);
      }
      if (pe === "comment") {
        let I = r.count;
        do
          I = I - 1;
        while (I > 0 && e.types[I] === "comment");
        pe = e.types[I], j = e.token[I];
      }
      if (L = A(2, !1), v === "void")
        j === ":" && e.stack[r.count - 1] === "arguments" ? w = "type" : w = "word";
      else if ((r.stack.token === "object" || r.stack.token === "class" || r.stack.token === "data_type") && (i(e.token[r.count], 123) || i(e.token[e.begin[r.count]], 123) && i(e.token[r.count], 44) || e.types[r.count] === "liquid_end" && (i(e.token[e.begin[r.count] - 1], 123) || i(e.token[e.begin[r.count] - 1], 44))))
        v === "return" || v === "break" ? w = "word" : w = "property";
      else if (f[f.length - 1] === !0 || (r.language === "typescript" || r.language === "flow") && j === "type")
        w = "type";
      else if (s.length > 0 && (j === "function" || j === "class" || j === "const" || j === "let" || j === "var" || j === "new" || j === "void"))
        w = "reference", s[s.length - 1].push(v), r.language === "javascript" || r.language === "jsx" || r.language === "typescript" || r.language === "tsx" ? j === "var" || j === "function" && e.types[r.count - 1] !== "operator" && e.types[r.count - 1] !== "start" && e.types[r.count - 1] !== "end" ? M(r.count, v, !0) : M(r.count, v, !1) : M(r.count, v, !1);
      else if (r.stack.token === "arguments" && w !== "operator")
        w = "reference", C.push(v);
      else if (i(j, 44) && e.stack[r.count] !== "method" && (e.stack[r.count] !== "expression" || e.token[e.begin[r.count] - 1] === "for")) {
        let I = r.count, H = r.stack.index;
        do {
          if (e.begin[I] === H) {
            if (e.token[I] === ";" || e.token[I] === "var" || e.token[I] === "let" || e.token[I] === "const" || e.token[I] === "type")
              break;
          } else
            e.types[I] === "end" && (I = e.begin[I]);
          I = I - 1;
        } while (I > H);
        s.length > 0 && e.token[I] === "var" ? (w = "reference", s[s.length - 1].push(v), r.language === "javascript" || r.language === "jsx" || r.language === "typescript" || r.language === "tsx" ? M(I, v, !0) : M(I, v, !1)) : s.length > 0 && (e.token[I] === "let" || e.token[I] === "const" || e.token[I] === "type" && (r.language === "typescript" || r.language === "tsx")) ? (w = "reference", s[s.length - 1].push(v), M(I, v, !1)) : w = "word";
      } else if (r.stack.token !== "object" || r.stack.token === "object" && h !== "," && h !== "{") {
        let I = s.length, H = 0;
        if (I > 0) {
          do
            if (I = I - 1, H = s[I].length, H > 0) {
              do
                if (H = H - 1, v === s[I][H])
                  break;
              while (H > 0);
              if (v === s[I][H])
                break;
            }
          while (I > 0);
          s[I][H] === v && j !== "." ? w = "reference" : w = "word";
        } else
          w = "word";
      } else
        w = "word";
      h = v, v === "from" && e.token[r.count] === "}" && ee();
    }
    if (g(), v === "class" && b.push(0), v === "do" && (L = A(1, !0), L !== "{" && (h = n.correct === !0 ? "{" : "x{", w = "start", d.push("x{"), g("do"))), v === "else") {
      L = A(2, !0);
      let I = r.count - 1;
      if (e.types[I] === "comment")
        do
          I = I - 1;
        while (I > 0 && e.types[I] === "comment");
      e.token[I] === "x}" && (e.token[r.count] === "else" ? e.stack[r.count - 1] !== "if" && e.types[r.count - 1] !== "comment" && e.stack[r.count - 1] !== "else" ? (d.pop(), r.splice({
        data: e,
        howmany: 0,
        index: r.count - 1,
        record: {
          begin: e.begin[e.begin[e.begin[r.count - 1] - 1] - 1],
          ender: -1,
          lexer: "script",
          lines: 0,
          stack: "if",
          token: n.correct === !0 ? "}" : "x}",
          types: "end"
        }
      }), r.stack.length > 1 && (r.stack.splice(r.stack.length - 2, 1), r.stack.update(r.count))) : (e.token[r.count - 2] === "x}" && B[0] !== "if" && e.stack[r.count] === "else" || e.token[r.count - 2] === "}" && e.stack[r.count - 2] === "if" && B[0] === "if" && e.token[B[1] - 1] !== "if" && e.token[e.begin[r.count - 1]] === "x{") && E() : e.token[r.count] === "x}" && e.stack[r.count] === "if" && E()), L !== "if" && $(L, 123) && (h = n.correct === !0 ? "{" : "x{", w = "start", d.push("x{"), g("else"));
    }
    (v === "for" || v === "if" || v === "switch" || v === "catch") && e.token[r.count - 1] !== "." && (L = A(1, !0), L !== "(" && (a = r.count, n.correct === !0 ? Q("(") : Q("x(")));
  }
  function K() {
    r.lineOffset = 1;
    do {
      if (i(l[u], 10) && (r.lineIndex = u, r.lineOffset = r.lineOffset + 1, r.lineNumber = r.lineNumber + 1), le(l[u + 1]) === !1)
        break;
      u = u + 1;
    } while (u < N);
  }
  do
    le(l[u]) ? (z > -1 && y(), K(), r.lineOffset > 1 && ae < r.count && $(l[u + 1], 59) && $(l[u + 1], 125) && (P(!1), ae = r.count)) : i(l[u], 123) && i(l[u + 1], 37) ? re("{%", "%}", "liquid") : i(l[u], 123) && i(l[u + 1], 123) ? re("{{", "}}", "liquid") : i(l[u], 60) && i(l[u + 1], 33) && i(l[u + 2], 45) && i(l[u + 3], 45) ? re("<!--", "-->", "comment") : i(l[u], 60) ? se() : i(l[u], 47) && (u === N - 1 || i(l[u + 1], 42)) ? we() : (r.count < 0 || e.lines[r.count] > 0) && i(l[u], 35) && i(l[u + 1], 33) && (i(l[u + 2], 47) || i(l[u + 3], 91)) ? re("#!" + l[u + 2], Z, "string") : i(l[u], 47) && (u === N - 1 || i(l[u + 1], 47)) ? oe() : i(l[u], 96) || i(l[u], 125) && r.stack.token === "template_string" ? (z > -1 && y(), h = V(), i(h, 125) && h.slice(h.length - 2) === "${" ? (w = "template_string_else", g("template_string")) : h.slice(h.length - 2) === "${" ? (w = "template_string_start", g("template_string")) : i(h[0], 125) ? (w = "template_string_end", g()) : (w = "string", g())) : i(l[u], 34) || i(l[u], 39) ? re(l[u], l[u], "string") : i(l[u], 45) && u < N - 1 && $(l[u + 1], 61) && $(l[u + 1], 45) && (w === "number" || w === "word" || w === "reference") && h !== "return" && (w === "word" || w === "reference" || w === "number" || i(h, 41) || i(h, 93)) ? (z > -1 && y(), h = "-", w = "operator", g()) : z === -1 && (l[u] !== "0" || l[u] === "0" && l[u + 1] !== "b") && (Ee(l[u]) || u !== N - 2 && i(l[u], 45) && i(l[u + 1], 46) && Ee(l[u + 2]) || u !== N - 1 && (i(l[u], 45) || i(l[u], 46)) && Ee(l[u + 1])) ? (z > -1 && y(), w === "end" && i(l[u], 45) ? (h = "-", w = "operator") : (h = J(), w = "number"), g()) : i(l[u], 58) && i(l[u + 1], 58) ? (z > -1 && y(), n.correct === !0 && D(), ee(), u = u + 1, h = "::", w = "separator", g()) : i(l[u], 44) ? (z > -1 && y(), n.correct === !0 && D(), f[f.length - 1] === !0 && e.stack[r.count].indexOf("type") < 0 && (f[f.length - 1] = !1), w === "comment" ? Be() : R > -1 && W.count[R] === 0 && O.variableList === "each" ? (ee(), h = ";", w = "separator", g(), h = W.word[R], w = "word", g(), W.index[R] = r.count) : (h = ",", w = "separator", ee(), g())) : i(l[u], 46) ? (z > -1 && y(), f[f.length - 1] = !1, i(l[u + 1], 46) && i(l[u + 2], 46) ? (h = "...", w = "operator", u = u + 2) : (ee(), h = ".", w = "separator"), le(l[u - 1]) && (r.lineOffset = 1), g()) : i(l[u], 59) ? (z > -1 && y(), f[f.length - 1] === !0 && e.stack[r.count].indexOf("type") < 0 && (f[f.length - 1] = !1), b[b.length - 1] === 0 && b.pop(), R > -1 && W.count[R] === 0 && (O.variableList === "each" ? q() : W.index[R] = r.count + 1), n.correct === !0 && D(), h = ";", w = "separator", e.token[r.count] === "x}" ? ke() : g(), ge()) : i(l[u], 40) || i(l[u], 91) || i(l[u], 123) ? Q(l[u]) : i(l[u], 41) || i(l[u], 93) || i(l[u], 125) ? Se(l[u]) : z < 0 && e.stack[r.count] === "object" && i(l[u], 42) && $(l[u + 1], 61) && Ee(l[u + 1]) === !1 && le(l[u + 1]) === !1 ? z = u : i(l[u], 61) || i(l[u], 38) || i(l[u], 60) || i(l[u], 62) || i(l[u], 43) || i(l[u], 45) || i(l[u], 42) || i(l[u], 47) || i(l[u], 33) || i(l[u], 63) || i(l[u], 124) || i(l[u], 94) || i(l[u], 58) || i(l[u], 37) || i(l[u], 94) ? (h = X(), h === "regex" ? h = e.token[r.count] : i(h, 42) && e.token[r.count] === "function" ? e.token[r.count] = "function*" : (w = "operator", $(h, 33) && h !== "++" && h !== "--" && ee(), g())) : z < 0 && l[u] !== p && (z = u), R > -1 && r.count === W.index[R] + 1 && i(e.token[W.index[R]], 59) && h !== W.word[R] && w !== "comment" && O.variableList === "list" && q(), u = u + 1;
  while (u < N);
  return z > -1 && y(), ($(e.token[r.count], 125) && i(e.token[0], 123) || $(e.token[0], 123)) && ($(e.token[r.count], 93) && i(e.token[0], 91) || $(e.token[0], 91)) && P(!1), t[0] === r.count && (h = Z + t[1], w = "string", g()), e.token[r.count] === "x;" && (i(e.token[r.count - 1], 125) || i(e.token[r.count - 1], 93)) && e.begin[r.count - 1] === 0 && r.pop(e), O.objectSort && e.begin.length > 0 && vt(0, r.count + 1), e;
}

// src/lexers/style.ts
function Ti() {
  let { data: e, rules: s, source: n } = r, c = n.split(p), O = n.length, l = [], N = [], o = 0, d = p, b = p;
  function t(a) {
    r.push(e, {
      begin: r.stack.index,
      ender: -1,
      lexer: "style",
      lines: r.lineOffset,
      stack: r.stack.token,
      token: b,
      types: d
    }, a);
  }
  function f(a) {
    let C = a;
    do
      a = a - 1;
    while (i(c[a], 92) && a > 0);
    return (C - a) % 2 === 1;
  }
  function W(a) {
    let C = a.replace(/\s*!important/, " !important").split(p), F = /-?transition$/.test(e.token[r.count - 2]), B = [], G = /(\s|\(|,)-?0+\.?\d+([a-z]|\)|,|\s)/g, ie = /(\s|\(|,)-?\.?\d+([a-z]|\)|,|\s)/g, q = 0, g = 0, A = p, _ = C.length, P = [], ee = (X) => X;
    function ke(X) {
      return X = X.replace(/\s*/g, p), /\/\d/.test(X) && a.indexOf("url(") === 0 ? X : ` ${X.charAt(0)} ${X.charAt(1)}`;
    }
    function we(X) {
      return s.style.noLeadZero === !0 ? X.replace(/^-?\D0+(\.|\d)/, (V) => V.replace(/0+/, p)) : /0*\./.test(X) ? X.replace(/0*\./, "0.") : /0+/.test(/\d+/.exec(X)[0]) ? /^\D*0+\D*$/.test(X) ? X.replace(/0+/, "0") : X.replace(/\d+/.exec(X)[0], /\d+/.exec(X)[0].replace(/^0+/, p)) : X;
    }
    function oe(X) {
      return X.replace(",", ", ");
    }
    function T(X) {
      return `${X} `;
    }
    function J() {
      let X = q - 1, V = X;
      if (X < 1)
        return !0;
      do
        V = V - 1;
      while (V > 0 && i(C[V], 92));
      return (X - V) % 2 === 1;
    }
    if (q < _)
      do
        P.push(C[q]), ($(C[q - 1], 92) || J() === !1) && (A === p ? i(C[q], 34) ? (A = Ce, g = g + 1) : i(C[q], 39) ? (A = ve, g = g + 1) : i(C[q], 40) ? (A = ")", g = g + 1) : i(C[q], 91) && (A = "]", g = g + 1) : i(C[q], 40) && i(A, 41) || i(C[q], 91) && i(A, 93) ? g = g + 1 : C[q] === A && (g = g - 1, g === 0 && (A = p))), A === p && i(C[q], 32) && (P.pop(), B.push(ee(P.join(p))), P = []), q = q + 1;
      while (q < _);
    if (B.push(ee(P.join(p))), _ = B.length, q = 0, q < _)
      do
        s.style.noLeadZero === !0 && /^-?0+\.\d+[a-z]/.test(B[q]) === !0 ? B[q] = B[q].replace(/0+\./, ".") : s.style.noLeadZero === !1 && /^-?\.\d+[a-z]/.test(B[q]) ? B[q] = B[q].replace(".", "0.") : G.test(B[q]) || ie.test(B[q]) ? B[q] = B[q].replace(G, we).replace(ie, we) : /^(0+([a-z]{2,3}|%))$/.test(B[q]) && F === !1 ? B[q] = "0" : /^(0+)/.test(B[q]) ? (B[q] = B[q].replace(/0+/, "0"), /\d/.test(B[q].charAt(1)) && (B[q] = B[q].substr(1))) : /^url\((?!('|"))/.test(B[q]) && B[q].charCodeAt(B[q].length - 1) === 41 && (A = B[q].charAt(B[q].indexOf("url(") + 4), A !== "@" && $(A, 40) && $(A, 60) && (s.style.quoteConvert === "double" ? B[q] = B[q].replace(/url\(/, 'url("').replace(/\)$/, '")') : B[q] = B[q].replace(/url\(/, "url('").replace(/\)$/, "')"))), /^(\+|-)?\d+(\.\d+)?(e-?\d+)?\D+$/.test(B[q]) && (ye.css.units.has(B[q].replace(/(\+|-)?\d+(\.\d+)?(e-?\d+)?/, p)) || (B[q] = B[q].replace(/(\+|-)?\d+(\.\d+)?(e-?\d+)?/, T))), /^\w+\(/.test(B[q]) && B[q].charAt(B[q].length - 1) === ")" && (B[q].indexOf("url(") !== 0 || B[q].indexOf("url(") === 0 && B[q].indexOf(Y) > 0) && (B[q] = B[q].replace(/,\S/g, oe)), q = q + 1;
      while (q < _);
    return A = B.join(Y), A.charAt(0) + A.slice(1).replace(/\s*(\/|\+|\*)\s*(\d|\$)/, ke);
  }
  function R() {
    let a = [], C = [], F = s.style.quoteConvert, B = o, G = 0, ie = p, q = null, g = !1;
    function A() {
      if (C.push(c[B]), le(c[B + 1]))
        do
          B = B + 1;
        while (B < O && le(c[B + 1]));
    }
    if (B < O)
      do {
        if (i(c[B], 34) || i(c[B], 39) ? (q === null && (q = !1), a[a.length - 1] === c[B] && ($(c[B - 1], 92) || f(B - 1) === !1) ? (a.pop(), F === "double" ? c[B] = Ce : F === "single" && (c[B] = ve)) : $(a[a.length - 1], 34) && $(a[a.length - 1], 39) && ($(c[B - 1], 92) || f(B - 1) === !1) ? (a.push(c[B]), F === "double" ? c[B] = Ce : F === "single" && (c[B] = ve)) : i(c[B - 1], 92) && F !== "none" ? f(B - 1) === !0 && (F === "double" && i(c[B], 39) || F === "single" && i(c[B], 34)) && C.pop() : F === "double" && i(c[B], 34) ? c[B] = '\\"' : F === "single" && i(c[B], 39) && (c[B] = "\\'"), C.push(c[B])) : $(c[B - 1], 92) || f(B - 1) === !1 ? i(c[B], 40) ? (q === null && (q = !0), a.push(")"), A()) : i(c[B], 91) ? (q = !1, a.push("]"), A()) : (i(c[B], 35) || i(c[B], 64)) && i(c[B + 1], 123) ? (q = !1, C.push(c[B]), B = B + 1, a.push("}"), A()) : c[B] === a[a.length - 1] ? (C.push(c[B]), a.pop()) : C.push(c[B]) : C.push(c[B]), r.stack.token === "map" && a.length === 0 && (i(c[B + 1], 44) || i(c[B + 1], 41)))
          if (i(c[B + 1], 41) && i(e.token[r.count], 40))
            r.pop(e), r.stack.pop(), C.splice(0, 0, "(");
          else
            break;
        if (i(c[B + 1], 58)) {
          if (G = B, le(c[G]))
            do
              G = G - 1;
            while (le(c[G]));
          e.types[r.count] !== "start" && (ie = c.slice(G - 6, G + 1).join(p), (ie.indexOf("filter") === ie.length - 6 || ie.indexOf("progid") === ie.length - 6) && (ie = "filter"));
        }
        if (a.length === 0) {
          if (i(c[B + 1], 59) && f(B + 1) === !0 || i(c[B + 1], 58) && $(c[B], 58) && $(c[B + 2], 58) && ie !== "filter" && ie !== "progid" || i(c[B + 1], 123) || i(c[B + 1], 125) || i(c[B + 1], 47) && (i(c[B + 2], 42) || i(c[B + 2], 47))) {
            if (G = C.length - 1, le(C[G]))
              do
                G = G - 1, B = B - 1, C.pop();
              while (le(C[G]));
            break;
          }
          if (i(c[B + 1], 44))
            break;
        }
        B = B + 1;
      } while (B < O);
    o = B, r.stack.token === "map" && i(C[0], 40) && (l[l.length - 1] = l[l.length - 1] - 1), b = C.join(p).replace(/\s+/g, Y).replace(/^\s/, p).replace(/\s$/, p), q === !0 && (r.count > -1 && ye.css.atrules(b) && s.style.atRuleSpace === !0 ? e.token[r.count] = e.token[r.count].replace(/\s*\(/g, " (").replace(/\s*\)\s*/g, ") ").replace(/,\(/g, ", (") : b = b.replace(/\s+\(/g, "(").replace(/\s+\)/g, ")").replace(/,\(/g, ", (")), d === "colon" && e.types[r.count - 1] === "start" ? ye.css.pseudoClasses.has(b) && (e.token[r.count] = b = ":" + b, d = "pseudo", g = !0) : r.count > -1 && e.token[r.count].indexOf("extend(") === 0 ? d = "pseudo" : q === !0 && Ee(b.charAt(0)) === !1 && /^rgba?\(/.test(b) === !1 && b.indexOf("url(") !== 0 && (b.indexOf(Y) < 0 || b.indexOf(Y) > b.indexOf("(")) && b.charAt(b.length - 1) === ")" ? (i(e.token[r.count], 58) ? d = "value" : (b = b.replace(/,\u0020?/g, ", "), d = "function"), b = W(b)) : r.count > -1 && ve.indexOf(e.token[r.count].charAt(0)) > -1 && e.types[r.count] === "variable" ? d = "item" : i(C[0], 64) || C[0] === "$" ? (e.types[r.count] === "colon" && s.language === "css" && (e.types[r.count - 1] === "property" || e.types[r.count - 1] === "variable") ? d = "value" : r.count > -1 && (d = "item", ie = e.token[r.count], B = ie.indexOf("("), i(ie[ie.length - 1], 41) && B > 0 && (ie = ie.slice(B + 1, ie.length - 1), e.token[r.count] = e.token[r.count].slice(0, B + 1) + W(ie) + ")")), b = W(b)) : d = "item", g === !1 ? t(p) : g = !1;
  }
  function u(a) {
    let C = r.count, F = 0, B = p, G = [];
    function ie() {
      if (!(r.count < 0)) {
        if (C > 0 && (e.types[C] === "comment" || e.types[C] === "ignore"))
          do
            C = C - 1, G.push(e.token[C]);
          while (C > 0 && e.lexer[C] === "style" && (e.types[C] === "comment" || e.types[C] === "ignore"));
        if (F = C - 1, F > 0 && (e.types[F] === "comment" || e.types[F] === "ignore"))
          do
            F = F - 1;
          while (F > 0 && e.lexer[C] === "style" && (e.types[F] === "comment" || e.types[F] === "ignore"));
        F < 0 && (F = 0), C < 0 && (C = 0), B = e.token[C][0];
      }
    }
    function q(A) {
      return A.replace(/\s*&/, " &").replace(/\s*&\s*{/, " & {").replace(/\s*>\s*/g, " > ").replace(/\s*\+\s*/g, " + ");
    }
    function g(A) {
      let _ = A, P = e.begin[_];
      if (e.token[A] = e.token[A].replace(/\s*&/, " &").replace(/\s*&\s*{/, " & {").replace(/\s*>\s*/g, " > ").replace(/\s*\+\s*/g, " + ").replace(/:\s+/g, ": ").replace(/^\s+/, p).replace(/\s+$/, p).replace(/\s+::\s+/, "::"), i(e.token[_], 64) && (e.token[A] = e.token[A].replace(/(\(\s*[a-z-]+\s*)(:)(\S)/g, "$1$2 $3")), $(e.token[_], 44) && e.types[_] !== "comment" && (e.types[_] = "selector"), i(e.token[_ - 1], 44) || i(e.token[_ - 1], 58) || e.types[_ - 1] === "comment" || e.types[_ - 1] === "pseudo")
        if (e.types[_ - 1] === "colon" && (e.types[_] === "selector" || e.types[_] === "at_rule") && (e.types[_ - 2] === "template" || e.types[_ - 2] === "liquid_start" || e.types[_ - 2] === "liquid_else" || e.types[_ - 2] === "liquid_end"))
          e.token[_ - 1] = ":" + e.token[_] + Y, e.types[_ - 1] = "selector", r.splice({
            data: e,
            howmany: 1,
            index: _
          });
        else if (e.types[_ - 1] === "pseudo")
          e.token[_ - 1] = `${e.token[_ - 1]}${e.token[_]}`, e.types[_ - 1] = "selector", r.splice({
            data: e,
            howmany: 1,
            index: _
          });
        else if (e.types[_ - 2] === "comment")
          e.token[_ - 1] = q(`${e.token[_ - 1]}${e.token[_]}`), e.types[_ - 1] = "selector", r.splice({
            data: e,
            howmany: 1,
            index: _
          });
        else
          do
            if (_ = _ - 1, e.begin[_] === P) {
              if (i(e.token[_], 59))
                break;
              $(e.token[_], 44) && e.types[_] !== "comment" && (e.types[_] = "selector"), e.token[_] === ":" && $(e.token[_ - 1], 59) && (e.token[_ - 1] = q(`${e.token[_ - 1]}:${e.token[_ + 1]}`), r.splice({
                data: e,
                howmany: 2,
                index: _
              }));
            } else
              break;
          while (_ > 0);
      if (_ = r.count, s.style.sortSelectors === !0 && i(e.token[_ - 1], 44)) {
        let ee = [e.token[_]];
        do {
          if (_ = _ - 1, e.types[_] === "comment" || e.types[_] === "ignore")
            do
              _ = _ - 1;
            while (_ > 0 && (e.types[_] === "comment" || e.types[_] === "ignore"));
          i(e.token[_], 44) && (_ = _ - 1), ee.push(e.token[_]);
        } while (_ > 0 && (i(e.token[_ - 1], 44) || e.types[_ - 1] === "selector" || e.types[_ - 1] === "comment" || e.types[_ - 1] === "ignore"));
        ee.sort(), _ = r.count, e.token[_] = ee.pop();
        do {
          if (_ = _ - 1, e.types[_] === "comment" || e.types[_] === "ignore")
            do
              _ = _ - 1;
            while (_ > 0 && (e.types[_] === "comment" || e.types[_] === "ignore"));
          i(e.token[_], 44) && (_ = _ - 1), e.token[_] = ee.pop();
        } while (_ > 0 && (i(e.token[_ - 1], 44) || e.types[_ - 1] === "selector" || e.types[_ - 1] === "comment" || e.types[_ - 1] === "ignore"));
      }
      C = r.count, ie();
    }
    if (ie(), a === "start" && (e.types[C] === "value" || e.types[C] === "variable") && (e.types[C] = "item"), e.lexer[r.count - 1] !== "style" || F < 0)
      a === "colon" ? i(B, 36) || i(B, 64) ? e.types[C] = "variable" : e.stack[C] !== "global" && (e.types[C] !== "comment" || e.types[C] !== "ignore") && (e.types[C] = "property") : e.lexer[C] === "style" && (e.types[C] = "selector", g(C));
    else if (a === "start" && e.types[C] === "function" && e.lexer[C] === "style")
      e.types[C] = "selector", g(C);
    else if (e.types[C] === "item" && e.lexer[C] === "style")
      if (a === "start")
        g(C), e.types[C] = "selector", e.token[C] === ":" && (e.types[F] = "selector"), e.token[C].indexOf("=\u201C") > 0 ? r.error = `Invalid Quote (\u201C, \\201c) used on line number ${r.lineNumber}` : e.token[C].indexOf("=\u201D") > 0 && (r.error = `Invalid Quote (\u201D, \\201d) used on line number ${r.lineNumber}`);
      else if (a === "end")
        i(B, 36) || i(B, 64) ? e.types[C] = "variable" : e.types[C] = "value", e.token[C] = W(e.token[C]);
      else if (a === "separator")
        if (e.types[F] === "colon" || i(e.token[F], 44) || i(e.token[F], 123)) {
          if ($(c[o], 59) && (e.types[F] === "selector" || e.types[F] === "at_rule" || i(e.token[F], 123)))
            e.types[C] = "selector", g(C);
          else if (i(e.token[C], 36) || i(e.token[C], 64))
            e.types[C] = "variable";
          else if (i(e.token[F], 58) && e.token[C] === "root") {
            e.types[F] = "selector", e.token[F] = e.token[F] + e.token[C], r.pop(e);
            return;
          } else
            e.types[C] = "value";
          e.token[C] = W(e.token[C]), e.token[C].charAt(0) === "\u201C" ? r.error = `Invalid Quote (\u201C, \\201c) used on line number ${r.lineNumber}` : e.token[C].charAt(0) === "\u201D" && (r.error = `Invalid (\u201D, \\201d) used on line number ${r.lineNumber}`);
        } else
          i(B, 36) || i(B, 64) ? e.types[C] = "variable" : e.types[F] === "value" || e.types[F] === "variable" ? (e.token[F] = e.token[F] + e.token[C], r.pop(e)) : e.types[C] = "value";
      else
        a === "colon" ? i(B, 36) || i(B, 64) ? e.types[C] = "variable" : e.types[C] = "property" : i(e.token[F], 64) && (e.types[F - 2] !== "variable" && e.types[F - 2] !== "property" || e.types[F - 1] === "separator") ? (e.types[F] = "variable", d = "variable", e.token[F] = W(e.token[F])) : a === "comment" && (i(B, 46) || i(B, 35)) && (e.types[C] = "selector");
  }
  function h() {
    let a = r.count;
    do
      a = a - 1;
    while (a > 0 && e.types[a] === "comment");
    e.token[a] !== ";" && r.splice({
      data: e,
      howmany: 0,
      index: a + 1,
      record: {
        begin: r.stack.index,
        ender: -1,
        lexer: "style",
        lines: r.lineOffset,
        stack: r.stack.token,
        token: ";",
        types: "separator"
      }
    });
  }
  function w(a, C) {
    let F = [], B = p, G = p, ie = 0, q = a.length;
    function g(A) {
      let _ = r.count > 0 ? e.types[r.count - 1] : e.types[r.count];
      d === "item" && (_ === "colon" ? e.types[r.count] = "value" : u(_)), i(c[o + 1], 32), d = A, b = jt(b, G, s.liquid), d.indexOf("start") > -1 || d.indexOf("else") > -1 ? t(b) : t(p);
    }
    if (N[N.length - 1] = !0, o < O)
      do {
        if (F.push(c[o]), B === p) {
          if (i(c[o], 34))
            B = Ce;
          else if (i(c[o], 39))
            B = ve;
          else if (i(c[o], 47))
            i(c[o + 1], 47) ? B = "/" : i(c[o + 1], 42) && (B = "*");
          else if (i(C, c[o + 1].charCodeAt(0))) {
            do
              ie = ie + 1, o = o + 1, F.push(c[o]);
            while (o < O && ie < C.length && c[o + 1] === C.charAt(ie));
            if (ie === C.length) {
              if (B = F.join(p), le(B.charAt(q)))
                do
                  q = q + 1;
                while (le(B.charAt(q)));
              ie = q;
              do
                ie = ie + 1;
              while (ie < C.length && !le(B.charAt(ie)));
              if (ie === B.length && (ie = ie - C.length), a === "{%" && (G = _e(B)), d === "item" && e.types[r.count - 1] === "colon" && (e.types[r.count - 2] === "property" || e.types[r.count - 2] === "variable")) {
                d = "value", e.types[r.count] = "value", Number.isNaN(Number(e.token[r.count])) === !0 && e.token[r.count].charAt(e.token[r.count].length - 1) !== ")" ? e.token[r.count] = e.token[r.count] + B : e.token[r.count] = e.token[r.count] + Y + B;
                return;
              }
              if (b = B, a === "{%") {
                let A = Array.from(ye.liquid.tags), _ = A.length - 1, P = G.slice(0, G.indexOf(Y) + 1);
                if (P.indexOf("(") > 0 && (G = P.slice(0, P.indexOf("("))), ye.liquid.else.has(G)) {
                  g("liquid_else");
                  return;
                }
                if (_ = A.length - 1, _ > -1)
                  do {
                    if (G === A[_]) {
                      g("liquid_start");
                      return;
                    }
                    if (G === "end" + A[_]) {
                      g("liquid_end");
                      return;
                    }
                    _ = _ - 1;
                  } while (_ > -1);
              } else if (a === "{{") {
                let A = B.slice(2), _ = A.length, P = 0;
                do
                  P = P + 1;
                while (P < _ && le(A.charAt(P)) === !1 && A.charCodeAt(q) !== 40);
                if (A = A.slice(0, P), i(A[A.length - 2], 125) && (A = A.slice(0, A.length - 2)), A === "end") {
                  g("liquid_end");
                  return;
                }
              }
              g("liquid");
              return;
            }
            ie = 0;
          }
        } else
          B === c[o] && (i(B, 34) || i(B, 39) ? B = p : i(B, 47) && (i(c[o], 13) || i(c[o], 10)) ? B = p : i(B, 42) && i(c[o + 1], 47) && (B = p));
        o = o + 1;
      } while (o < O);
  }
  function x(a) {
    let C;
    a ? (C = Bt({
      chars: c,
      start: o,
      end: O,
      lexer: "style",
      begin: "//",
      ender: Z
    }), b = C[0], d = qt.test(b) ? "ignore" : "comment") : (C = ut({
      chars: c,
      start: o,
      end: O,
      lexer: "style",
      begin: "/*",
      ender: "*/"
    }), b = C[0], d = yi.test(b) ? "ignore" : "comment"), t(p), o = C[1];
  }
  function ae() {
    let a = r.lineOffset, C = {
      data: {
        margin: [
          p,
          p,
          p,
          p,
          !1
        ],
        padding: [
          p,
          p,
          p,
          p,
          !1
        ]
      },
      last: {
        margin: 0,
        padding: 0
      },
      removes: []
    }, F = r.stack.index;
    function B(g) {
      if (e.token[ie - 2] === g) {
        let A = e.token[ie].replace(/\s*!important\s*/g, p).split(Y), _ = A.length;
        e.token[ie].indexOf("!important") > -1 && (C.data[g[4]] = !0), _ > 3 ? (C.data[g][0] === p && (C.data[g][0] = A[0]), C.data[g][1] === p && (C.data[g][1] = A[1]), C.data[g][2] === p && (C.data[g][2] = A[2]), C.data[g][3] === p && (C.data[g][3] = A[3])) : _ > 2 ? (C.data[g][0] === p && (C.data[g][0] = A[0]), C.data[g][1] === p && (C.data[g][1] = A[1]), C.data[g][2] === p && (C.data[g][2] = A[2]), C.data[g][3] === p && (C.data[g][3] = A[1])) : _ > 1 ? (C.data[g][0] === p && (C.data[g][0] = A[0]), C.data[g][1] === p && (C.data[g][1] = A[1]), C.data[g][2] === p && (C.data[g][2] = A[0]), C.data[g][3] === p && (C.data[g][3] = A[1])) : (C.data[g][0] === p && (C.data[g][0] = A[0]), C.data[g][1] === p && (C.data[g][1] = A[0]), C.data[g][2] === p && (C.data[g][2] = A[0]), C.data[g][3] === p && (C.data[g][3] = A[0]));
      } else if (e.token[ie - 2] === `${g}-bottom`)
        C.data[g][2] === p && (C.data[g][2] = e.token[ie]);
      else if (e.token[ie - 2] === `${g}-left`)
        C.data[g][3] === p && (C.data[g][3] = e.token[ie]);
      else if (e.token[ie - 2] === `${g}-right`)
        C.data[g][1] === p && (C.data[g][1] = e.token[ie]);
      else if (e.token[ie - 2] === `${g}-top`)
        C.data[g][0] === p && (C.data[g][0] = e.token[ie]);
      else
        return;
      C.removes.push([ie, g]), C.last[g] = ie;
    }
    function G() {
      let g = 0, A = p, _ = /^(0+([a-z]+|%))/, P = C.removes.length, ee = C.data.margin[0] !== p && C.data.margin[1] !== p && C.data.margin[2] !== p && C.data.margin[3] !== p, ke = C.data.padding[0] !== p && C.data.padding[1] !== p && C.data.padding[2] !== p && C.data.padding[3] !== p;
      function we(oe) {
        if (_.test(C.data[oe][0]) === !0 && (C.data[oe][0] = "0"), _.test(C.data[oe][1]) === !0 && (C.data[oe][1] = "0"), _.test(C.data[oe][2]) === !0 && (C.data[oe][2] = "0"), _.test(C.data[oe][3]) === !0 && (C.data[oe][3] = "0"), C.data[oe][0] === C.data[oe][1] && C.data[oe][0] === C.data[oe][2] && C.data[oe][0] === C.data[oe][3] ? A = C.data[oe][0] : C.data[oe][0] === C.data[oe][2] && C.data[oe][1] === C.data[oe][3] && C.data[oe][0] !== C.data[oe][1] ? A = `${C.data[oe][0]} ${C.data[oe][1]}` : C.data[oe][1] === C.data[oe][3] && C.data[oe][0] !== C.data[oe][2] ? A = `${C.data[oe][0]} ${C.data[oe][1]} ${C.data[oe][2]}` : A = `${C.data[oe][0]} ${C.data[oe][1]} ${C.data[oe][2]} ${C.data[oe][3]}`, C.data[oe[4]] === !0 && (A = `${A.replace(" !important", p)} !important`), C.last[oe] > r.count) {
          g = F < 1 ? 1 : F + 1;
          do {
            if (e.begin[g] === F && e.types[g] === "value" && e.token[g - 2].indexOf(oe) === 0) {
              C.last[oe] = g;
              break;
            }
            g = g + 1;
          } while (g < r.count);
        }
        e.token[C.last[oe]] = A, e.token[C.last[oe] - 2] = oe;
      }
      if (P > 1 && (ee === !0 || ke === !0))
        do
          C.removes[g][0] !== C.last.margin && C.removes[g][0] !== C.last.padding && (ee === !0 && C.removes[g][1] === "margin" || ke === !0 && C.removes[g][1] === "padding") && r.splice({
            data: e,
            howmany: e.types[C.removes[g][0] + 1] === "separator" ? 4 : 3,
            index: C.removes[g][0] - 2
          }), g = g + 1;
        while (g < P - 1);
      ee === !0 && we("margin"), ke === !0 && we("padding"), q === !0 && (F < 0 ? r.error = "Brace mismatch. There appears to be more closing braces than starting braces." : vt(F, r.count + 1));
    }
    let ie = r.count, q = !1;
    do
      ie = ie - 1, e.begin[ie] === F ? e.types[ie] === "value" && e.types[ie - 2] === "property" && (e.token[ie - 2].indexOf("margin") === 0 ? B("margin") : e.token[ie - 2].indexOf("padding") === 0 && B("padding")) : (q = !0, ie = e.begin[ie]);
    while (ie > F);
    G(), r.lineOffset = a;
  }
  function z() {
    r.lineOffset = 1;
    do {
      if (i(c[o], 10) && (r.lineIndex = o, r.lineOffset = r.lineOffset + 1, r.lineNumber = r.lineNumber + 1), le(c[o + 1]) === !1)
        break;
      o = o + 1;
    } while (o < O);
  }
  do
    le(c[o]) ? z() : i(c[o], 47) && i(c[o + 1], 42) ? x(!1) : i(c[o], 47) && i(c[o + 1], 47) ? x(!0) : i(c[o], 123) && i(c[o + 1], 37) ? w("{%", "%}") : i(c[o], 123) && i(c[o + 1], 123) ? w("{{", "}}") : i(c[o], 123) || i(c[o], 40) && i(e.token[r.count], 58) && e.types[r.count - 1] === "variable" ? (u("start"), d = "start", b = c[o], i(c[o], 40) ? (t("map"), l.push(0)) : e.types[r.count] === "at_rule" || e.types[r.count] === "selector" || e.types[r.count] === "variable" ? i(e.token[r.count], 64) ? (e.types[r.count] = "at_rule", t(e.token[r.count])) : t(e.token[r.count]) : e.types[r.count] === "colon" ? t(e.token[r.count - 1]) : t("block"), N.push(!1)) : i(c[o], 125) || c[o] === ")" && r.stack.token === "map" && l[l.length - 1] === 0 ? i(c[o], 125) && i(e.token[r.count - 1], 123) && e.types[r.count] === "item" && e.token[r.count - 2] !== void 0 && e.token[r.count - 2].charCodeAt(e.token[r.count - 2].length - 1) === 64 ? (e.token[r.count - 2] = e.token[r.count - 2] + "{" + e.token[r.count] + "}", r.pop(e), r.pop(e), r.stack.pop()) : (i(c[o], 41) && l.pop(), u("end"), i(c[o], 125) && $(e.token[r.count], 59) && (e.types[r.count] === "value" || e.types[r.count] === "function" || e.types[r.count] === "variable" && (i(e.token[r.count - 1], 58) || i(e.token[r.count - 1], 59)) ? (s.correct === !0 ? b = ";" : b = "x;", d = "separator", t(p)) : e.types[r.count] === "comment" && h()), N.pop(), b = c[o], d = "end", i(c[o], 125) && ae(), s.style.sortProperties === !0 && i(c[o], 125) && bt(e), t(p)) : i(c[o], 59) || i(c[o], 44) ? (e.types[r.count - 1] === "selector" || e.types[r.count - 1] === "at_rule" || e.types[r.count] !== "function" && i(e.token[r.count - 1], 125) ? u("start") : u("separator"), e.types[r.count] !== "separator" && f(o) === !0 && (b = c[o], d = "separator", t(p))) : r.count > -1 && i(c[o], 58) && e.types[r.count] !== "end" ? (u("colon"), b = ":", d = "colon", t(p)) : (r.stack.token === "map" && i(c[o], 40) && (l[l.length - 1] = l[l.length - 1] + 1), R()), o = o + 1;
  while (o < O);
  return s.style.sortProperties === !0 && bt(e), e;
}

// src/lexers/index.ts
function Yt(e) {
  if (e === 1)
    return Kt();
  if (e === 3)
    return Ti();
  if (e === 2)
    return Wi();
}

// src/format/markup.ts
function Mi() {
  let { rules: e } = r, { lineBreakValue: s } = e.markup, n = r.start, c = -1, O = 0, l = 0, N = 0, o = isNaN(e.indentLevel) ? 0 : e.indentLevel, d = r.data, b = r.ender < 1 || r.ender > d.token.length ? d.token.length : r.ender + 1, t = {}, f = e.language === "jsx" || e.language === "tsx", W = /* @__PURE__ */ new Map(), R = r.start > 0 ? Array(r.start).fill(0, 0, r.start) : [], u = ke(), h = F(), w = [];
  function x(T, J) {
    return d.types[T] === J;
  }
  function ae(T, J) {
    return d.token[T] === J;
  }
  function z(T, J) {
    return T > -1 && (d.types[T] || p).indexOf(J);
  }
  function a(T, J = !0) {
    let X = [], V = e.preserveLine + 1, se = Math.min(d.lines[n + 1] - 1, V), D = 0;
    if (T < 0 && (T = 0), J)
      do
        X.push(r.crlf), D = D + 1;
      while (D < se);
    if (T > 0) {
      D = 0;
      do
        X.push(h), D = D + 1;
      while (D < T);
    }
    return X.join(p);
  }
  function C() {
    let T, J = d.lines[n + 1];
    x(n, "comment") && (i(d.token[n][1], 37) && e.liquid.preserveComment === !1 || $(d.token[n][1], 37) && e.markup.preserveComment === !1) ? T = d.token[n].split(r.crlf).map((re) => re.trimStart()) : T = d.token[n].split(r.crlf);
    let X = x(n, "attribute"), V = T.length - 1, se = u[n - 1] > -1 ? X ? u[n - 1] + 1 : u[n - 1] : (() => {
      let re = n - 1, ge = re > -1 && z(re, "start") > -1;
      if (u[n] > -1 && x(n, "attribute"))
        return u[n] + 1;
      do {
        if (re = re - 1, u[re] > -1)
          return x(n, "content") && ge === !1 ? u[re] : u[re] + 1;
        z(re, "start") > -1 && (ge = !0);
      } while (re > 0);
      return re === -2 ? 0 : 1;
    })(), D = 0;
    d.lines[n + 1] = 0;
    do
      x(n, "comment") ? (D === 0 && (i(d.token[n][1], 37) && e.liquid.commentNewline === !0 || i(d.token[n][1], 37) === !1 && e.markup.commentNewline === !0) && (e.preserveLine === 0 || w.length > 0 && w[w.length - 1].lastIndexOf(Z) + 1 < 2) && w.push(a(se)), T[D] !== p ? (D > 0 && (i(d.token[n][1], 37) && e.liquid.commentIndent === !0 || i(d.token[n][1], 37) === !1 && e.markup.commentIndent === !0) && w.push(h), T[D + 1].trimStart() !== p ? w.push(T[D], a(se)) : w.push(T[D], Z)) : T[D + 1].trimStart() === p ? w.push(Z) : w.push(a(se))) : X ? s === "align" || s === "force-align" ? w.push(T[D].trim(), a(u[n])) : s === "indent" || s === "force-indent" ? w.push(T[D].trim(), a(se)) : (w.push(T[D]), s === "force-preserve" && (D + 1 === V || D === 0) ? w.push(a(u[n])) : w.push(r.crlf)) : w.push(T[D], a(se)), D = D + 1;
    while (D < V);
    if (X && $(T[V], 60) && W.get(n - 1) >= 2 && $e(T[V], 62) && e.markup.delimiterTerminus !== "inline") {
      W.delete(n - 1);
      let re = a(u[n - 1] - 1);
      w[w.length - 1] === re && w.push(e.indentChar.repeat(e.indentSize)), x(n - 1, "singleton") && Je(T[V], 47) ? w.push(T[V].slice(0, -2), re, "/>") : w.push(T[V].slice(0, -1), re, ">");
    } else
      w.push(T[V]);
    d.lines[n + 1] = J, x(n, "comment") && (x(n + 1, "liquid_end") || x(n - 1, "liquid_end")) ? w.push(a(u[n])) : u[n] === -10 ? w.push(Y) : w.push(a(u[n]));
  }
  function F() {
    let T = [e.indentChar], J = e.indentSize - 1, X = 0;
    if (X < J)
      do
        T.push(e.indentChar), X = X + 1;
      while (X < J);
    return T.join(p);
  }
  function B() {
    l > 0 && (O = l - 1);
    let T = n + 1, J = 0;
    if (x(T, void 0))
      return T - 1;
    if (x(T, "comment") || n < b - 1 && z(T, "attribute") > -1)
      do {
        if (x(T, "jsx_attribute_start")) {
          J = T;
          do {
            if (x(T, "jsx_attribute_end") && d.begin[T] === J)
              break;
            T = T + 1;
          } while (T < b);
        } else if (x(T, "comment") === !1 && z(T, "attribute") < 0)
          return T;
        T = T + 1;
      } while (T < b);
    return T;
  }
  function G() {
    let T = /(?!=)\/?>$/, J = d.token[n], X = T.exec(J);
    if (X === null)
      return;
    let V = n + 1, se = !1, D = e.markup.selfCloseSpace === !0 && X[0] === "/>" ? Y : p;
    d.token[n] = J.replace(T, p);
    do {
      if (x(V, "jsx_attribute_end") && d.begin[d.begin[V]] === n)
        se = !1;
      else if (d.begin[V] === n) {
        if (x(V, "jsx_attribute_start"))
          se = !0;
        else if (z(V, "attribute") < 0 && se === !1)
          break;
      } else if (se === !1 && (d.begin[V] < n || z(V, "attribute") < 0))
        break;
      V = V + 1;
    } while (V < b);
    x(V - 1, "comment_attribute") && (D = a(u[V - 2] - 1)), d.token[V - 1] = `${d.token[V - 1]}${D}${X[0]}`, x(V, "comment");
  }
  function ie() {
    if (x(n, "end") === !1 && $(d.token[n], 60) && W.get(d.begin[n]) >= 2 && $e(d.token[n], 62)) {
      W.delete(d.begin[n]);
      let T = a(u[n - 1] - 1).replace(/\n+/, Z), J = `${d.token[n].slice(0, -1)}${T}>`;
      x(d.begin[n], "singleton") && i(d.token[n][d.token[n].length - 2], 47) ? d.token[n] = `${d.token[n].slice(0, -2)}${T}/>` : d.token[n] = J;
    }
  }
  function q() {
    let T = d.begin[n], J = n;
    do
      if (J = J - 1, ae(J, "</li>") && ae(J - 1, "</a>") && d.begin[d.begin[J]] === T && d.begin[J - 1] === d.begin[J] + 1)
        J = d.begin[J];
      else
        return;
    while (J > T + 1);
    J = n;
    do
      J = J - 1, x(J + 1, "attribute") ? R[J] = -10 : ae(J, "</li>") === !1 && (R[J] = -20);
    while (J > T + 1);
  }
  function g() {
    let T = n, J = !1;
    if (d.lines[n + 1] === 0 && e.markup.forceIndent === !1) {
      do {
        if (d.lines[T] > 0) {
          J = !0;
          break;
        }
        T = T - 1;
      } while (T > c);
      T = n;
    } else
      J = !0;
    if (J === !0) {
      x(d.begin[T] - 1, "liquid") && (R[d.begin[T] - 1] = o);
      do
        R.push(o), T = T - 1;
      while (T > c);
      R[n] = o, (x(T, "attribute") || x(T, "liquid_attribute") || x(T, "jsx_attribute_start") || x(T, "start")) && x(n + 1, "comment") === !1 && x(n + 1, "start") === !1 && d.types[n + 1].startsWith("liquid") === !1 || x(n + 1, "liquid_end") ? R[T] = o + 1 : x(n + 1, "liquid_else") && (R[T] = o - 1);
    } else {
      do
        R.push(-20), T = T - 1;
      while (T > c);
      R[T] = -20;
    }
    c = -1;
  }
  function A() {
    let T = o;
    if (e.markup.forceIndent === !0 || e.markup.forceAttribute === !0) {
      R.push(o);
      return;
    }
    if (l < b && (z(l, "end") > -1 || z(l, "start") > -1) && d.lines[l] > 0 ? (R.push(o), T = T + 1, n > 0 && x(n, "singleton") && z(n - 1, "attribute") > -1 && x(d.begin[n - 1], "singleton") && (d.begin[n] < 0 || x(d.begin[n - 1], "singleton") && d.begin[d.ender[n] - 1] !== n ? R[n - 1] = o : R[n - 1] = o + 1)) : n > 0 && x(n, "singleton") && z(n - 1, "attribute") > -1 ? (R[n - 1] = o, N = d.token[n].length, R.push(-10)) : d.lines[l] === 0 ? R.push(-20) : (e.wrap === 0 || n < b - 2 && d.token[n] !== void 0 && d.token[n + 1] !== void 0 && d.token[n + 2] !== void 0 && d.token[n].length + d.token[n + 1].length + d.token[n + 2].length + 1 > e.wrap && z(n + 2, "attribute") > -1 || d.token[n] !== void 0 && d.token[n + 1] !== void 0 && d.token[n].length + d.token[n + 1].length > e.wrap) && (x(n + 1, "singleton") || x(n + 1, "liquid")) ? R.push(o) : (N = N + 1, R.push(-10)), n > 0 && z(n - 1, "attribute") > -1 && d.lines[n] < 1 && (R[n - 1] = -20), N > e.wrap) {
      let J = n, X = Math.max(d.begin[n], 0);
      if (x(n, "content") && e.markup.preserveText === !1) {
        let V = 0, se = d.token[n].replace(/\s+/g, Y).split(Y);
        do
          if (J = J - 1, R[J] < 0)
            V = V + d.token[J].length, R[J] === -10 && (V = V + 1);
          else
            break;
        while (J > 0);
        J = 0, X = se.length;
        do
          se[J].length + V > e.wrap ? (se[J] = r.crlf + se[J], V = se[J].length) : (se[J] = ` ${se[J]}`, V = V + se[J].length), J = J + 1;
        while (J < X);
        i(se[0], 32) ? d.token[n] = se.join(p).slice(1) : (R[n - 1] = T, d.token[n] = se.join(p).replace(r.crlf, p)), d.token[n].indexOf(r.crlf) > 0 && (N = d.token[n].length - d.token[n].lastIndexOf(r.crlf));
      } else {
        do {
          if (J = J - 1, R[J] > -1) {
            N = d.token[n].length, d.lines[n + 1] > 0 && (N = N + 1);
            return;
          }
          if (z(J, "start") > -1) {
            N = 0;
            return;
          }
          if (d.lines[J + 1] > 0 && (x(J, "attribute") === !1 || x(J, "attribute") && x(J + 1, "attribute")) && (x(J, "singleton") === !1 || x(J, "attribute") && x(J + 1, "attribute"))) {
            N = d.token[n].length, d.lines[n + 1] > 0 && (N = N + 1);
            break;
          }
        } while (J > X);
        R[J] = T;
      }
    }
  }
  function _() {
    let T = n;
    d.types[T - 1] === "script_start" && i(d.token[T - 1], 123) && (R[T - 1] = -20);
    do {
      if (d.lexer[n + 1] === "markup" && d.begin[n + 1] < T && x(n + 1, "start") === !1 && x(n + 1, "singleton") === !1)
        break;
      R.push(0), n = n + 1;
    } while (n < b);
    t[T] = n, d.types[n + 1] === "script_end" && d.token[n + 1] === "}" ? R.push(-20) : (d.types[n + 1], R.push(o - 1)), l = B(), d.lexer[l] === "markup" && d.stack[n].indexOf("attribute") < 0 && (d.types[l] === "end" || d.types[l] === "liquid_end") && (o = o - 1);
  }
  function P(T) {
    let J = d.token[T].replace(/\s+/g, Y).split(Y), X = J.length, V = 1, se = J[0].length;
    do
      se + J[V].length > e.wrap ? (se = J[V].length, J[V] = r.crlf + J[V]) : (J[V] = ` ${J[V]}`, se = se + J[V].length), V = V + 1;
    while (V < X);
    d.token[T] = J.join(p);
  }
  function ee() {
    let T = n - 1, J = n, X = !1, V = !1, se = z(T + 1, "end"), D = d.token[T].length + 1, re = 0, ge = (() => {
      if (z(n, "start") > 0) {
        let Se = n;
        do {
          if (x(Se, "end") && d.begin[Se] === n && Se < b - 1 && z(Se + 1, "attribute") > -1) {
            X = !0;
            break;
          }
          Se = Se + 1;
        } while (Se < b);
      } else
        n < b - 1 && z(n + 1, "attribute") > -1 && (X = !0);
      return x(l, "end") || x(l, "liquid_end") ? x(T, "singleton") ? o + 2 : o + 1 : x(T, "singleton") ? o + 1 : o;
    })();
    if (X === !1 && x(n, "comment_attribute")) {
      R.push(o), R[T] = d.types[T] === "singleton" ? o + 1 : o;
      return;
    }
    function Be(Se) {
      e.markup.forceAttribute === !1 ? R.push(-10) : e.markup.forceAttribute === !0 || Se >= e.markup.forceAttribute ? e.liquid.indentAttribute === !0 ? (x(n - 1, "liquid_attribute_start") && (R[n - 1] = ge + re), R.push(ge + re)) : R.push(ge) : R.push(-10);
    }
    ge < 1 && (ge = 1), se = 0;
    do
      se = se + 1;
    while (z(n + se, "attribute") > -1 && (x(n + se, "end") === !1 || x(n + se, "singleton") === !1 || x(n + se, "start") === !1 || x(n + se, "comment") === !1));
    (s === "force-preserve" || s === "force-align" || s === "force-indent") && (Ke(e.markup.forceAttribute) && e.markup.forceAttribute === !1 || st(e.markup.forceAttribute) && se <= e.markup.forceAttribute) && (se = 1 / 0);
    do {
      if (N = N + d.token[n].length + 1, d.types[n].indexOf("attribute") > 0)
        x(n, "comment_attribute") ? R.push(ge) : z(n, "start") > 0 && z(n, "liquid") < 0 ? (V = !0, n < b - 2 && d.types[n + 2].indexOf("attribute") > 0 ? (R.push(-20), n = n + 1, t[n] = n) : (T === n - 1 && X === !1 ? f ? R.push(-20) : R.push(ge) : f ? R.push(-20) : R.push(ge + 1), d.lexer[n + 1] !== "markup" && (n = n + 1, _()))) : e.liquid.indentAttribute === !0 ? x(n, "liquid_attribute_start") ? (re > 0 ? R.push(ge + re) : R.push(ge), re = re + 1) : x(n, "liquid_attribute_else") ? R[n - 1] = ge + re - 1 : x(n, "liquid_attribute_end") ? (re = re - 1, R[n - 1] = ge + re) : Be(se) : z(n, "end") > 0 && x(n, "liquid_attribute_end") === !1 ? (R[n - 1] !== -20 && (R[n - 1] = R[d.begin[n]] - 1), d.lexer[n + 1] !== "markup" ? R.push(-20) : R.push(ge)) : z(n, "liquid_attribute") > -1 ? (D = D + d.token[n].length + 1, e.markup.preserveAttribute === !0 ? R.push(-10) : e.markup.forceAttribute === !0 || e.markup.forceAttribute >= 1 || V === !0 || n < b - 1 && z(n + 1, "attribute") > -1 ? Be(se) : R.push(-10)) : R.push(ge);
      else if (x(n, "attribute"))
        D = D + d.token[n].length + 1, e.markup.preserveAttribute === !0 ? R.push(-10) : e.markup.forceAttribute === !0 || e.markup.forceAttribute >= 1 || V === !0 || n < b - 1 && z(n + 1, "attribute") > -1 ? Be(se) : R.push(-10);
      else if (d.begin[n] < T + 1)
        break;
      n = n + 1;
    } while (n < b);
    if (n = n - 1, z(n, "liquid") < 0 && z(n, "end") > -1 && z(n, "attribute") > 0 && x(T, "singleton") === !1 && R[n - 1] > 0 && X === !0 && (R[n - 1] = R[n - 1] - 1), R[n] !== -20 && (f === !0 && z(T, "start") > -1 && x(n + 1, "script_start") ? R[n] = ge : ae(n, "/") && R[n - 1] !== 10 ? R[n - 1] = -10 : R[n] = R[T]), e.markup.forceAttribute === !0)
      N = 0, R[T] = ge, se >= 2 && e.markup.delimiterTerminus === "force" && W.set(T, se);
    else if (e.markup.forceAttribute >= 1)
      if (se >= e.markup.forceAttribute) {
        R[T] = ge;
        let Se = n - 1;
        do
          (x(Se, "liquid") && R[Se] === -10 || x(Se, "attribute") && R[Se] === -10) && (R[Se] = ge), Se = Se - 1;
        while (Se > T);
        (e.markup.delimiterTerminus === "force" && se >= 2 || e.markup.delimiterTerminus === "adapt" && se === 1 / 0) && W.set(T, se);
      } else
        R[T] = -10;
    else
      R[T] = -10;
    if (e.markup.preserveAttribute === !0 || ae(T, "<%xml%>") || ae(T, "<?xml?>")) {
      N = 0;
      return;
    }
    if (J = n, J > T + 1) {
      if (e.markup.selfCloseSpace === !1 && (D = D - 1), D > e.wrap && e.wrap > 0 && e.markup.forceAttribute === !1) {
        R[T] = ge, N = d.token[n].length, J = J - 1;
        do
          d.token[J].length > e.wrap && le(d.token[J]) && P(J), (z(J, "liquid") > -1 && R[J] === -10 || x(J, "attribute") && R[J] === -10) && (R[J] = ge), J = J - 1;
        while (J > T);
      }
    } else
      e.wrap > 0 && x(n, "attribute") && d.token[n].length > e.wrap && le(d.token[n]) && P(n);
  }
  function ke() {
    do
      d.lexer[n] === "markup" ? (x(n, "doctype") && (R[n - 1] = o), z(n, "attribute") > -1 ? ee() : x(n, "comment") ? (c < 0 && (c = n), g()) : x(n, "comment") === !1 && (l = B(), (x(l, "end") || x(l, "liquid_end") && x(n, "liquid_else") === !1) && (o > -1 && (o = o - 1), (ae(n, "</ol>") || ae(n, "</ul>") || ae(n, "</dl>")) && q()), x(n, "script_end") && x(l, "end") ? d.lines[l] < 1 ? R.push(-20) : d.lines[l] > 1 ? R.push(o) : R.push(-10) : (e.markup.forceIndent === !1 || e.markup.forceIndent === !0 && x(l, "script_start")) && (x(n, "content") || x(n, "singleton") || x(n, "liquid")) ? (N = N + d.token[n].length, d.lines[l] > 0 && x(l, "script_start") ? R.push(-10) : e.wrap > 0 && x(n, "singleton") === !1 && (z(n, "liquid") < 0 || l < b && z(n, "liquid") > -1 && z(l, "liquid") < 0) ? A() : l < b && (z(l, "end") > -1 || z(l, "start") > -1) && (d.lines[l] > 0 || z(n, "liquid_") > -1) ? R.push(o) : d.lines[l] === 0 ? R.push(-20) : d.lines[l] === 1 ? R.push(-10) : R.push(o)) : x(n, "start") || x(n, "liquid_start") ? (o = o + 1, x(l, "liquid_when") && e.liquid.dedentTagList.includes("case") === !1 && (o = o + 1), f === !0 && ae(n + 1, "{") ? d.lines[l] === 0 ? R.push(-20) : d.lines[l] > 1 ? R.push(o) : R.push(-10) : x(n, "start") && x(l, "end") ? d.stack[n] === "liquid" || z(l - 1, "comment") > -1 ? R.push(o) : R.push(-20) : x(n, "start") && x(l, "script_start") ? R.push(-10) : e.markup.forceIndent === !0 ? R.push(o) : d.lines[l] === 0 && (x(l, "content") || x(l, "singleton") || x(n, "start") && x(l, "liquid")) ? R.push(-20) : R.push(o)) : e.markup.forceIndent === !1 && d.lines[l] === 0 && (x(l, "content") || x(l, "singleton")) || x(n + 2, "script_end") ? R.push(-20) : x(n, "liquid_when") ? (R[n - 1] = o - 1, R.push(o)) : x(n, "liquid_else") && x(l, "liquid_end") ? (o = o - 1, R[n - 1] = o, R.push(o)) : x(n, "liquid_else") && x(l, "liquid_else") ? (R[n - 1] = o - 1, R.push(o - 1)) : x(n, "liquid_else") && (x(l, "content") || x(l, "liquid")) ? (R[n - 1] = o - 1, R.push(o)) : e.markup.forceIndent === !0 && (x(n, "content") && (x(l, "liquid") || x(l, "content")) || x(n, "liquid") && (x(l, "content") || x(l, "liquid"))) ? d.lines[l] < 1 ? R.push(-20) : d.lines[l] > 1 ? R.push(o) : R.push(-10) : x(n, "liquid_start_bad") ? (o = o + 1, R.push(o)) : x(l, "liquid_end_bad") ? (o = o - 1, R.push(o)) : ae(n, "{% endcase %}") && e.liquid.dedentTagList.includes("case") === !1 ? (R[n - 1]--, o = o - 1) : x(l, "liquid_else") && R[n - 1] === o ? R.push(o - 1) : x(n, "liquid_else") && R[n - 1] === o && e.markup.forceIndent === !1 ? (R[n - 1] = o - 1, R.push(o)) : x(O, "liquid_start") && x(l, "liquid_end") && d.lines[l] === 0 ? R[n - 1] = -20 : R.push(o)), x(n, "content") === !1 && x(n, "singleton") === !1 && x(n, "liquid") === !1 && x(n, "attribute") === !1 && (N = 0)) : (N = 0, _()), n = n + 1;
    while (n < b);
    return R;
  }
  function we() {
    let T = d.token[n].split(Z), J = T.length, X = 0, V = Z;
    n - 1 > 0 || T[0].length === 2 || T[0].length, V += a(u[n - 1], !1) + "  ";
    do {
      if (X === 0)
        if (X + 1 === J - 1 && (T[X + 1].length === 2 || T[X + 1].length === 3)) {
          V.length > 1 && (V = V.slice(0, -2)), w.push(T[X], V, T[X + 1]);
          break;
        } else
          w.push(T[X], V);
      else
        X === J - 1 ? w.push(T[X]) : (X + 1 === J - 1 && (T[X + 1].length === 2 || T[X + 1].length === 3) && (V = V.slice(0, -2)), w.push(T[X], V));
      X = X + 1;
    } while (X < J);
  }
  function oe() {
    n = r.start;
    let T = e.indentLevel;
    do {
      if (d.lexer[n] === "markup")
        (x(n, "start") || x(n, "singleton") || x(n, "xml")) && n < b - 1 && z(n, "attribute") < 0 && De(d.types[n + 1]) === !1 && z(n + 1, "attribute") > -1 && G(), De(d.token[n]) === !1 && d.token[n].indexOf(r.crlf) > 0 && (x(n, "content") && e.markup.preserveText === !1 || x(n, "comment") || x(n, "attribute")) ? C() : x(n, "comment") && e.markup.preserveComment === !1 && (i(d.token[n][1], 37) && e.liquid.commentNewline === !0 || i(d.token[n][1], 37) === !1 && e.markup.commentNewline === !0) && (e.preserveLine === 0 || w.length > 0 && w[w.length - 1].lastIndexOf(Z) + 1 < 2) ? w.push(
          a(u[n]),
          w.pop(),
          d.token[n],
          a(u[n])
        ) : z(n, "_preserve") > -1 ? w.push(d.token[n]) : x(n + 1, "ignore") && x(n + 2, "ignore") ? (w.push(
          d.token[n],
          a(u[n]).replace(bi, p),
          d.token[n + 1],
          Xe(d.lines[n + 2] - 1 === 0 ? 1 : d.lines[n + 2] - 1, Z)
        ), n = n + 1) : (T = u[n], e.markup.delimiterTerminus === "force" && ie(), /\n/.test(d.token[n]) && z(n, "liquid") > -1 && !x(n, "liquid_end") ? we() : w.push(d.token[n]), u[n] === -10 && n < b - 1 ? w.push(Y) : u[n] > -1 && z(n + 1, "_preserve") < 0 && w.push(a(u[n])));
      else {
        r.start = n, r.ender = t[n], T > 0 && e.liquid.dedentTagList.includes(d.stack[n]) && (w.splice(w.length - 1, 1, a(u[n] - 1)), T = T - 1);
        let J = r.external(T);
        e.language === "jsx" && (d.types[n - 1] === "template_string_end" || d.types[n - 1] === "jsx_attribute_start" || d.types[n - 1] === "script_start") ? w.push(J) : (w.push(J), (e.markup.forceIndent || u[r.iterator] > -1 && n in t && t[n] > n) && (n = r.iterator, w.push(a(u[n])))), n !== r.iterator && (n = r.iterator);
      }
      n = n + 1;
    } while (n < b);
    return r.iterator = b - 1, (w[0] === r.crlf || i(w[0], 32)) && (w[0] = p), e.endNewline === !0 ? w.join(p).replace(/\s*$/, r.crlf) : w.join(p).trimEnd();
  }
  return oe();
}

// src/format/script.ts
function _i() {
  let { data: e, rules: s } = r, n = r.language === "json" ? s.json : s.script, O = 0, l = {}, N = "script", o = r.ender < 1 || r.ender > e.token.length ? e.token.length : r.ender + 1, d = (() => {
    let t = r.start, f = s.indentLevel, W = !1, R = !1, u = p, h = p, w = e.types[0], x = e.token[0], ae = [-1], z = [], a = r.start > 0 ? Array(r.start).fill(0, 0, r.start) : [], C = [], F = [[]], B = [], G = [], ie = [], q = [!1], g = [], A = [];
    function _() {
      P(!1, !1);
      let Q = n.commentIndent === !0 ? f : 0;
      if (W === !1 && /\/\u002a\s*global\s/.test(e.token[t])) {
        let U = e.token[t].replace(/\/\u002a\s*global\s+/, p).replace(/\s*\u002a\/$/, p).split(","), y = U.length;
        do
          y = y - 1, U[y] = U[y].replace(/\s+/g, p), U[y] !== p && r.stack.push([U[y], -1]);
        while (y > 0);
      }
      if (e.types[t - 1] === "comment" || e.types[t + 1] === "comment")
        a[t - 1] = Q;
      else if (e.lines[t] < 2) {
        let U = t + 1;
        if (e.types[U] === "comment")
          do
            U = U + 1;
          while (U < o && e.types[U] === "comment");
        if (t < o - 1 && e.stack[U] !== "block" && (i(e.token[U], 123) || e.token[U] === "x{")) {
          let y = r.stack.length;
          if (e.begin.splice(t, 0, e.begin[U]), e.ender.splice(t, 0, e.ender[U]), e.lexer.splice(t, 0, e.lexer[U]), e.lines.splice(t, 0, e.lines[U]), e.stack.splice(t, 0, e.stack[U]), e.token.splice(t, 0, e.token[U]), e.types.splice(t, 0, e.types[U]), y > 0)
            do
              if (y = y - 1, r.stack[y][1] === U)
                r.stack[y][1] = t;
              else if (r.stack[y][1] < t)
                break;
            while (y > 0);
          U = U + 1, e.begin.splice(U, 1), e.ender.splice(U, 1), e.lexer.splice(U, 1), e.lines.splice(U, 1), e.stack.splice(U, 1), e.token.splice(U, 1), e.types.splice(U, 1), y = t + 1;
          do
            e.begin[y] = t, e.stack[y] = e.stack[U], y = y + 1;
          while (y < U);
          y = y + 1;
          do {
            if (e.begin[y] === e.begin[U] && (e.begin[y] = t, e.types[y] === "end"))
              break;
            y = y + 1;
          } while (y < o - 1);
          e.begin[U] = t, t = t - 1;
        } else
          a[t - 1] = -10, e.stack[t] === "paren" || e.stack[t] === "method" ? a.push(f + 2) : a.push(f), n.commentIndent === !0 && a[t] > -1 && e.lines[t] < 3 && (e.lines[t] = 3);
        e.types[t + 1] !== "comment" && (W = !0);
        return;
      } else
        i(e.token[t - 1], 44) ? a[t - 1] = Q : i(x, 61) && e.types[t - 1] !== "comment" && /^\/\*{2}\s*@[A-Za-z_]+/.test(h) === !0 ? a[t - 1] = -10 : i(x, 123) && e.types[t - 1] !== "comment" && e.lines[0] < 2 ? e.stack[t] === "function" ? a[t - 1] = Q : a[t - 1] = /\n/.test(h) ? Q : -10 : a[t - 1] = Q;
      e.types[t + 1] !== "comment" && (W = !0), i(e.token[e.begin[t]], 40) ? a.push(f + 1) : a.push(f), a[t] > -1 && e.lines[t] < 3 && (e.types[t - 1] === "comment" && h.startsWith("//") ? e.lines[t] = 2 : e.lines[t] = 3), n.commentNewline === !0 && h.startsWith("//") === !1 && e.lines[t] >= 3 && (e.lines[t] = 2);
    }
    function P(Q, U) {
      let y = t - 1, K = Q === !0 ? 0 : 1, k = F[F.length - 1] === void 0 ? [] : F[F.length - 1], m = U === !1 && e.stack[t] === "array" && Q === !0 && $(h, 91);
      if (!(G[G.length - 1] === !1 || e.stack[t] === "array" && n.arrayFormat === "inline" || e.stack[t] === "object" && n.objectIndent === "inline")) {
        G[G.length - 1] = !1;
        do {
          if (e.types[y] === "end" ? K = K + 1 : e.types[y] === "start" && (K = K - 1), e.stack[y] === "global")
            break;
          if (K === 0) {
            if (e.stack[t] === "class" || e.stack[t] === "map" || m === !1 && (Q === !1 && e.token[y] !== "(" && e.token[y] !== "x(" || Q === !0 && i(e.token[y], 44)))
              e.types[y + 1] === "liquid_start" ? e.lines[y] < 1 ? a[y] = -20 : a[y] = f - 1 : k.length > 0 && k[k.length - 1] > -1 ? a[y] = f - 1 : a[y] = f;
            else if (e.stack[t] === "array" && e.types[t] === "operator" && (i(e.token[y], 44) && (a[y] = f), y === e.begin[t]))
              break;
            if (Q === !1)
              break;
          }
          if (K < 0) {
            e.types[y + 1] === "liquid_start" || e.types[y + 1] === "template_string_start" ? e.lines[y] < 1 ? a[y] = -20 : a[y] = f - 1 : k.length > 0 && k[k.length - 1] > -1 ? a[y] = f - 1 : a[y] = f;
            break;
          }
          y = y - 1;
        } while (y > -1);
      }
    }
    function ee() {
      let Q = De(F[F.length - 1]) ? [] : F[F.length - 1];
      function U() {
        let y = t, K = !1, k = e.begin[y];
        do {
          if (y = y - 1, e.lexer[y] === "markup") {
            K = !0;
            break;
          }
          e.begin[y] !== k && (y = e.begin[y]);
        } while (y > k);
        if (K === !0) {
          y = t;
          do
            y = y - 1, e.begin[y] !== k ? y = e.begin[y] : i(e.token[y], 44) && (a[y] = f + 1);
          while (y > k);
          a[k] = f + 1, a[t - 1] = f;
        } else
          a[t - 1] = -20;
      }
      if (i(h, 41) && i(e.token[t + 1], 46) && $(e.token[Q[0]], 58) && Q[Q.length - 1] > -1) {
        let y = e.begin[t], K = !1, k = !1;
        do
          y = y - 1;
        while (y > 0 && a[y] < -9);
        K = a[y] === f, y = t + 1;
        do {
          if (y = y + 1, i(e.token[y], 123)) {
            k = !0;
            break;
          }
          if (e.begin[y] === e.begin[t + 1] && (e.types[y] === "separator" || e.types[y] === "end"))
            break;
        } while (y < o);
        K === !1 && k === !0 && F.length > 1 && (F[F.length - 2].push(e.begin[t]), f = f + 1);
      }
      if (w !== "separator" && oe(), i(e.token[t + 1], 58) && (e.stack[t] === "object" || e.stack[t] === "array") && P(!0, !1), i(e.token[e.begin[t] - 1], 44) && (i(e.token[t + 1], 125) || i(e.token[t + 1], 93)) && (e.stack[t] === "object" || e.stack[t] === "array") && P(!0, !1), e.stack[t] !== "attribute" && ($(h, 41) && h !== "x)" && (e.lexer[t - 1] !== "markup" || e.lexer[t - 1] === "markup" && e.token[t - 2] !== "return") && (f = f - 1), i(h, 125) && e.stack[t] === "switch" && n.noCaseIndent === !1 && (f = f - 1)), i(h, 125) || h === "x}") {
        if (e.types[t - 1] !== "comment" && x !== "{" && x !== "x{" && w !== "end" && w !== "string" && w !== "number" && w !== "separator" && x !== "++" && x !== "--" && (t < 2 || e.token[t - 2] !== ";" || e.token[t - 2] !== "x;" || x === "break" || x === "return")) {
          let y = t - 1, K = !1, k = e.begin[t], m = z.length;
          do {
            if (e.begin[y] === k) {
              if ((i(e.token[y], 61) || i(e.token[y], 59) || e.token[y] === "x;") && (K = !0), i(e.token[y], 46) && a[y - 1] > -1) {
                G[G.length - 1] = !1, a[k] = f + 1, a[t - 1] = f;
                break;
              }
              if (y > 0 && e.token[y] === "return" && (e.token[y - 1] === ")" || e.token[y - 1] === "x)" || e.token[y - 1] === "{" || e.token[y - 1] === "x{" || e.token[y - 1] === "}" || e.token[y - 1] === "x}" || e.token[y - 1] === ";" || e.token[y - 1] === "x;")) {
                f = f - 1, a[t - 1] = f;
                break;
              }
              if (i(e.token[y], 58) && C.length === 0 || i(e.token[y], 44) && K === !1)
                break;
              if (y === 0 || e.token[y - 1] === "{" || e.token[y - 1] === "x{" || e.token[y] === "for" || e.token[y] === "if" || e.token[y] === "do" || e.token[y] === "function" || e.token[y] === "while" || e.token[y] === "var" || e.token[y] === "let" || e.token[y] === "const" || e.token[y] === "with") {
                z[m - 1] === !1 && m > 1 && (t === o - 1 || e.token[t + 1] !== ")" && e.token[t + 1] !== "x)") && e.stack[t] !== "object" && (f = f - 1);
                break;
              }
            } else
              y = e.begin[y];
            y = y - 1;
          } while (y > k);
        }
        ae.pop();
      }
      if (n.bracePadding === !1 && h !== "}" && w !== "markup" && w !== "liquid" && (a[t - 1] = -20), n.bracePadding === !0 && w !== "start" && x !== ";" && (a[e.begin[t]] < -9 || G[G.length - 1] === !0))
        a[e.begin[t]] = -10, a[t - 1] = -10, a.push(-20);
      else if (e.stack[t] === "attribute")
        a[t - 1] = -20, a.push(f);
      else if (e.stack[t] === "array" && (Q.length > 0 || B[B.length - 1] === !0))
        ke(), G[G.length - 1] = !1, a[e.begin[t]] = f + 1, a[t - 1] = f, a.push(-20);
      else if (Q.length > 0 && (e.stack[t] === "object" || e.begin[t] === 0 && i(h, 125)))
        ke(), G[G.length - 1] = !1, a[e.begin[t]] = f + 1, a[t - 1] = f, a.push(-20);
      else if (h === ")" || h === "x)") {
        let y = h === ")" && $(x, 40) && A.length > 0 ? A.pop() + 1 : 0, K = e.token[e.begin[t] - 1] === "if" ? (() => {
          let k = t;
          do
            if (k = k - 1, e.token[k] === ")" && a[k - 1] > -1)
              return y;
          while (k > e.begin[t]);
          return y + 5;
        })() : y;
        if (y > 0 && (r.language !== "jsx" || r.language === "jsx" && e.token[e.begin[t] - 1] !== "render")) {
          let k = s.wrap, m = e.begin[t], v = A.length, L = t - 2;
          if (K > k) {
            a[e.begin[t]] = f + 1, a[t - 1] = f;
            do
              e.begin[L] === m ? e.token[L] === "&&" || e.token[L] === "||" ? a[L] = f + 1 : a[L] > -1 && e.types[L] !== "comment" && e.token[L + 1] !== "." && (a[L] = a[L] + 1) : a[L] > -1 && e.token[L + 1] !== "." && (a[L] = a[L] + 1), L = L - 1;
            while (L > m);
          } else
            v > 0 && (A[v - 1] = A[v - 1] + y);
        } else if (h === ")" && t > e.begin[t] + 2 && e.lexer[e.begin[t] + 1] === N && e.token[e.begin[t] + 1] !== "function") {
          let k = e.begin[t] < 0 ? 0 : e.begin[t], m = s.wrap, v = Q.length, L = 0, j = 0, pe = 0, S = 0, E = 0, M = !1, I = !1, H = f + 1, fe = !1, ue = !1, de = !1;
          if (a[k] < -9) {
            j = k;
            do
              j = j + 1;
            while (j < t && a[j] < -9);
            S = j;
            do
              L = L + e.token[j].length, a[j] === -10 && (L = L + 1), e.token[j] === "(" && pe > 0 && pe < m - 1 && S === t && (pe = -1), e.token[j] === ")" ? E = E - 1 : e.token[j] === "(" && (E = E + 1), j === k && E > 0 && (pe = L), j = j - 1;
            while (j > k && a[j] < -9);
            if (e.token[j + 1] === "." && (H = a[j] + 1), L > m - 1 && m > 0 && $(x, 40) && pe !== -1 && G[G.length - 2] === !1 && (e.token[k - 1] === "if" && z[z.length - 1] === !0 || e.token[k - 1] !== "if") && (a[k] = H, e.token[k - 1] === "for")) {
              j = k;
              do
                j = j + 1, i(e.token[j], 59) && e.begin[j] === k && (a[j] = H);
              while (j < t);
            }
          }
          j = t, L = 0;
          do
            j = j - 1, e.stack[j] === "function" ? j = e.begin[j] : e.begin[j] === k ? (i(e.token[j], 63) ? de = !0 : i(e.token[j], 44) && M === !1 ? (M = !0, L >= m && m > 0 && (fe = !0)) : e.types[j] === "markup" && ue === !1 && (ue = !0), a[j] > -9 && $(e.token[j], 44) && e.types[j] !== "markup" ? L = 0 : (a[j] === -10 && (L = L + 1), L = L + e.token[j].length, L >= m && m > 0 && (M === !0 || ue === !0) && (fe = !0))) : a[j] > -9 ? L = 0 : (L = L + e.token[j].length, L >= m && m > 0 && (M === !0 || ue === !0) && (fe = !0));
          while (j > k && fe === !1);
          if (M === !1 && i(e.token[e.begin[t] + 1], 96))
            a[e.begin[t]] = -20, a[t - 1] = -20;
          else if ((M === !0 || ue === !0) && L >= m && m > 0 || a[k] > -9) {
            if (de === !0) {
              if (H = a[k], i(e.token[k - 1], 91)) {
                j = t;
                do
                  if (j = j + 1, e.types[j] === "end" || i(e.token[j], 44) || i(e.token[j], 59))
                    break;
                while (j < o);
                i(e.token[j], 93) && (H = H - 1, I = !0);
              }
            } else
              v > 0 && Q[v - 1] > j && (H = H - v);
            G[G.length - 1] = !1, j = t;
            do
              if (j = j - 1, e.begin[j] === k)
                if (e.token[j].indexOf("=") > -1 && e.types[j] === "operator" && e.token[j].indexOf("!") < 0 && e.token[j].indexOf("==") < 0 && e.token[j] !== "<=" && e.token[j].indexOf(">") < 0) {
                  L = j;
                  do
                    if (L = L - 1, e.begin[L] === k && (e.token[L] === ";" || e.token[L] === "," || L === k))
                      break;
                  while (L > k);
                } else
                  i(e.token[j], 44) ? a[j] = H : a[j] > -9 && I === !1 && (e.token[k - 1] !== "for" || e.token[j + 1] === "?" || e.token[j + 1] === ":") && (e.token[e.begin[t]] !== "(" || e.token[j] !== "+") && (a[j] = a[j] + 1);
              else
                a[j] > -9 && I === !1 && (a[j] = a[j] + 1);
            while (j > k);
            a[k] = H, a[t - 1] = H - 1;
          } else
            a[t - 1] = -20;
          e.token[e.begin[t] - 1] === "+" && a[e.begin[t]] > -9 && (a[e.begin[t] - 1] = -10);
        } else
          r.language === "jsx" || r.language === "tsx" ? U() : a[t - 1] = -20;
        a.push(-20);
      } else if (G[G.length - 1] === !0)
        i(h, 93) && e.begin[t] - 1 > 0 && e.token[e.begin[e.begin[t] - 1]] === "[" && (G[G.length - 2] = !1), e.begin[t] < a.length && (a[e.begin[t]] = -20), r.language === "jsx" || r.language === "tsx" ? U() : i(h, 93) && a[e.begin[t]] > -1 ? a[t - 1] = a[e.begin[t]] - 1 : a[t - 1] = -20, a.push(-20);
      else if (e.types[t - 1] === "comment" && e.token[t - 1].substring(0, 2) === "//")
        e.token[t - 2] === "x}" && (a[t - 3] = f + 1), a[t - 1] = f, a.push(-20);
      else if (w.indexOf("liquid") < 0 && // PATCH SO LIQUID TOKENS DONT END WITH: }}} (3 LCB)
      e.types[t - 1] !== "comment" && (i(x, 123) && i(h, 125) || i(x, 91) && i(h, 93)))
        a[t - 1] = -20, a.push(-20);
      else if (i(h, 93)) {
        if (z[z.length - 1] === !0 && G[G.length - 1] === !1 && n.arrayFormat !== "inline" || i(x, 93) && a[t - 2] === f + 1 ? (a[t - 1] = f, a[e.begin[t]] = f + 1) : a[t - 1] === -10 && (a[t - 1] = -20), e.token[e.begin[t] + 1] === "function")
          a[t - 1] = f;
        else if (z[z.length - 1] === !1) {
          (i(x, 125) || x === "x}") && (a[t - 1] = f);
          let y = t - 1, K = 1;
          do {
            if (i(e.token[y], 93) && (K = K + 1), i(e.token[y], 91) && (K = K - 1, K === 0)) {
              if (y > 0 && (i(e.token[y + 1], 123) || i(e.token[y + 1], 91) || e.token[y + 1] === "x{")) {
                a[y] = f + 1;
                break;
              }
              if ($(e.token[y + 1], 91) || R === !1) {
                a[y] = -20;
                break;
              }
              break;
            }
            K === 1 && e.token[y] === "+" && a[y] > 1 && (a[y] = a[y] - 1), y = y - 1;
          } while (y > -1);
        } else
          (r.language === "jsx" || r.language === "tsx") && U();
        if (n.arrayFormat === "inline") {
          let y = t, K = e.begin[t];
          do
            if (y = y - 1, e.types[y] === "end")
              break;
          while (y > K);
          y > K ? (a[e.begin[t]] = f + 1, a[t - 1] = f) : (a[e.begin[t]] = -20, a[t - 1] = -20);
        } else
          a[e.begin[t]] > -1 && (a[t - 1] = a[e.begin[t]] - 1);
        a.push(-20);
      } else
        i(h, 125) || h === "x}" || z[z.length - 1] === !0 ? (i(h, 125) && x === "x}" && e.token[t + 1] === "else" ? (a[t - 2] = f + 2, a.push(-20)) : a.push(f), a[t - 1] = f) : a.push(-20);
      e.types[t - 1] === "comment" && (a[t - 1] = f), ke(), R = z[z.length - 1], z.pop(), F.pop(), B.pop(), ie.pop(), g.pop(), G.pop(), q.pop();
    }
    function ke() {
      let Q = 0, U = F[F.length - 1];
      if (U !== void 0) {
        if (Q = U.length - 1, Q < 1 && U[Q] < 0 && (i(h, 59) || h === "x;" || i(h, 41) || h === "x)" || i(h, 125) || h === "x}")) {
          U.pop();
          return;
        }
        if (!(Q < 0 || U[Q] < 0)) {
          if (i(h, 58)) {
            if ($(e.token[U[Q]], 63))
              do
                U.pop(), Q = Q - 1, f = f - 1;
              while (Q > -1 && U[Q] > -1 && $(e.token[U[Q]], 63));
            U[Q] = t, a[t - 1] = f;
          } else
            do
              U.pop(), Q = Q - 1, f = f - 1;
            while (Q > -1 && U[Q] > -1);
          (e.stack[t] === "array" || i(h, 44)) && U.length < 1 && U.push(-1);
        }
      }
    }
    function we() {
      let Q = t;
      do {
        if (e.lexer[t + 1] === N && e.begin[t + 1] < Q || e.token[Q - 1] === "return" && e.types[t] === "end" && e.begin[t] === Q)
          break;
        a.push(0), t = t + 1;
      } while (t < o);
      l[Q] = t, a.push(f - 1);
    }
    function oe() {
      let Q = t - 1, U = e.begin[t];
      if (!(f < 1))
        do {
          if (U !== e.begin[Q])
            Q = e.begin[Q];
          else if (e.types[Q] === "separator" || e.types[Q] === "operator") {
            e.token[Q] === "." && a[Q - 1] > 0 && (e.token[U - 1] === "if" ? f = f - 2 : f = f - 1);
            break;
          }
          Q = Q - 1;
        } while (Q > 0 && Q > U);
    }
    function T() {
      (e.token[t + 1] !== "," && h.indexOf("/>") !== h.length - 2 || e.token[t + 1] === "," && e.token[e.begin[t] - 3] !== "React") && P(!1, !1), x === "return" || x === "?" || x === ":" ? (a[t - 1] = -10, a.push(-20)) : w === "start" || e.token[t - 2] === "return" && e.stack[t - 1] === "method" ? a.push(f) : a.push(-20);
    }
    function J() {
      let Q = De(F[F.length - 1]) ? [] : F[F.length - 1];
      function U() {
        let y = e.token[t + 1], K = 0, k = 0, m = t, v = h === "+" ? f + 2 : f, L = 0;
        if (s.wrap < 1) {
          a.push(-10);
          return;
        }
        do {
          if (m = m - 1, i(e.token[e.begin[t]], 40) && (m === e.begin[t] && (L = K), i(e.token[m], 44) && e.begin[m] === e.begin[t] && z[z.length - 1] === !0) || K > s.wrap - 1 || a[m] > -9 || e.types[m] === "operator" && e.token[m] !== "=" && e.token[m] !== "+" && e.begin[m] === e.begin[t] || (K = K + e.token[m].length, m === e.begin[t] && e.token[m] === "[" && K < s.wrap - 1) || e.token[m] === "." && a[m] > -9)
            break;
          a[m] === -10 && (K = K + 1);
        } while (m > 0);
        if (L > 0 && (L = L + y.length), K = K + y.length, k = m, K > s.wrap - 1 && a[m] < -9)
          do
            k = k - 1;
          while (k > 0 && a[k] < -9);
        if (e.token[k + 1] === "." && e.begin[t] <= e.begin[k] ? v = v + 1 : e.types[k] === "operator" && (v = a[k]), k = y.length, K + k < s.wrap) {
          a.push(-10);
          return;
        }
        if (i(e.token[e.begin[t]], 40) && (e.token[Q[0]] === ":" || e.token[Q[0]] === "?") ? v = f + 3 : e.stack[t] === "method" ? (a[e.begin[t]] = f, z[z.length - 1] === !0 ? v = f + 3 : v = f + 1) : (e.stack[t] === "object" || e.stack[t] === "array") && P(!0, !1), (e.token[m] === "var" || e.token[m] === "let" || e.token[m] === "const") && (K = K - s.indentSize * s.indentChar.length * 2), L > 0 ? m = s.wrap - L : m = s.wrap - K, m > 0 && m < 5) {
          a.push(v), (e.token[t].charAt(0) === '"' || e.token[t].charAt(0) === "'") && (t = t + 1, a.push(-10));
          return;
        }
        if (e.token[e.begin[t]] !== "(" || L > s.wrap - 1 || L === 0) {
          if (L > 0 && (K = L), K - y.length < s.wrap - 1 && (y.charAt(0) === '"' || y.charAt(0) === "'")) {
            if (t = t + 1, K = K + 3, K - y.length > s.wrap - 4) {
              a.push(v);
              return;
            }
            a.push(-10);
            return;
          }
          a.push(v);
          return;
        }
        a.push(-10);
      }
      if (oe(), Q.length > 0 && Q[Q.length - 1] > -1 && e.stack[t] === "array" && (B[B.length - 1] = !0), h !== ":" && (e.token[e.begin[t]] !== "(" && e.token[e.begin[t]] !== "x(" && G.length > 0 && P(!0, !1), h !== "?" && e.token[Q[Q.length - 1]] === ".")) {
        let y = 0, K = t, k = e.begin[K];
        do {
          if (e.begin[K] === k) {
            if (e.token[K + 1] === "{" || e.token[K + 1] === "[" || e.token[K] === "function")
              break;
            if (i(e.token[K], 44) || i(e.token[K], 59) || e.types[K] === "end" || i(e.token[K], 58)) {
              Q.pop(), f = f - 1;
              break;
            }
            if (e.token[K] === "?" || i(e.token[K], 58)) {
              e.token[Q[Q.length - 1]] === "." && y < 2 && (Q[Q.length - 1] = k + 1);
              break;
            }
            e.token[K] === "." && (y = y + 1);
          }
          K = K + 1;
        } while (K < o);
      }
      if (h === "!" || h === "...") {
        (i(x, 125) || x === "x}") && (a[t - 1] = f), a.push(-20);
        return;
      }
      if (x === ";" || x === "x;") {
        e.token[e.begin[t] - 1] !== "for" && (a[t - 1] = f), a.push(-20);
        return;
      }
      if (h === "*") {
        x === "function" || x === "yield" ? a[t - 1] = -20 : a[t - 1] = -10, a.push(-10);
        return;
      }
      if (h === "?") {
        if (e.lines[t] === 0 && e.types[t - 2] === "word" && e.token[t - 2] !== "return" && e.token[t - 2] !== "in" && e.token[t - 2] !== "instanceof" && e.token[t - 2] !== "typeof" && (w === "reference" || w === "word") && (e.types[t + 1] === "word" || e.types[t + 1] === "reference" || (i(e.token[t + 1], 40) || e.token[t + 1] === "x(") && e.token[t - 2] === "new")) {
          if (a[t - 1] = -20, e.types[t + 1] === "word" || e.types[t + 1] === "reference") {
            a.push(-10);
            return;
          }
          a.push(-20);
          return;
        }
        if (e.token[t + 1] === ":") {
          a[t - 1] = -20, a.push(-20);
          return;
        }
        if (C.push(t), n.ternaryLine === !0)
          a[t - 1] = -10;
        else {
          let y = t - 1;
          do
            y = y - 1;
          while (y > -1 && a[y] < -9);
          if (Q.push(t), f = f + 1, a[y] === f && e.token[y + 1] !== ":" && (f = f + 1, Q.push(t)), a[t - 1] = f, i(e.token[e.begin[t]], 40) && (Q.length < 2 || Q[0] === Q[1])) {
            G[G.length - 1] = !1, t - 2 === e.begin[t] ? a[e.begin[t]] = f - 1 : a[e.begin[t]] = f, y = t - 2;
            do {
              if (e.types[y] === "end" && a[y - 1] > -1)
                break;
              a[y] > -1 && (a[y] = a[y] + 1), y = y - 1;
            } while (y > e.begin[t]);
          }
        }
        a.push(-10);
        return;
      }
      if (h === ":") {
        if (e.stack[t] === "map" || e.types[t + 1] === "type" || e.types[t + 1] === "type_start") {
          a[t - 1] = -20, a.push(-10);
          return;
        }
        if (C.length > 0 && e.begin[C[C.length - 1]] === e.begin[t]) {
          let y = t, K = e.begin[t];
          do
            if (y = y - 1, e.begin[y] === K) {
              if (i(e.token[y], 44) || i(e.token[y], 59)) {
                a[t - 1] = -20;
                break;
              }
              if (e.token[y] === "?") {
                C.pop(), ke(), n.ternaryLine === !0 && (a[t - 1] = -10), a.push(-10);
                return;
              }
            } else
              e.types[y] === "end" && (y = e.begin[y]);
          while (y > K);
        }
        if (e.token[t - 2] === "where" && e.stack[t - 2] === e.stack[t]) {
          a[t - 1] = -10, a.push(-10);
          return;
        }
        if (w === "reference" && e.token[e.begin[t]] !== "(" && e.token[e.begin[t]] !== "x(") {
          a[t - 1] = -20, a.push(-10);
          return;
        }
        if ((i(x, 41) || x === "x)") && e.token[e.begin[t - 1] - 2] === "function") {
          a[t - 1] = -20, a.push(-10);
          return;
        }
        if (e.stack[t] === "attribute") {
          a[t - 1] = -20, a.push(-10);
          return;
        }
        if (e.token[e.begin[t]] !== "(" && e.token[e.begin[t]] !== "x(" && (w === "reference" || i(x, 41) || i(x, 93) || x === "?") && (e.stack[t] === "map" || e.stack[t] === "class" || e.types[t + 1] === "reference") && (C.length === 0 || C[C.length - 1] < e.begin[t]) && ("mapclassexpressionmethodglobalparen".indexOf(e.stack[t]) > -1 || e.types[t - 2] === "word" && e.stack[t] !== "switch")) {
          a[t - 1] = -20, a.push(-10);
          return;
        }
        if (e.stack[t] === "switch" && (C.length < 1 || C[C.length - 1] < e.begin[t])) {
          a[t - 1] = -20, n.caseSpace === !0 ? a.push(-10) : a.push(f);
          return;
        }
        e.stack[t] === "object" ? a[t - 1] = -20 : C.length > 0 ? a[t - 1] = f : a[t - 1] = -10, a.push(-10);
        return;
      }
      if (h === "++" || h === "--") {
        w === "number" || w === "reference" ? (a[t - 1] = -20, a.push(-10)) : t < o - 1 && (e.types[t + 1] === "number" || e.types[t + 1] === "reference") ? a.push(-20) : a.push(-10);
        return;
      }
      if (h === "+") {
        if (w === "start" ? a[t - 1] = -20 : a[t - 1] = -10, s.wrap < 1 || e.token[e.begin[t]] === "x(") {
          a.push(-10);
          return;
        }
        let y = e.token[t + 1];
        if (y === void 0) {
          a.push(-10);
          return;
        }
        if (e.types[t - 1] === "operator" || e.types[t - 1] === "start") {
          if (e.types[t + 1] === "reference" || y === "(" || y === "[") {
            a.push(-20);
            return;
          }
          if (Number(y.slice(1, -1)) > -1 && (/\d/.test(y.charAt(1)) === !0 || y.charAt(1) === "." || y.charAt(1) === "-" || y.charAt(1) === "+")) {
            a.push(-20);
            return;
          }
        }
        return U();
      }
      if (e.types[t - 1] !== "comment" && (i(x, 40) ? a[t - 1] = -20 : h === "*" && e.stack[t] === "object" && e.types[t + 1] === "reference" && (i(x, 123) || i(x, 44)) ? a[t - 1] = f : (h !== "?" || C.length === 0) && (a[t - 1] = -10)), h.indexOf("=") > -1 && h !== "==" && h !== "===" && h !== "!=" && h !== "!==" && h !== ">=" && h !== "<=" && h !== "=>" && e.stack[t] !== "method" && e.stack[t] !== "object") {
        let y = t + 1, K = 0, k = !1, m = p;
        if ((i(e.token[e.begin[t]], 40) || e.token[e.begin[t]] === "x(") && e.token[t + 1] !== "function")
          return;
        do {
          if (e.types[y] === "start") {
            if (k === !0 && e.token[y] !== "[") {
              q[q.length - 1] === !0 && (q[q.length - 1] = !1);
              break;
            }
            K = K + 1;
          }
          if (e.types[y] === "end" && (K = K - 1), K < 0) {
            q[q.length - 1] === !0 && (q[q.length - 1] = !1);
            break;
          }
          if (K === 0) {
            if (m = e.token[y], k === !0) {
              if (e.types[y] === "operator" || i(e.token[y], 59) || e.token[y] === "x;" || e.token[y] === "?" || e.token[y] === "var" || e.token[y] === "let" || e.token[y] === "const") {
                m !== void 0 && (m === "?" || m.indexOf("=") > -1 && m !== "==" && m !== "===" && m !== "!=" && m !== "!==" && m !== ">=" && m !== "<=") && q[q.length - 1] === !1 && (q[q.length - 1] = !0), (m === ";" || m === "x;" || m === "var" || m === "let" || m === "const") && q[q.length - 1] === !0 && (q[q.length - 1] = !1);
                break;
              }
              q[q.length - 1] === !0 && (m === "return" || m === "break" || m === "continue" || m === "throw") && (q[q.length - 1] = !1);
            }
            (m === ";" || m === "x;" || m === ",") && (k = !0);
          }
          y = y + 1;
        } while (y < o);
        a.push(-10);
        return;
      }
      if (h === "-" && x === "return" || i(x, 61)) {
        a.push(-20);
        return;
      }
      if (w === "operator" && e.types[t + 1] === "reference" && x !== "--" && x !== "++" && h !== "&&" && h !== "||") {
        a.push(-20);
        return;
      }
      return U();
    }
    function X() {
      let Q = () => {
        let U = e.begin[t];
        if (U < 0)
          r.stack.push([e.token[t], -1]);
        else {
          if (e.stack[U + 1] !== "function")
            do
              U = e.begin[U];
            while (U > -1 && e.stack[U + 1] !== "function");
          r.stack.push([e.token[t], U]);
        }
      };
      if (e.types[t - 1] === "comment" ? a[t - 1] = f : w === "end" && x !== ")" && e.token[e.begin[t - 1] - 1] !== ")" ? a[t - 1] = -10 : w !== "separator" && w !== "start" && w !== "end" && w.indexOf("template_string") < 0 && (w === "word" || w === "operator" || w === "property" || w === "type" || w === "reference" ? a[t - 1] = -10 : a[t - 1] = -20), x === "var" && e.lexer[t - 1] === N)
        Q();
      else if (x === "function")
        r.stack.push([e.token[t], t]);
      else if (x === "let" || x === "const")
        r.stack.push([e.token[t], t]);
      else if (e.stack[t] === "arguments")
        r.stack.push([e.token[t], t]);
      else if (i(x, 44)) {
        let U = t;
        do
          U = U - 1;
        while (U > e.begin[t] && e.token[U] !== "var" && e.token[U] !== "let" && e.token[U] !== "const");
        e.token[U] === "var" ? Q() : (e.token[U] === "let" || e.token[U] === "const") && r.stack.push([e.token[t], t]);
      }
      a.push(-10);
    }
    function V() {
      let Q = De(F[F.length - 1]) ? [] : F[F.length - 1], U = () => {
        if (n.methodChain > 0) {
          let y = t, K = e.begin[t], k = [t], m = e.token[K - 1] === "if";
          do
            if (y = y - 1, e.types[y] === "end" && (y = e.begin[y]), e.begin[y] === K) {
              if (e.types[y] === "string" && e.token[y].indexOf("${") === e.token[y].length - 2)
                break;
              if (e.token[y] === ".") {
                if (a[y - 1] > 0) {
                  a[t - 1] = m === !0 ? f + 1 : f;
                  return;
                }
                k.push(y);
              } else if (e.token[y] === ";" || e.token[y] === "," || e.types[y] === "operator" || (e.types[y] === "word" || e.types[y] === "reference") && (e.types[y - 1] === "word" || e.types[y - 1] === "reference"))
                break;
            }
          while (y > K);
          if (k.length < n.methodChain) {
            a[t - 1] = -20;
            return;
          }
          y = 0, K = k.length;
          do
            a[k[y] - 1] = m === !0 ? f + 1 : f, y = y + 1;
          while (y < K);
          y = k[k.length - 1] - 1;
          do
            a[y] > -1 && (a[y] = a[y] + 1), y = y + 1;
          while (y < t);
          f = m === !0 ? f + 2 : f + 1;
        }
        a[t - 1] = f;
      };
      if (h === "::") {
        a[t - 1] = -20, a.push(-20);
        return;
      }
      if (h === ".") {
        e.token[e.begin[t]] !== "(" && e.token[e.begin[t]] !== "x(" && Q.length > 0 && (e.stack[t] === "object" || e.stack[t] === "array" ? P(!0, !1) : P(!1, !1)), n.methodChain === 0 ? a[t - 1] = -20 : n.methodChain < 0 ? e.lines[t] > 0 ? U() : a[t - 1] = -20 : U(), a.push(-20);
        return;
      }
      if (h === ",") {
        if (oe(), z[z.length - 1] === !1 && (e.stack[t] === "object" || e.stack[t] === "array" || e.stack[t] === "paren" || e.stack[t] === "expression" || e.stack[t] === "method") && (z[z.length - 1] = !0, i(e.token[e.begin[t]], 40))) {
          let y = t;
          do
            y = y - 1, e.begin[y] === e.begin[t] && e.token[y] === "+" && a[y] > -9 && (a[y] = a[y] + 2);
          while (y > e.begin[t]);
        }
        if (e.stack[t] === "array" && n.arrayFormat === "indent") {
          a[t - 1] = -20, a.push(f);
          return;
        }
        if (e.stack[t] === "array" && n.arrayFormat === "inline") {
          a[t - 1] = -20, a.push(-10);
          return;
        }
        if (e.stack[t] === "object" && n.objectIndent === "indent") {
          a[t - 1] = -20, a.push(f);
          return;
        }
        if (e.stack[t] === "object" && n.objectIndent === "inline") {
          a[t - 1] = -20, a.push(-10);
          return;
        }
        if (Q.length > 0) {
          Q[Q.length - 1] > -1 && ke(), a[t - 1] = -20, a.push(f);
          return;
        }
        if (e.token[t - 2] === ":" && e.token[t - 4] === "where") {
          a[t - 1] = -20, a.push(-10);
          return;
        }
        if (a[t - 1] = -20, e.types[t + 1] !== "end" && (ie[ie.length - 1] = ie[ie.length - 1] + 1), (i(e.token[e.begin[t]], 40) || e.token[e.begin[t]] === "x(") && r.language !== "jsx" && e.stack[t] !== "global" && (e.types[t - 1] !== "string" && e.types[t - 1] !== "number" || e.token[t - 2] !== "+" || e.types[t - 1] === "string" && e.types[t - 1] !== "number" && i(e.token[t - 2], 43) && e.types[t - 3] !== "string" && e.types[t - 3] !== "number")) {
          a.push(-10);
          return;
        }
        if (w === "reference" && e.types[t - 2] === "word" && "var-let-const-from".indexOf(e.token[t - 2]) < 0 && (e.types[t - 3] === "end" || e.token[t - 3] === ";")) {
          g[g.length - 1] = !0, a.push(-10);
          return;
        }
        if (g[g.length - 1] === !0 || e.stack[t] === "notation") {
          a.push(-10);
          return;
        }
        if (ie[ie.length - 1] > 3 && (e.stack[t] === "array" || e.stack[t] === "object")) {
          if (G[G.length - 1] === !0 && P(!0, !0), a[t - 1] = -20, B[B.length - 1] === !0) {
            a.push(f);
            return;
          }
          let y = e.begin[t], K = t;
          do
            e.types[K] === "end" ? K = e.begin[K] : i(e.token[K], 44) && e.types[K + 1] !== "comment" && (a[K] = f), K = K - 1;
          while (K > y);
          a[y] = f, B[B.length - 1] = !0;
          return;
        }
        if (e.stack[t] === "object" && G[G.length - 1] === !0 && e.types[e.begin[t] - 1] !== "word" && e.types[e.begin[t] - 1] !== "reference" && e.token[e.begin[t] - 1] !== "(" && e.token[e.begin[t] - 1] !== "x(") {
          let y = e.begin[t], K = t - 1;
          do {
            if (e.begin[K] === y) {
              if (i(e.token[K], 44))
                break;
              if (i(e.token[K], 58)) {
                P(!0, !1);
                break;
              }
            }
            K = K - 1;
          } while (K > y);
        }
        if (G[G.length - 1] === !1 || i(e.token[t - 2], 43) && (w === "string" || w === "number") && a[t - 2] > 0 && (i(x, 34) || i(x, 39))) {
          if (e.stack[t] === "method") {
            if (i(e.token[t - 2], 43) && (i(x, 34) || i(x, 39)) && (e.token[t - 3].charAt(0) === '"' || e.token[t - 3].charAt(0) === "'")) {
              a.push(f + 2);
              return;
            }
            if (e.token[t - 2] !== "+") {
              a.push(-10);
              return;
            }
          }
          a.push(f);
          return;
        }
        if (G[G.length - 1] === !0 && e.stack[t] !== "object") {
          a.push(-10);
          return;
        }
        if (ie[ie.length - 1] < 4 && (e.stack[t] === "array" || e.stack[t] === "object")) {
          a.push(-10);
          return;
        }
        a.push(f);
        return;
      }
      if (i(h, 59) || h === "x;") {
        if (oe(), e.token[t + 1] !== void 0 && e.types[t + 1].indexOf("attribute") > 0 && e.types[t + 1].indexOf("end") > 0) {
          a[t - 1] = -20, a.push(f - 1);
          return;
        }
        if (ae[ae.length - 1] > -1 && e.stack[ae[ae.length - 1]] !== "expression") {
          let y = t;
          do {
            if (y = y - 1, i(e.token[y], 59))
              break;
            if (i(e.token[y], 44)) {
              f = f - 1;
              break;
            }
            e.types[y] === "end" && (y = e.begin[y]);
          } while (y > 0 && y > e.begin[t]);
        }
        if (ae[ae.length - 1] = -1, ke(), e.token[e.begin[t] - 1] !== "for" && P(!1, !1), g[g.length - 1] = !1, a[t - 1] = -20, e.begin[t] > 0 && e.token[e.begin[t] - 1] === "for" && e.stack[t] !== "for") {
          a.push(-10);
          return;
        }
        a.push(f);
        return;
      }
      a.push(-20);
    }
    function se() {
      let Q = e.stack[t + 1], U = t === 0 ? e.stack[t] : e.stack[t - 1];
      if ((i(x, 41) || $(x, 93) && (U === "object" || U === "array")) && (Q !== "method" || Q === "method" && $(e.token[t + 1], 41) && $(e.token[t + 2], 41)) && (i(x, 41) && (Q !== "function" || i(e.token[e.begin[e.begin[t - 1] - 1]], 40) || e.token[e.begin[e.begin[t - 1] - 1]] === "x(") ? P(!1, !1) : e.types[t + 1] !== "end" && e.types[t + 2] !== "end" && P(!0, !1)), z.push(!1), F.push([]), q.push(!1), B.push(!1), g.push(!1), ie.push(0), n.neverFlatten === !0 || Q === "attribute" || w === "generic" || n.arrayFormat === "indent" && Q === "array" || Q === "class" && $(x, 40) && x !== "x(" || i(h, 91) && e.token[t + 1] === "function" ? G.push(!1) : Q === "expression" || Q === "method" || (Q === "object" || Q === "class") && (i(x, 40) || x === "x(" || w === "word" || w === "reference") || Q === "array" || i(h, 40) || h === "x(" || i(h, 123) && Q === "object" && w !== "operator" && w !== "start" && w !== "string" && w !== "number" && U !== "object" && U !== "array" && t > 0 ? G.push(!0) : G.push(!1), $(h, 40) && h !== "x(" && e.stack[t + 1] !== "attribute" && (f = f + 1), i(h, 123) || h === "x{") {
        if (ae.push(-1), e.types[t - 1] !== "comment" && (w === "markup" ? a[t - 1] = f : n.braceAllman === !0 && w !== "operator" && x !== "return" ? a[t - 1] = f - 1 : e.stack[t + 1] !== "block" && (Q === "function" || i(x, 41) || x === "x)" || i(x, 44) || i(x, 125) || w === "markup") ? a[t - 1] = -10 : (i(x, 123) || x === "x{" || i(x, 91) || i(x, 125) || x === "x}") && (a[t - 1] = f - 1)), Q === "object") {
          if (n.objectIndent === "indent") {
            G[G.length - 1] = !1, a.push(f);
            return;
          }
          if (n.objectIndent === "inline") {
            G[G.length - 1] = !0, a.push(-20);
            return;
          }
        }
        if (Q === "switch") {
          if (n.noCaseIndent === !0) {
            a.push(f - 1);
            return;
          }
          f = f + 1, a.push(f);
          return;
        }
        if (G[G.length - 1] === !0 && w !== "word" && w !== "reference") {
          a.push(-20);
          return;
        }
        a.push(f);
        return;
      }
      if (i(h, 40) || h === "x(") {
        if (s.wrap > 0 && i(h, 40) && e.token[t + 1] !== ")" && A.push(1), i(x, 45) && (i(e.token[t - 2], 40) || e.token[t - 2] === "x(") && (a[t - 2] = -20), w === "end" && U !== "if" && U !== "for" && U !== "catch" && U !== "else" && U !== "do" && U !== "try" && U !== "finally" && U !== "catch" && (e.types[t - 1] === "comment" ? a[t - 1] = f : a[t - 1] = -20), x === "async" ? a[t - 1] = -10 : (Q === "method" || e.token[t - 2] === "function" && w === "reference") && (x === "import" || x === "in" || n.functionNameSpace === !0 ? a[t - 1] = -10 : i(x, 125) && e.stack[t - 1] === "function" || w === "word" || w === "reference" || w === "property" ? a[t - 1] = -20 : U !== "method" && Q !== "method" && (a[t - 1] = f)), i(x, 43) && (i(e.token[t - 2], 34) || i(e.token[t - 2], 39))) {
          a.push(f);
          return;
        }
        if (i(x, 125) || x === "x}") {
          a.push(-20);
          return;
        }
        (i(x, 45) && (t < 2 || $(e.token[t - 2], 41) && $(e.token[t - 2], 93) && e.token[t - 2] !== "x)" && e.types[t - 2] !== "reference" && e.types[t - 2] !== "string" && e.types[t - 2] !== "number") || n.functionSpace === !1 && x === "function") && (a[t - 1] = -20), a.push(-20);
        return;
      }
      if (i(h, 91)) {
        if (i(x, 91) && (z[z.length - 2] = !0), x === "return" || x === "var" || x === "let" || x === "const" ? a[t - 1] = -10 : e.types[t - 1] !== "comment" && e.stack[t - 1] !== "attribute" && (w === "end" || w === "word" || w === "reference") ? a[t - 1] = -20 : (i(x, 91) || i(x, 123) || x === "x{") && (a[t - 1] = f - 1), e.stack[t] === "attribute") {
          a.push(-20);
          return;
        }
        if (n.arrayFormat === "indent") {
          G[G.length - 1] = !1, a.push(f);
          return;
        }
        if (n.arrayFormat === "inline") {
          G[G.length - 1] = !0, a.push(-20);
          return;
        }
        if (Q === "method" || G[G.length - 1] === !0) {
          a.push(-20);
          return;
        }
        let y = t + 1;
        do {
          if (i(e.token[y], 93)) {
            a.push(-20);
            return;
          }
          if (i(e.token[y], 44)) {
            a.push(f);
            return;
          }
          y = y + 1;
        } while (y < o);
        a.push(-20);
      }
    }
    function D() {
      h.length === 1 ? (a.push(-20), e.lines[t] === 0 && (a[t - 1] = -20)) : h.indexOf("#!/") === 0 ? a.push(f) : w !== "liquid" && e.types[t + 1] !== "liquid" && a.push(-10), (i(x, 44) || w === "start") && (e.stack[t] === "object" || e.stack[t] === "array") && G[G.length - 1] === !1 && t > 0 && (a[t - 1] = f);
    }
    function re() {
      u === "liquid_else" ? w === "string" ? (e.lines[t - 1] <= 1 && (a[t - 1] = -20), e.lines[t] > 0 ? (f = f - 1, a.push(f)) : a.push(-20)) : (a[t - 1] = f - 1, a.push(f)) : u === "liquid_start" ? w === "string" ? (e.lines[t - 1] <= 1 && (a[t - 1] = -20), e.lines[t] > 0 ? (f = f + 1, a.push(f)) : a.push(-20)) : (f = f + 1, e.lines[t - 1] < 1 && (a[t - 1] = -20), e.lines[t] > 0 ? a.push(f) : a.push(-20)) : u === "liquid_end" ? w === "string" ? (e.lines[t - 1] <= 1 && (a[t - 1] = -20), e.lines[t] > 1 && (a[t - 1] = f - 1, a.push(f))) : (f = f - 1, w === "liquid_start" || e.lines[t - 1] < 1 ? a[t - 1] = -20 : a[t - 1] = f, e.lines[t] > 0 ? a.push(f) : a.push(-20)) : u === "liquid" && (i(x, 58) && a[t - 2] === -10 && (a[t - 2] = -20), e.lines[t] > 0 ? a.push(f) : a.push(-20));
    }
    function ge() {
      u === "template_string_start" ? (f = f + 1, a.push(f)) : u === "template_string_else" ? (oe(), a[t - 1] = f - 1, a.push(f)) : (oe(), f = f - 1, a[t - 1] = f, a.push(-10)), t > 2 && (e.types[t - 2] === "template_string_else" || e.types[t - 2] === "template_string_start") && (n.bracePadding === !0 ? (a[t - 2] = -10, a[t - 1] = -10) : (a[t - 2] = -20, a[t - 1] = -20));
    }
    function Be() {
      i(e.token[t - 1], 44) || i(e.token[t - 1], 58) && e.stack[t - 1] !== "data_type" ? a[t - 1] = -10 : a[t - 1] = -20, (e.types[t] === "type" || e.types[t] === "type_end") && a.push(-10), e.types[t] === "type_start" && a.push(-20);
    }
    function Se() {
      if ((i(x, 41) || x === "x)") && e.stack[t] === "class" && (e.token[e.begin[t - 1] - 1] === "static" || e.token[e.begin[t - 1] - 1] === "final" || e.token[e.begin[t - 1] - 1] === "void") && (a[t - 1] = -10, a[e.begin[t - 1] - 1] = -10), i(x, 93) && (a[t - 1] = -10), h === "else" && i(x, 125) && (e.token[t - 2] === "x}" && (a[t - 3] = a[t - 3] - 1), (n.braceAllman === !0 || n.elseNewline === !0) && (a[t - 1] = f)), h === "new" && ye.js.keywords.has(e.token[t + 1]) && (O = O + 1), h === "from" && w === "end" && t > 0 && (e.token[e.begin[t - 1] - 1] === "import" || i(e.token[e.begin[t - 1] - 1], 44)) && (a[t - 1] = -10), h === "function") {
        if (n.functionSpace === !1 && t < o - 1 && (i(e.token[t + 1], 40) || e.token[t + 1] === "x(")) {
          a.push(-20);
          return;
        }
        a.push(-10);
        return;
      }
      if (i(x, 45) && t > 1)
        e.types[t - 2] === "operator" || i(e.token[t - 2], 44) ? a[t - 1] = -20 : e.types[t - 2] === "start" && (a[t - 2] = -20, a[t - 1] = -20);
      else if (h === "while" && (i(x, 125) || x === "x}")) {
        let Q = t - 1, U = 0;
        do {
          if ((i(e.token[Q], 125) || e.token[Q] === "x}") && (U = U + 1), (i(e.token[Q], 123) || e.token[Q] === "x{") && (U = U - 1), U === 0) {
            if (e.token[Q - 1] === "do") {
              a[t - 1] = -10;
              break;
            }
            a[t - 1] = f;
            break;
          }
          Q = Q - 1;
        } while (Q > -1);
      } else if (h === "in" || (i(x, 125) || x === "x}") && (h === "catch" || h === "else" && n.elseNewline === !1 && n.braceAllman === !1))
        a[t - 1] = -10;
      else if (h === "var" || h === "let" || h === "const") {
        if (ae[ae.length - 1] = t, w === "end" && (a[t - 1] = f), e.token[e.begin[t] - 1] !== "for") {
          let Q = t + 1, U = 0;
          do {
            if (e.types[Q] === "end" && (U = U - 1), e.types[Q] === "start" && (U = U + 1), U < 0 || U === 0 && (i(e.token[Q], 59) || i(e.token[Q], 44)))
              break;
            Q = Q + 1;
          } while (Q < o);
          i(e.token[Q], 44) && (f = f + 1);
        }
        a.push(-10);
        return;
      }
      if (w !== "word" && e.stack[t] === "switch" && (h === "default" || h === "case")) {
        a[t - 1] = f - 1, a.push(-10);
        return;
      }
      if (h === "catch" && x === ".") {
        a[t - 1] = -20, a.push(-20);
        return;
      }
      if (h === "catch" || h === "finally") {
        a[t - 1] = -10, a.push(-10);
        return;
      }
      if (n.bracePadding === !1 && t < o - 1 && i(e.token[t + 1], 125)) {
        a.push(-20);
        return;
      }
      if (e.stack[t] === "object" && (i(x, 123) || i(x, 44)) && (i(e.token[t + 1], 40) || e.token[t + 1] === "x(")) {
        a.push(-20);
        return;
      }
      e.types[t - 1] === "comment" && i(e.token[e.begin[t]], 40) && (a[t - 1] = f + 1), s.script.inlineReturn === !0 && h === "return" && w === "start" && e.stack[t] === "if" && x === "x{" ? (a[t - 1] = -20, a.push(-20), console.log(x, w, h, u, a[t], f)) : a.push(-10);
    }
    do
      e.lexer[t] === N ? (u = e.types[t], h = e.token[t], u === "comment" ? _() : u === "regex" ? a.push(-20) : u === "string" ? D() : u.indexOf("template_string") === 0 ? ge() : u === "separator" ? V() : u === "start" ? se() : u === "end" ? ee() : u === "type" || u === "type_start" || u === "type_end" ? Be() : u === "operator" ? J() : u === "word" ? Se() : u === "reference" ? X() : u === "markup" ? T() : u.indexOf("liquid") === 0 ? re() : u === "generic" ? ($(x, 35) && x !== "return" && w !== "operator" && x !== "public" && x !== "private" && x !== "static" && x !== "final" && x !== "implements" && x !== "class" && x !== "void" && (a[t - 1] = -20), i(e.token[t + 1], 40) || e.token[t + 1] === "x(" ? a.push(-20) : a.push(-10)) : a.push(-10), u !== "comment" && (w = u, x = h), A.length > 0 && $(e.token[t], 41) && (e.types[t] === "comment" && A[A.length - 1] > -1 ? A[A.length - 1] = s.wrap + 1 : a[t] > -1 || i(e.token[t], 96) && e.token[t].indexOf(Z) > 0 ? A[A.length - 1] = -1 : A[A.length - 1] > -1 && (A[A.length - 1] = A[A.length - 1] + e.token[t].length, a[t] === -10 && (A[A.length - 1] = A[A.length - 1] + 1)))) : we(), t = t + 1;
    while (t < o);
    return a;
  })();
  return (() => {
    let t = [], f = s.indentChar.repeat(s.indentSize), W = s.preserveLine + 1, R = [
      "x;",
      "x}",
      "x{",
      "x(",
      "x)"
    ], u = r.start, h = s.indentLevel;
    function w(ae) {
      let z = (() => u === o - 1 ? 1 : e.lines[u + 1] - 1 > W ? W : e.lines[u + 1] > 1 ? e.lines[u + 1] - 1 : 1)();
      return r.crlf.repeat(z) + f.repeat(ae);
    }
    if (n.vertical === !0) {
      let ae = function(z) {
        let a = 0, C = 0, F = z - 1, B = 0, G = 0, ie = e.begin[u], q = [];
        do {
          if ((e.begin[F] === ie || i(e.token[F], 93) || i(e.token[F], 41)) && (i(e.token[F + 1], 61) || i(e.token[F + 1], 59) && e.stack[F] === "object")) {
            B = F, C = 0;
            do {
              if (e.begin[B] === ie) {
                if (i(e.token[B], 58) || i(e.token[B], 59) || e.token[B] === "x;" || d[B] > -1 && e.types[B] !== "comment") {
                  i(e.token[B + 1], 46) && (C = C + s.indentSize * s.indentChar.length);
                  break;
                }
              } else if (d[B] > -1)
                break;
              e.types[B] !== "comment" && (d[B - 1] === -10 && (C = C + 1), C = e.token[B].length + C), B = B - 1;
            } while (B > ie);
            if (G = B, i(e.token[G], 44) && i(e.token[F + 1], 61))
              do {
                if (e.types[G] === "end" && (G = e.begin[G]), e.begin[G] === ie) {
                  if (i(e.token[G], 59) || e.token[G] === "x;")
                    break;
                  if (e.token[G] === "var" || e.token[G] === "const" || e.token[G] === "let") {
                    C = C + s.indentSize * s.indentChar.length;
                    break;
                  }
                }
                G = G - 1;
              } while (G > ie);
            C > a && (a = C), q.push([F, C]), F = B;
          } else
            e.types[F] === "end" && (F = e.begin[F]);
          F = F - 1;
        } while (F > ie);
        if (F = q.length, F > 0)
          do
            if (F = F - 1, B = q[F][1], B < a)
              do
                e.token[q[F][0]] = e.token[q[F][0]] + Y, B = B + 1;
              while (B < a);
          while (F > 0);
      };
      u = o;
      do
        u = u - 1, e.lexer[u] === "script" && i(e.token[u], 125) && $(e.token[u - 1], 123) && d[e.begin[u]] > 0 ? ae(u) : u = e.begin[u];
      while (u > 0);
    }
    u = r.start;
    do {
      if (e.lexer[u] === N) {
        if (e.types[u] === "comment" && n.commentIndent === !0 && /\n/.test(e.token[u])) {
          let ae = e.begin[u] > -1 ? i(e.token[u][2], 42) ? Xe(d[u], f) + s.indentChar : Xe(d[u], f) : s.indentChar, z = e.token[u].split(/\n/), a = 1;
          do
            z[a] = ae + z[a].trimStart(), a = a + 1;
          while (a < z.length);
          e.token.splice(u, 1, z.join(Z));
        }
        R.indexOf(e.token[u]) < 0 && ($(e.token[u], 59) || n.noSemicolon === !1 ? t.push(e.token[u]) : d[u] < 0 && e.types[u + 1] !== "comment" && t.push(";")), u < o - 1 && e.lexer[u + 1] !== N && e.begin[u] === e.begin[u + 1] && e.types[u + 1].indexOf("end") < 0 && $(e.token[u], 44) ? t.push(Y) : d[u] > -1 ? ((d[u] > -1 && i(e.token[u], 123) || d[u] > -1 && i(e.token[u + 1], 125)) && e.lines[u] < 3 && n.braceNewline === !0 && e.lines[u + 1] < 3 && t.push(w(0)), r.mode === 2 ? r.ender !== u && t.push(w(d[u])) : u !== o - 1 && t.push(w(d[u])), h = d[u]) : d[u] === -10 && (t.push(Y), e.lexer[u + 1] !== N && (h = h + 1));
      } else if (l[u] === u)
        t.push(e.token[u]);
      else {
        r.ender = l[u], r.start = u;
        let ae = r.external(h);
        t.push(ae), u = r.iterator, d[u] === -10 ? t.push(Y) : d[u] > -1 && t.push(w(d[u]));
      }
      u = u + 1;
    } while (u < o);
    return r.iterator = o - 1, t.join(p);
  })();
}

// src/format/style.ts
function Di() {
  let e = [], { data: s, rules: n, crlf: c } = r, O = Oi(null), l = r.ender > 0 ? r.ender + 1 : s.token.length, N = n.preserveLine + 1, o = n.indentChar.repeat(n.indentSize), d = n.indentLevel, b = r.start, t = [p, p];
  function f(R, u) {
    return s.types[R] === u;
  }
  function W(R) {
    let u = [], h = (() => b === l - 1 ? 1 : s.lines[b + 1] - 1 > N ? N : s.lines[b + 1] > 1 ? s.lines[b + 1] - 1 : 1)(), w = 0;
    R < 0 && (R = 0);
    do
      u.push(c), w = w + 1;
    while (w < h);
    if (R > 0) {
      w = 0;
      do
        u.push(o), w = w + 1;
      while (w < R);
    }
    e.push(u.join(p));
  }
  do {
    switch ((f(b + 1, "end") || f(b + 1, "liquid_end") || f(b + 1, "liquid_else")) && d > 0 && (d = d - 1), f(b, "liquid") ? (e.push(s.token[b]), $(s.token[b + 1], 59) && ye.css.units.has(s.token[b + 1]) === !1 && (f(b + 1, "start") ? e.push(Y) : W(d))) : f(b - 1, "selector") && f(b, "liquid") && f(b + 1, "selector") ? (e.push(s.token[b]), $e(s.token[b - 1], 45) && (i(s.token[b + 1], 46) || i(s.token[b + 1], 35) || i(s.token[b + 1], 38)) && e.push(Y)) : f(b, "liquid_else") ? (e.push(s.token[b]), f(b + 1, "property") && (d = d + 1), s.lines[b + 1] === 1 ? e.push(Y) : s.lines[b + 1] > 1 && W(d)) : f(b, "liquid_start") ? (e.push(s.token[b]), s.lines[b + 1] === 1 ? e.push(Y) : (s.lines[b + 1] > 1 || (f(b + 1, "liquid") || f(b + 1, "selector")) && f(b + 2, "start")) && (d = d + 1, W(d))) : f(b, "liquid_end") ? (e.push(s.token[b]), f(b + 1, "start") ? e.push(Y) : s.lines[b + 1] !== 0 && W(d)) : f(b, "start") ? (e.push(s.token[b]), (f(b + 1, "property") || f(b + 1, "selector") || f(b + 1, "comment") || f(b + 1, "liquid") || f(b + 1, "liquid_start")) && (d = d + 1), f(b + 1, "end") === !1 && W(d)) : i(s.token[b], 59) ? (e.push(s.token[b]), f(b + 1, "property") && ((f(b - 2, "liquid") || f(b - 2, "liquid_end")) && f(b - 1, "value") || f(b - 1, "liquid_end")) && (d = d + 1, d > O.property && (d = O.property)), W(d)) : f(b, "end") || f(b, "comment") ? (e.push(s.token[b]), f(b + 1, "value") ? s.lines[b + 1] === 1 ? e.push(Y) : s.lines[b + 1] > 1 && W(d) : f(b - 1, "liquid_end") && f(b, "separator") && f(b + 1, "property") ? (d = d + 1, W(d), console.log(s.token[b])) : f(b + 1, "separator") === !1 ? f(b + 1, "comment") === !1 || f(b + 1, "comment") && s.lines[b + 1] > 1 ? W(d) : e.push(Y) : f(b, "comment") && f(b + 1, "comment") === !1 && s.lines[b] > 1 && W(d)) : i(s.token[b], 58) ? (e.push(s.token[b]), f(b + 1, "selector") === !1 && $(s.token[b + 1], 44) && e.push(Y)) : f(b, "selector") || f(b, "at_rule") ? (n.style.classPadding === !0 && f(b - 1, "end") && s.lines[b] < 3 && W(d), s.token[b].indexOf("and(") > 0 ? (s.token[b] = s.token[b].replace(/and\(/, "and ("), e.push(s.token[b])) : s.token[b].indexOf("when(") > 0 ? (t = s.token[b].split("when("), e.push(t[0].replace(/\s+$/, p)), W(d + 1), e.push(`when (${t[1]}`)) : e.push(s.token[b]), f(b + 1, "start") ? e.push(Y) : s.types[b + 1].indexOf("liquid") > -1 && s.lines[b + 1] === 0 && (e.push(s.token[b + 1]), b = b + 1)) : i(s.token[b], 44) ? (f(b + 1, "value") && W(d), e.push(s.token[b]), f(b + 1, "selector") || f(b + 1, "property") ? W(d) : e.push(Y), f(b - 1, "selector") && f(b + 1, "liquid_end") && W(d)) : s.stack[b] === "map" && i(s.token[b + 1], 41) && b - s.begin[b] > 5 ? (e.push(s.token[b]), W(d)) : s.token[b] === "x;" ? W(d) : (f(b, "variable") || f(b, "function")) && n.style.classPadding === !0 && f(b - 1, "end") && s.lines[b] < 3 ? (e.push(c), e.push(s.token[b])) : $(s.token[b], 59) && (e.push(s.token[b]), (f(b + 1, "liquid_end") || f(b + 1, "liquid_else")) && (s.lines[b + 1] === 1 ? e.push(Y) : s.lines[b + 1] > 1 && W(d))), s.types[b + 1]) {
      case "property":
        O.property = d;
        break;
      case "end":
        O.property = d - 1;
        break;
      case "selector":
        s.types[b] === "selector" && (O.property = d);
        break;
    }
    b = b + 1;
  } while (b < l);
  return r.iterator = l - 1, (e[0] === r.crlf || i(e[0], 32)) && (e[0] = p), n.endNewline === !0 ? e.join(p).replace(/\s*$/, r.crlf) : e.join(p).replace(/\s+$/, p);
}

// src/format/index.ts
function ei(e) {
  if (e === 1)
    return Mi();
  if (e === 3)
    return Di();
  if (e === 2)
    return _i();
}

// ../../node_modules/.pnpm/mergerino@0.4.0/node_modules/mergerino/dist/mergerino.min.js
var sn = Object.assign || ((e, s) => (s && Object.keys(s).forEach((n) => e[n] = s[n]), e)), ti = (e, s, n) => {
  let c = typeof n;
  if (n && c === "object")
    if (Array.isArray(n))
      for (let O of n)
        s = ti(e, s, O);
    else
      for (let O of Object.keys(n)) {
        let l = n[O];
        typeof l == "function" ? s[O] = l(s[O], $t) : l === void 0 ? e && !isNaN(O) ? s.splice(O, 1) : delete s[O] : l === null || typeof l != "object" || Array.isArray(l) ? s[O] = l : typeof s[O] == "object" ? s[O] = l === s[O] ? l : $t(s[O], l) : s[O] = ti(!1, {}, l);
      }
  else
    c === "function" && (s = n(s, $t));
  return s;
}, $t = (e, ...s) => {
  let n = Array.isArray(e);
  return ti(n, n ? e.slice() : sn({}, e), s);
}, Fe = $t;

// src/rules/presets/default.ts
var ct = Fe({
  crlf: !1,
  correct: !1,
  preset: "default",
  language: "auto",
  endNewline: !1,
  indentChar: " ",
  indentLevel: 0,
  indentSize: 2,
  preserveLine: 2,
  wrap: 0,
  wrapFraction: 0,
  liquid: {
    commentNewline: !1,
    commentIndent: !0,
    delimiterTrims: "preserve",
    delimiterPlacement: "preserve",
    forceFilter: 0,
    forceArgument: 0,
    ignoreTagList: [],
    indentAttribute: !1,
    lineBreakSeparator: "before",
    normalizeSpacing: !0,
    preserveComment: !1,
    preserveInternal: !1,
    dedentTagList: [],
    quoteConvert: "none"
  },
  markup: {
    attributeCasing: "preserve",
    attributeSort: !1,
    commentNewline: !1,
    commentIndent: !0,
    delimiterTerminus: "inline",
    forceAttribute: 3,
    forceAttributeValue: !0,
    forceIndent: !1,
    ignoreCSS: !1,
    ignoreJS: !0,
    ignoreJSON: !1,
    lineBreakValue: "preserve",
    preserveComment: !1,
    preserveText: !1,
    preserveAttribute: !1,
    selfCloseSpace: !0,
    selfCloseSVG: !0,
    stripAttributeLines: !1,
    quoteConvert: "none"
  },
  json: {
    arrayFormat: "default",
    braceAllman: !1,
    bracePadding: !1,
    objectIndent: "default",
    objectSort: !1,
    braceStyle: "none",
    caseSpace: !1,
    commentIndent: !1,
    commentNewline: !1,
    correct: !1,
    elseNewline: !1,
    functionNameSpace: !1,
    functionSpace: !1,
    methodChain: 4,
    neverFlatten: !1,
    noCaseIndent: !1,
    preserveComment: !1,
    styleGuide: "none",
    ternaryLine: !1,
    variableList: "none",
    quoteConvert: "double",
    endComma: "never",
    noSemicolon: !0,
    vertical: !1
  },
  style: {
    commentIndent: !1,
    commentNewline: !1,
    atRuleSpace: !0,
    classPadding: !1,
    noLeadZero: !1,
    preserveComment: !1,
    sortSelectors: !1,
    sortProperties: !1,
    quoteConvert: "none"
  },
  script: {
    arrayFormat: "default",
    braceNewline: !1,
    bracePadding: !1,
    braceStyle: "none",
    braceAllman: !1,
    caseSpace: !1,
    commentIndent: !1,
    commentNewline: !1,
    elseNewline: !1,
    endComma: "never",
    functionNameSpace: !1,
    functionSpace: !1,
    inlineReturn: !0,
    methodChain: 4,
    neverFlatten: !1,
    noCaseIndent: !1,
    noSemicolon: !1,
    objectSort: !1,
    objectIndent: "default",
    preserveComment: !1,
    quoteConvert: "none",
    styleGuide: "none",
    ternaryLine: !1,
    variableList: "none",
    vertical: !1
  }
});

// src/parse/parser.ts
var ii = class extends Array {
  get entry() {
    return this[this.length - 1];
  }
  get token() {
    return this[this.length - 1][0];
  }
  get index() {
    return this[this.length - 1][1];
  }
  update(s, n) {
    let c = this.length - 1;
    return c > 0 ? (n === void 0 ? typeof s == "string" ? this[c][0] = s : this[c][1] = s : (this[c][0] = s, this[c][1] = n), this[c]) : (this.push([s, n]), this[c + 1]);
  }
  pop() {
    let s = this.length - 1, n = this[s];
    return s > 0 && this.splice(s, 1), n;
  }
}, Ue = class {
  constructor() {
    /**
     * Hooks
     *
     * Event Listeners which will trigger during traversal and the
     * formatting cycle. This is a future feature to allow consumers
     * to augment and adjust tokens.
     */
    this.hooks = { parse: null, format: null };
    /**
     * Hard coded line numbers
     */
    this.numbers = [];
    /**
     * Reference to a starting index within the data structure. This is
     * used for external regions, but can also provide incremental support.
     */
    this.start = 0;
    /**
     * Reference to a ender index within the data structure. This is
     * used for external regions, but can also provide incremental support.
     */
    this.ender = 0;
    /**
     * Reference to `a`
     */
    this.iterator = 0;
    /**
     * Reference of attributes of newline values with containing Liquid block tokens.
     * It maintains a store which is generated in the markup lexer and used within
     * the beautification cycle
     */
    this.attributes = /* @__PURE__ */ new Map();
    /**
     * External language regions, typically embedded tokens which use a different
     * lexer. This map maintains stores during the lexing process for switching.
     */
    this.regions = /* @__PURE__ */ new Map();
    /**
     * Holds a store reference to markup start/end pairs. This is used for potential
     * parse errors and keeps track of paired sequences for syntactic reporting.
     */
    this.pairs = /* @__PURE__ */ new Map();
    /**
     * Parse Error reference. Defaults to `null` and will be assigned an object reference exception
     */
    this.error = null;
    /**
     * Hardcoded string reference to CRLF rule
     */
    this.crlf = `
`;
    /**
     * Stores the declared variable names for the script lexer. This must be stored outside
     * the script lexer since some languages recursive use of the script lexer
     */
    this.references = [[]];
    /**
     * Stores the final index location of the data arrays
     */
    this.count = -1;
    /**
     * The current line column character starting from left side of the
     * beginning of a newline. For example
     *
     * ```
     *
     * 1 | xxx
     * 2 | hello world
     *               ^   // Column 11
     *
     * ```
     *
     * In the example above, the column reference equals `[11]` and points
     * to the letter `d` in cases where we need this context, it exists
     * at this point.
     */
    this.lineColumn = 0;
    /**
     * The current line number. Line numbers start at index `1` instead of `0`,
     * which is something to keep in mind if referencing. This is used in errors
     * and counts the number of lines as we have spanned during traversal. For example:
     *
     * ```
     *
     * 1 | hello  // Line 1
     * 2 | world  // Line 2
     *
     *
     * ```
     */
    this.lineNumber = 1;
    /**
     * The current line depth. This keep a reference to the indentation
     * depth currently traversed and used to capture the left most indent level.
     *
     * ```
     *
     * 1 | <div>        // 2
     * 2 | <ul>         // 4
     * 3 | <li>         // 6
     * 4 | {{ HERE }}   // 8
     * 5 | </li>        // 6
     * 6 | </ul>        // 4
     * 7 | </div>       // 2
     *
     * ```
     *
     * In the example above, it is assumed that `indentChar` is set to a value
     * of `2` (default). For every `start` token, the depth increases.
     */
    this.lineDepth = 2;
    /**
     * The record `lines` value count before the next token, for example:
     *
     * ```
     *
     * 1 | foo  // line offset is: 0
     * 2 | bar  // line offset is: 2
     * 3
     * 4 | baz  // line offset is: 3
     * 5
     * 6
     * 7 | qux  // line offset is: 4
     * 8 | xxx  // line offset is: 2
     *
     *
     * ```
     *
     * Where `foo` is `0` as it exists on line `1` but `bar` is `2` because
     * it counts line `1` as a single line and given it exists on line `2`
     * another line offset increment is applies. The word `baz` is similar to
     * `bar` but has a count of `3` given a newline exists above it and this
     * pattern follows as we progress to `qux` which has 2 newlines, equating
     * to a value line offset of `4` whereas `xxx` only has `2` so on and so forth.
     */
    this.lineOffset = 0;
    /**
     * The character index of the last known newline, for example:
     *
     * ```
     *
     * 1 | abcdefgh
     * 2 | ijklmnop
     *     ^
     *
     * ```
     *
     * Where character `i` is index `[8]` and index `[8]` is the
     * beginning of line `2`.
     *
     */
    this.lineIndex = 0;
    /**
     * The formatting and parse rules
     */
    this.rules = ct;
    /**
     * The parse table data structure
     */
    this.data = {
      begin: [],
      ender: [],
      lexer: [],
      lines: [],
      stack: [],
      token: [],
      types: []
    };
  }
  /**
   * The document source `input` reference
   */
  get source() {
    return this.mode === 2 ? Ue.region : Ne.env === "node" && Buffer.isBuffer(Ue.input) ? Ue.input.toString() : Ue.input;
  }
  /**
   * Set the source `input` reference
   */
  set source(s) {
    Ue.input = Ne.env !== "node" || Buffer.isBuffer(s) ? s : Buffer.from(s);
  }
  get current() {
    return {
      begin: this.data.begin[this.count],
      ender: this.data.ender[this.count],
      lexer: this.data.lexer[this.count],
      lines: this.data.lines[this.count],
      stack: this.data.stack[this.count],
      token: this.data.token[this.count],
      types: this.data.types[this.count]
    };
  }
  /**
   * Reset
   *
   * Resets the current stores for clean parse structures
   */
  reset() {
    this.error = null, this.count = -1, this.start = 0, this.ender = 0, this.lineColumn = 0, this.lineNumber = 1, this.lineDepth = 2, this.lineIndex = 0, this.lineOffset = 0, this.numbers = [], this.data.begin = [], this.data.ender = [], this.data.lexer = [], this.data.lines = [], this.data.stack = [], this.data.token = [], this.data.types = [], this.references = [[]], this.stack = new ii(["global", -1]), this.mode = 1, this.pairs.size > 0 && this.pairs.clear(), this.attributes.size > 0 && this.attributes.clear(), this.regions.size > 0 && this.regions.clear();
  }
  /**
   * Get Record
   *
   * Returns a record at the give index
   */
  get(s) {
    return {
      begin: this.data.begin[s],
      ender: this.data.ender[s],
      lexer: this.data.lexer[s],
      lines: this.data.lines[s],
      stack: this.data.stack[s],
      token: this.data.token[s],
      types: this.data.types[s]
    };
  }
  /**
   * Document Parse
   *
   * Executes a full parse - top to bottom.
   */
  document(s, n = 3) {
    return this.reset(), Yt(s), n === 1 ? this.data : (this.mode = 3, ei(s));
  }
  /**
   * Switch
   *
   * Used to switch between lexers and formatters when
   * dealing with embedded regions.
   */
  external(s, n) {
    if (this.mode === 1) {
      this.mode = 2;
      let c = ht(s);
      Ue.region = n, this.language = s, this.lexer = Pe(this.language), this.regions.set(this.count + 1, { lexer: c, id: this.language }), Yt(c), this.mode = 1, this.lexer = Pe(this.rules.language), this.language = this.rules.language;
    } else {
      if (this.regions.size === 0)
        return this.source;
      let { id: c, lexer: O } = this.regions.get(this.start);
      this.mode = 2, this.language = c, this.rules.indentLevel = s;
      let l = ei(O);
      return this.mode = 3, this.rules.indentLevel = 0, this.language = this.rules.language, this.lexer = Pe(this.language), l;
    }
  }
  /**
   * Push Final
   *
   * The final conclusion for the data strucuture uniform.
   */
  final(s) {
    let n = this.count, c = s.begin[n];
    if (!(s.lexer[n] === "style" && this.rules.style.sortProperties || s.lexer[n] === "script" && (this.rules.script.objectSort || this.rules.json.objectSort))) {
      do
        s.begin[n] === c || s.begin[s.begin[n]] === c && s.types[n].indexOf("attribute") > -1 && s.types[n].indexOf("attribute_end") < 0 ? s.ender[n] = this.count : n = s.begin[n], n = n - 1;
      while (n > c);
      n > -1 && (s.ender[n] = this.count);
    }
  }
  /**
   * Syntactical Tracking
   *
   * This is a store The `parse.data.begin` index. This will typically
   * reference the `parse.count` value, incremented by `1`
   */
  syntactic(s, n) {
    if (s.types === "liquid_start" || s.types === "start")
      this.pairs.set(this.count, {
        index: this.count,
        line: this.lineNumber,
        token: s.token,
        type: s.types === "start" ? 2 : 3,
        stack: n
      });
    else if (this.pairs.has(this.stack.index) && (s.types === "end" || s.types === "liquid_end")) {
      let c = this.pairs.get(this.stack.index);
      c.type === 3 ? s.token.indexOf(`end${c.stack}`) > -1 ? this.pairs.delete(this.stack.index) : Rt(112, c) : c.type === 2 && `</${c.stack}>` === s.token && this.pairs.delete(this.stack.index);
    }
  }
  /**
   * Replace Record
   *
   * Replaces a single record at the provided index. If no index is
   * passed it will use the last known record reference.
   */
  replace(s, n = this.count) {
    for (let c in s)
      this.data[c][n] = s[c];
  }
  /**
   * Push Structure
   *
   * An extension of `Array.prototype.push` to work across the parse table data structure
   */
  push(s, n, c = p) {
    if (s.begin.push(n.begin), s.ender.push(n.ender), s.lexer.push(n.lexer), s.stack.push(n.stack), s.token.push(n.token), s.types.push(n.types), s.lines.push(n.lines), this.numbers.push(this.lineNumber), s === this.data) {
      if (this.count = this.count + 1, n.lexer !== "style" && c.replace(/[{}<>%]/g, p) === p && (c = n.types === "else" ? "else" : _e(n.token)), this.lineOffset = 0, n.types === "start" || n.types.indexOf("_start") > 0)
        this.stack.push([c, this.count]), this.lineDepth = this.lineDepth + this.rules.indentSize;
      else if (n.types === "end" || n.types.indexOf("_end") > 0) {
        let O = 0, l = this.stack.length;
        l > 2 && (s.types[this.stack[l - 1][1]] === "else" || s.types[this.stack[l - 1][1]].indexOf("_else") > 0) && (s.types[this.stack[l - 2][1]] === "start" || s.types[this.stack[l - 2][1]].indexOf("_start") > 0) && (s.types[this.stack[l - 2][1] + 1] === "else" || s.types[this.stack[l - 2][1] + 1].indexOf("_else") > 0) && (this.stack.pop(), s.begin[this.count] = this.stack.index, s.stack[this.count] = this.stack.token, s.ender[this.count - 1] = this.count, O = s.ender[s.begin[this.count] + 1]), this.final(s), O > 0 && (s.ender[s.begin[this.count] + 1] = O), this.stack.pop(), this.lineDepth = this.lineDepth - this.rules.indentSize;
      } else
        (n.types === "else" || n.types.indexOf("_else") > 0) && (c === p && (c = "else"), this.count > 0 && (s.types[this.count - 1] === "start" || s.types[this.count - 1].indexOf("_start") > 0) ? this.stack.push([c, this.count]) : (this.final(s), this.stack.update(c === p ? "else" : c, this.count)));
      this.hooks.parse !== null && this.hooks.parse[0].call({
        line: this.lineNumber,
        stack: this.stack.entry,
        language: this.language
      }, n, this.count);
    }
  }
  /**
   * Pop Structure
   *
   * An extension of `Array.prototype.pop` to work across the data
   * structure
   */
  pop(s) {
    return s === this.data && (this.count = this.count - 1), this.numbers.pop(), {
      begin: s.begin.pop(),
      ender: s.ender.pop(),
      lexer: s.lexer.pop(),
      lines: s.lines.pop(),
      stack: s.stack.pop(),
      token: s.token.pop(),
      types: s.types.pop()
    };
  }
  /**
   * Concat Structure
   *
   * An extension of `Array.prototype.concat` to work across
   * the data structure. This is an expensive operation.
   */
  concat(s, n) {
    s.begin = s.begin.concat(n.begin), s.ender = s.ender.concat(n.ender), s.lexer = s.lexer.concat(n.lexer), s.stack = s.stack.concat(n.stack), s.token = s.token.concat(n.token), s.types = s.types.concat(n.types), s.lines = s.lines.concat(n.lines), s === this.data && (this.count = s.token.length - 1);
  }
  /**
   * Splice Structure
   *
   * An extension of `Array.prototype.splice` to work across the data structure
   */
  splice(s) {
    let n = this.data.begin[this.count], c = this.data.token[this.count];
    s.record !== void 0 && s.record.token !== p ? (s.data.begin.splice(s.index, s.howmany, s.record.begin), s.data.ender.splice(s.index, s.howmany, s.record.ender), s.data.token.splice(s.index, s.howmany, s.record.token), s.data.lexer.splice(s.index, s.howmany, s.record.lexer), s.data.stack.splice(s.index, s.howmany, s.record.stack), s.data.types.splice(s.index, s.howmany, s.record.types), s.data.lines.splice(s.index, s.howmany, s.record.lines), s.data === this.data && (this.count = this.count - s.howmany + 1, (n !== this.data.begin[this.count] || c !== this.data.token[this.count]) && (this.lineOffset = 0))) : (s.data.begin.splice(s.index, s.howmany), s.data.ender.splice(s.index, s.howmany), s.data.token.splice(s.index, s.howmany), s.data.lexer.splice(s.index, s.howmany), s.data.stack.splice(s.index, s.howmany), s.data.types.splice(s.index, s.howmany), s.data.lines.splice(s.index, s.howmany), s.data === this.data && (this.count = this.count - s.howmany, this.lineOffset = 0));
  }
  /**
   * Is Checksum
   *
   * Checks a record value on the last know entry in the
   * parse table data strcuture
   */
  is(s, n) {
    return this.count > 0 ? this.data[s][this.count] === n : !1;
  }
  /**
   * Line Increment
   *
   * A small helper for incrementing newlines. Expects an `index` which
   * matches the current iteration point and an optional `lines` parameter
   * which will be incremented by `1` and the returning value.
   */
  lines(s, n) {
    return this.lineNumber = this.lineNumber + 1, this.lineIndex = s, n + 1;
  }
  spacer(s) {
    this.lineOffset = 1;
    do {
      if (s.array[s.index] === Z && (this.lineOffset = this.lineOffset + 1, this.lineNumber = this.lineNumber + 1), le(s.array[s.index + 1]) === !1)
        break;
      s.index = s.index + 1;
    } while (s.index < s.end);
    return s.index;
  }
}, wt = Ue;
/**
 * Static reference of the provided input
 */
wt.input = p, /**
 * Static reference to the current external region input
 */
wt.region = p;
var r = new wt();

// src/parse/detection.ts
function Qi(e) {
  let s = [], n = 0, c = /(((var)|(let)|(const)|(function)|(import))\s+(\w|\$)+[a-zA-Z0-9]*)/.test(e) && /@import/.test(e) === !1, O = /((((final)|(public)|(private))\s+static)|(static\s+void))/.test(e);
  function l() {
    return /\n\s*#+\s+/.test(e) || /^#+\s+/.test(e) ? {
      language: "markdown",
      lexer: "markup"
    } : /\$[a-zA-Z]/.test(e) || /\{\s*(\w|\.|\$|#)+\s*\{/.test(e) || /^[.#]?[\w][\w-]+\s+\{(?:\s+[a-z][a-z-]+:\s*\S+;)+\s+[&>+]?\s+[.#:]?[\w][\w-]\s+\{/.test(e) && /:\s*@[a-zA-Z];/.test(e) === !1 ? {
      language: "scss",
      lexer: "style"
    } : /@[a-zA-Z]:/.test(e) || /\.[a-zA-Z]\(\);/.test(e) ? {
      language: "less",
      lexer: "style"
    } : {
      language: "css",
      lexer: "style"
    };
  }
  function N() {
    let d = 1, b = p, t = !1, f = !1, W = /((public)|(private))\s+(static\s+)?(((v|V)oid)|(class)|(final))/.test(e);
    function R() {
      return e.indexOf("(") > -1 || e.indexOf("=") > -1 || e.indexOf(";") > -1 && e.indexOf("{") > -1 ? O === !0 || /\w<\w+(,\s+\w+)*>/.test(e) || /(?:var|let|const)\s+\w+\s*:/.test(e) || /=\s*<\w+/.test(e) ? {
        language: "typescript",
        lexer: "script"
      } : {
        language: "javascript",
        lexer: "script"
      } : {
        language: "unknown",
        lexer: "text"
      };
    }
    function u() {
      return /:\s*(?:number|string|boolean|any|unknown)(?:\[\])?/.test(e) || /(?:public|private)\s+/.test(e) || /(?:export|declare)\s+type\s+\w+\s*=/.test(e) || /(?:namespace|interface|enum|implements|declare)\s+\w+/.test(e) || /(?:typeof|keyof|as)\s+\w+/.test(e) || /\w+\s+as\s+\w+/.test(e) || /\[\w+(?:(?::\s*\w+)|(?:\s+in\s+\w+))\]:/.test(e) || /\):\s*\w+(?:\[\])?\s*(?:=>|\{)\s+/.test(e) || /(var|const|let)\s+\w+:\s*(string|number|boolean|string|any)(\[\])?/.test(e) ? {
        language: "typescript",
        lexer: "script"
      } : /\s(class|var|const|let)\s+\w/.test(e) === !1 && /<[a-zA-Z](?:-[a-zA-Z])?/.test(e) && /<\/[a-zA-Z-](?:-[a-zA-Z])?/.test(e) && (/\s?\{%/.test(e) || /{{/.test(e)) ? {
        language: "liquid",
        lexer: "markup"
      } : /^(\s*[$@])/.test(e) === !1 && /([}\]];?\s*)$/.test(e) && (/^\s*import\s+\*\s+as\s+\w+\s+from\s+['"]/.test(e) || /module\.export\s+=\s+/.test(e) || /export\s+default\s+\{/.test(e) || /[?:]\s*[{[]/.test(e) || /^(?:\s*return;?(?:\s+[{[])?)/.test(e)) ? {
        language: "javascript",
        lexer: "script"
      } : /{%/.test(e) && /{{/.test(e) && /<\w/.test(e) ? {
        language: "liquid",
        lexer: "markup"
      } : /{\s*(?:\w|\.|@|#)+\s*\{/.test(e) ? {
        language: "less",
        lexer: "style"
      } : /\$(\w|-)/.test(e) ? {
        language: "scss",
        lexer: "style"
      } : /[;{:]\s*@\w/.test(e) === !0 ? {
        language: "less",
        lexer: "style"
      } : {
        language: "css",
        lexer: "style"
      };
    }
    if (d < n)
      do
        t === !1 ? i(s[d], 42) && i(s[d - 1], 47) ? (s[d - 1] = p, t = !0) : f === !1 && d < n - 6 && s[d].charCodeAt(0) === 102 && //     f
        s[d + 1].charCodeAt(0) === 105 && // i
        s[d + 2].charCodeAt(0) === 108 && // l
        s[d + 3].charCodeAt(0) === 116 && // t
        s[d + 4].charCodeAt(0) === 101 && // e
        s[d + 5].charCodeAt(0) === 114 && // r
        i(s[d + 6], 58) && (f = !0) : t === !0 && i(s[d], 42) && d !== n - 1 && i(s[d + 1], 47) ? (t = !1, s[d] = p, s[d + 1] = p) : f === !0 && i(s[d], 59) && (f = !1, s[d] = p), (t === !0 || f === !0) && (s[d] = p), d = d + 1;
      while (d < n);
    return b = s.join(p), /\s\/\//.test(e) === !1 && /\/\/\s/.test(e) === !1 && /^(\s*(\{|\[)(?!%))/.test(e) === !0 && /((\]|\})\s*)$/.test(e) && e.indexOf(",") !== -1 ? {
      language: "json",
      lexer: "script"
    } : /((\}?(\(\))?\)*;?\s*)|([a-z0-9]("|')?\)*);?(\s*\})*)$/i.test(e) === !0 && (c === !0 || W === !0 || /console\.log\(/.test(e) === !0 || /export\s+default\s+class\s+/.test(e) === !0 || /export\s+(const|var|let|class)s+/.test(e) === !0 || /document\.get/.test(e) === !0 || /((=|(\$\())\s*function)|(\s*function\s+(\w*\s+)?\()/.test(e) === !0 || e.indexOf("{") === -1 || /^(\s*if\s+\()/.test(e) === !0) ? R() : e.indexOf("{") > -1 && (/^(\s*[\u007b\u0024\u002e#@a-z0-9])/i.test(e) || /^(\s*\/(\*|\/))/.test(e) || /^(\s*\*\s*\{)/.test(e)) && /^(\s*if\s*\()/.test(e) === !1 && /=\s*(\{|\[|\()/.test(b) === !1 && (/(\+|-|=|\?)=/.test(b) === !1 || /\/\/\s*=+/.test(b) || /=+('|")?\)/.test(e) && /;\s*base64/.test(e)) && /function(\s+\w+)*\s*\(/.test(b) === !1 ? u() : e.indexOf("{%") > -1 ? {
      language: "liquid",
      lexer: "markup"
    } : {
      language: "unknown",
      lexer: "text"
    };
  }
  function o() {
    function d() {
      return /{%-?\s*(schema|for|if|unless|render|include)/.test(e) || /{%-?\s*end\w+/.test(e) || /{{-?\s*content_for/.test(e) || /{{-?\s*[a-zA-Z0-9_'".[\]]+\s*-?}}/.test(e) || /{%/.test(e) && /%}/.test(e) && /{{/.test(e) && /}}/.test(e) ? {
        language: "liquid",
        lexer: "markup"
      } : {
        language: "html",
        lexer: "markup"
      };
    }
    return /^(\s*<!doctype\s+html>)/i.test(e) || /^(\s*<html)/i.test(e) || /<form\s/i.test(e) && /<label\s/i.test(e) && /<input\s/i.test(e) || /<img(\s+\w+=['"]?\S+['"]?)*\s+src\s*=/.test(e) || /<a(\s+\w+=['"]?\S+['"]?)*\s+href\s*=/.test(e) || /<ul\s/i.test(e) && /<li\s/i.test(e) && /<\/li>/i.test(e) && /<\/ul>/i.test(e) || /<head\s*>/.test(e) && /<\/head>/.test(e) || /^(\s*<!DOCTYPE\s+((html)|(HTML))\s+PUBLIC\s+)/.test(e) && /XHTML\s+1\.1/.test(e) === !1 && /XHTML\s+1\.0\s+(S|s)((trict)|(TRICT))/.test(e) === !1 ? d() : /\s?{[{%]-?/.test(e) ? {
      language: "liquid",
      lexer: "markup"
    } : {
      language: "xml",
      lexer: "markup"
    };
  }
  return e === null || e.replace(/\s+/g, p) === p ? {
    language: "unknown",
    lexer: "text"
  } : (/\n\s*#{1,6}\s+/.test(e) || /\n\s*(?:\*|-|(?:\d+\.))\s/.test(e)) && (/\[( |x|X)\]/.test(e) || /\s[*_~]{1,2}\w+[*_~]{1,2}/.test(e) || /\n\s*```[a-zA-Z]*?\s+/.test(e) || /-+\|(-+\|)+/.test(e)) ? {
    language: "markdown",
    lexer: "text"
  } : /^(\s*<!DOCTYPE\s+html>)/i.test(e) ? o() : /^\s*@(?:charset|import|include|keyframes|media|namespace|page)\b/.test(e) || /**
   * Final Statics Test
   */
  O === !1 && /=(>|=|-|\+|\*)/.test(e) === !1 && /^(?:\s*((if)|(for)|(function))\s*\()/.test(e) === !1 && /(?:\s|;|\})((if)|(for)|(function\s*\w*))\s*\(/.test(e) === !1 && c === !1 && /return\s*\w*\s*(;|\})/.test(e) === !1 && (e === void 0 || /^(?:\s*#(?!(!\/)))/.test(e) || /\n\s*(\.|@)\w+(\(|(\s*:))/.test(e) && />\s*<\w/.test(e) === !1 || /^\s*:root\s*\{/.test(e) || /-{2}\w+\s*\{/.test(e) || /^\s*(?:body|button|hr|section|h[1-6]|p|strong|\*)\s+\{\s+/.test(e)) ? l() : (s = e.replace(/\[[a-zA-Z][\w-]*=['"]?[a-zA-Z][\w-]*['"]?\]/g, p).split(p), n = s.length, /^(\s*({{|{%|<))/.test(e) ? o() : O === !0 || /^(?:[\s\w-]*<)/.test(e) === !1 && /(?:>[\s\w-]*)$/.test(e) === !1 ? N() : (/^(?:\s*<\?xml)/.test(e) || /(?:>[\w\s:]*)?<(?:\/|!|#)?[\w\s:\-[]+/.test(e) || /^\s*</.test(e) && /<\/\w+(\w|\d)+>\s*$/.test(e)) && (/^(?:[\s\w]*<)/.test(e) || /(?:>[\s\w]*)$/.test(e)) || /^(?:\s*<s((cript)|(tyle)))/i.test(e) && /(?:<\/s((cript)|(tyle))>\s*)$/i.test(e) ? /^(?:[\s\w]*<)/.test(e) === !1 || /(?:>[\s\w]*)$/.test(e) === !1 ? N() : o() : {
    language: "unknown",
    lexer: "text"
  });
}

// src/rules/validate.ts
function Wt(e, s, n) {
  if (e === "global")
    switch (s) {
      case "indentChar":
        return rn(e, s, n);
      case "preset":
      case "language":
        return He(e, s, n);
      case "crlf":
      case "correct":
      case "endNewline":
        return pt(e, s, n);
      case "indentLevel":
      case "indentSize":
      case "preserveLine":
      case "wrap":
      case "wrapFraction":
        return ni(e, s, n);
      default:
        return !1;
    }
  else if (e === "liquid")
    switch (s) {
      case "commentNewline":
      case "commentIndent":
      case "indentAttribute":
      case "normalizeSpacing":
      case "preserveComment":
      case "preserveInternal":
        return pt(e, s, n);
      case "forceArgument":
      case "forceFilter":
        return ni(e, s, n);
      case "ignoreTagList":
      case "dedentTagList":
        return Fi(e, s, n);
      case "lineBreakSeparator":
      case "delimiterPlacement":
      case "delimiterTrims":
      case "quoteConvert":
        return He(e, s, n);
    }
  else if (e === "markup")
    switch (s) {
      case "forceAttribute":
        if (st(n))
          return ni(e, s, n);
        if (Ke(n))
          return pt(e, s, n);
        throw Ae({
          message: `Invalid ${e} rule (${s}) type "${typeof n}" provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "boolean",
            "number"
          ]
        });
      case "attributeSort":
        if (Ke(n))
          return pt(e, s, n);
        if (Re(n))
          return Fi(e, s, n);
        throw Ae({
          message: `Invalid ${e} rule (${s}) type "${typeof n}" provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "boolean",
            "number"
          ]
        });
      case "commentNewline":
      case "commentIndent":
      case "forceIndent":
      case "forceAttributeValue":
      case "ignoreCSS":
      case "ignoreJS":
      case "ignoreJSON":
      case "preserveComment":
      case "preserveText":
      case "preserveAttribute":
      case "selfCloseSpace":
      case "selfCloseSVG":
      case "stripAttributeLines":
        return pt(e, s, n);
      case "attributeCasing":
      case "delimiterTerminus":
      case "lineBreakValue":
      case "quoteConvert":
        return He(e, s, n);
    }
  else if (e === "style")
    switch (s) {
      case "correct":
      case "atRuleSpace":
      case "classPadding":
      case "noLeadZero":
      case "sortSelectors":
      case "sortProperties":
        return Ke(n);
      case "quoteConvert":
        return He(e, s, n);
    }
  else if (e === "json")
    switch (s) {
      case "arrayFormat":
      case "objectIndent":
        return He(e, s, n);
      case "allowComments":
      case "braceAllman":
      case "bracePadding":
      case "objectSort":
        return pt(e, s, n);
    }
}
function Fi(e, s, n) {
  if (Re(n)) {
    if (n.length === 0)
      return !0;
    for (let c = 0; c < n.length; c++)
      if (mt(n[c]) === !1)
        throw Ae({
          message: `Invalid ${e} rule (${s}) type "${typeof n}" provided`,
          option: `${e} \u2192 ${s} (index: ${c})`,
          provided: n,
          expected: [
            "string"
          ]
        });
    return !0;
  }
  throw Ae({
    message: `Invalid ${e} rule (${s}) type "${typeof n}" provided`,
    option: e === "global" ? s : `${e} \u2192 ${s}`,
    provided: n,
    expected: [
      "string[]"
    ]
  });
}
function rn(e, s, n) {
  if (typeof n == "string")
    return !0;
  throw Ae({
    message: `Invalid ${e} rule (${s}) type "${typeof n}" provided`,
    option: e === "global" ? s : `${e} \u2192 ${s}`,
    provided: n,
    expected: [
      "string"
    ]
  });
}
function ni(e, s, n) {
  if (st(n) && isNaN(n) === !1)
    return !0;
  throw Ae({
    message: `Invalid ${e} rule (${s}) type "${typeof n}" provided`,
    option: e === "global" ? s : `${e} \u2192 ${s}`,
    provided: n,
    expected: [
      "number"
    ]
  });
}
function pt(e, s, n) {
  if (st(n))
    return n !== 0;
  if (Ke(n))
    return !0;
  throw Ae({
    message: `Invalid ${e} rule (${s}) type "${typeof n}" provided`,
    option: e === "global" ? s : `${e} \u2192 ${s}`,
    provided: n,
    expected: [
      "boolean"
    ]
  });
}
function He(e, s, n) {
  if (mt(n) === !1)
    throw Ae({
      message: `Invalid ${e} rule (${s}) type "${typeof n}" provided`,
      option: `${e} \u2192 ${s}`,
      provided: n,
      expected: [
        "string"
      ]
    });
  if (s === "language") {
    switch (n) {
      case "text":
      case "markup":
      case "html":
      case "liquid":
      case "xml":
      case "javascript":
      case "typescript":
      case "jsx":
      case "tsx":
      case "json":
      case "less":
      case "scss":
      case "sass":
      case "css":
        return !0;
    }
    throw Ae({
      message: `Unsupported "${s}" identifier provided`,
      option: e === `${s} (global)` ? s : `${e} \u2192 ${s}`,
      provided: n,
      expected: [
        "text",
        "auto",
        "markup",
        "html",
        "liquid",
        "xml",
        "javascript",
        "typescript",
        "jsx",
        "tsx",
        "json",
        "less",
        "scss",
        "sass",
        "css"
      ]
    });
  } else if (s === "preset") {
    switch (n) {
      case "default":
      case "strict":
      case "recommended":
      case "warrington":
      case "prettier":
        return !0;
    }
    throw Ae({
      message: `Unsupported "${s}" provided`,
      option: e === `${s} (global)` ? s : `${e} \u2192 ${s}`,
      provided: n,
      expected: [
        "default",
        "strict",
        "recommended",
        "warrington",
        "prettier"
      ]
    });
  } else if (s === "attributeCasing")
    switch (n) {
      case "preserve":
      case "lowercase":
      case "lowercase-name":
      case "lowercase-value":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "preserve",
            "lowercase",
            "lowercase-name",
            "lowercase-value"
          ]
        });
    }
  else if (s === "delimiterTrims")
    switch (n) {
      case "preserve":
      case "never":
      case "always":
      case "tags":
      case "outputs":
      case "multiline":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "preserve",
            "never",
            "always",
            "tags",
            "outputs",
            "multiline",
            "linebreak"
          ]
        });
    }
  else if (s === "delimiterPlacement")
    switch (n) {
      case "default":
      case "inline":
      case "preserve":
      case "consistent":
      case "force":
      case "force-multiline":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "default",
            "inline",
            "preserve",
            "consistent",
            "force",
            "force-multiline"
          ]
        });
    }
  else if (s === "lineBreakSeparator")
    switch (n) {
      case "preserve":
      case "before":
      case "after":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "preserve",
            "before",
            "after"
          ]
        });
    }
  else if (s === "delimiterTerminus")
    switch (n) {
      case "force":
      case "inline":
      case "adapt":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "force",
            "inline",
            "adapt"
          ]
        });
    }
  else if (s === "lineBreakValue")
    switch (n) {
      case "preserve":
      case "align":
      case "indent":
      case "force-preserve":
      case "force-align":
      case "force-indent":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "preserve",
            "align",
            "indent",
            "force-preserve",
            "force-align",
            "force-indent"
          ]
        });
    }
  else if (s === "quoteConvert")
    switch (n) {
      case "none":
      case "double":
      case "single":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "none",
            "double",
            "single"
          ]
        });
    }
  else if (s === "objectIndent" || s === "arrayFormat")
    switch (n) {
      case "default":
      case "indent":
      case "inline":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "default",
            "indent",
            "inline"
          ]
        });
    }
  else if (s === "endComma")
    switch (n) {
      case "none":
      case "always":
      case "never":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "none",
            "always",
            "never"
          ]
        });
    }
  else if (s === "variableList")
    switch (n) {
      case "none":
      case "each":
      case "list":
        return !0;
      default:
        throw Ae({
          message: `Invalid "${s}" option provided`,
          option: `${e} \u2192 ${s}`,
          provided: n,
          expected: [
            "none",
            "each",
            "list"
          ]
        });
    }
}

// src/rules/presets/recommended.ts
var Tt = Fe({
  preset: "recommended",
  language: "auto",
  preserveLine: 2,
  wrap: 120,
  wrapFraction: 90,
  liquid: {
    ignoreTagList: ["javascript"],
    indentAttribute: !0,
    commentNewline: !0,
    delimiterTrims: "tags",
    lineBreakSeparator: "after",
    quoteConvert: "double",
    delimiterPlacement: "consistent"
  },
  markup: {
    attributeCasing: "lowercase-name",
    commentNewline: !0,
    delimiterTerminus: "adapt",
    forceAttribute: 2,
    forceIndent: !0,
    ignoreCSS: !1,
    ignoreJSON: !1,
    lineBreakValue: "indent",
    selfCloseSpace: !0,
    selfCloseSVG: !0,
    quoteConvert: "double"
  },
  json: {
    arrayFormat: "indent",
    objectIndent: "indent"
  },
  style: {
    commentNewline: !0,
    commentIndent: !0,
    quoteConvert: "double",
    noLeadZero: !0,
    sortProperties: !0
  }
});

// src/rules/presets/strict.ts
var Mt = Fe({
  preset: "strict",
  language: "auto",
  preserveLine: 1,
  wrap: 0,
  wrapFraction: 80,
  liquid: {
    ignoreTagList: [],
    commentNewline: !0,
    delimiterTrims: "never",
    lineBreakSeparator: "before",
    quoteConvert: "double",
    forceArgument: 3,
    forceFilter: 4,
    delimiterPlacement: "consistent"
  },
  markup: {
    attributeSort: [
      "id",
      "class",
      "type",
      "name",
      "value",
      "href",
      "src"
    ],
    attributeCasing: "lowercase-name",
    commentNewline: !0,
    delimiterTerminus: "adapt",
    forceAttribute: 1,
    forceIndent: !0,
    ignoreCSS: !1,
    ignoreJSON: !1,
    ignoreJS: !1,
    lineBreakValue: "force-indent",
    selfCloseSpace: !0,
    selfCloseSVG: !0,
    stripAttributeLines: !0,
    quoteConvert: "double"
  },
  json: {
    arrayFormat: "indent",
    objectIndent: "indent",
    objectSort: !0
  },
  style: {
    commentNewline: !0,
    commentIndent: !0,
    quoteConvert: "double",
    noLeadZero: !0,
    sortProperties: !0,
    sortSelectors: !0
  }
});

// src/rules/presets/warrington.ts
var It = Fe({
  preset: "warrington",
  language: "auto",
  preserveLine: 2,
  wrap: 0,
  liquid: {
    ignoreTagList: ["javascript"],
    indentAttribute: !0,
    lineBreakSeparator: "after",
    quoteConvert: "double"
  },
  markup: {
    commentNewline: !0,
    delimiterTerminus: "adapt",
    forceAttribute: 1,
    forceIndent: !0,
    ignoreCSS: !0,
    ignoreJSON: !1,
    lineBreakValue: "indent",
    selfCloseSpace: !0,
    selfCloseSVG: !0,
    stripAttributeLines: !0,
    quoteConvert: "double"
  },
  json: {
    arrayFormat: "indent",
    objectIndent: "indent"
  },
  style: {
    commentIndent: !1,
    quoteConvert: "double"
  }
});

// src/rules/presets/prettier.ts
var _t = Fe({
  preset: "prettier",
  language: "auto",
  preserveLine: 1,
  wrap: 80,
  wrapFraction: 60,
  liquid: {
    ignoreTagList: ["javascript"],
    indentAttribute: !0,
    lineBreakSeparator: "after",
    dedentTagList: ["schema"],
    quoteConvert: "double"
  },
  markup: {
    commentNewline: !0,
    delimiterTerminus: "force",
    forceAttribute: 1,
    forceIndent: !0,
    ignoreJS: !0,
    ignoreCSS: !0,
    ignoreJSON: !1,
    lineBreakValue: "force-indent",
    selfCloseSpace: !0,
    selfCloseSVG: !0,
    stripAttributeLines: !0,
    quoteConvert: "double"
  },
  json: {
    arrayFormat: "indent",
    objectIndent: "indent"
  },
  style: {
    commentIndent: !1,
    quoteConvert: "double"
  }
});

// src/rules/define.ts
var St = [
  "correct",
  "crlf",
  "endNewline",
  "indentChar",
  "indentLevel",
  "indentSize",
  "preserveLine",
  "wrap",
  "wrapFraction"
], Lt = [
  "liquid",
  "markup",
  "style",
  "json",
  "script"
];
function on(e) {
  if (e.preset !== r.rules.preset && He("global", "preset", e.preset)) {
    if (r.rules = Qe({}, ct), r.rules.preset = e.preset, e.preset === "default")
      return;
    let s;
    switch (e.preset) {
      case "strict":
        s = nt(Mt);
        for (let n of St)
          s(n) && (r.rules[n] = Mt[n]);
        for (let n of Lt)
          s(n) && Qe(r.rules[n], Mt[n]);
        break;
      case "recommended":
        s = nt(Tt);
        for (let n of St)
          s(n) && (r.rules[n] = Tt[n]);
        for (let n of Lt)
          s(n) && Qe(r.rules[n], Tt[n]);
        break;
      case "warrington":
        s = nt(It);
        for (let n of St)
          s(n) && (r.rules[n] = It[n]);
        for (let n of Lt)
          s(n) && Qe(r.rules[n], It[n]);
        break;
      case "prettier":
        s = nt(_t);
        for (let n of St)
          s(n) && (r.rules[n] = _t[n]);
        for (let n of Lt)
          s(n) && Qe(r.rules[n], _t[n]);
        break;
    }
  }
}
function Hi(e, s) {
  let n = e, c = nt(n), O;
  s.rules.length > 0 && (O = {}), "preset" in n && on(n), c("language") && Wt("global", "language", n.language) && r.language !== n.language && (r.language = r.rules.language = n.language);
  for (let l of St)
    c(l) !== !1 && r.rules[l] !== n[l] && Wt("global", l, n[l]) && (O && (O[l] = { from: r.rules[l], to: n[l] }), l === "crlf" && (r.crlf = n[l] ? oi : Z), l === "wrap" && n[l] > 0 && (c("wrapFraction") === !1 || c("wrapFraction") && n.wrapFraction <= 0) && (n.wrapFraction = n[l] - n[l] / 4), r.rules[l] = n[l]);
  for (let l of Lt)
    if (c(l) !== !1 && r.rules[l] !== n[l]) {
      O && (O[l] = {});
      for (let N in n[l])
        Wt(l, N, n[l][N]) && (O && (O[l][N] = { old: r.rules[l][N], now: n[l][N] }), r.rules[l][N] = n[l][N]);
    }
  if (s.rules.length > 0)
    for (let l of s.rules)
      l(O, r.rules);
  return r.rules;
}

// src/rules/presets.ts
var si = {};
Vi(si, {
  defaults: () => ct
});

// src/esthetic.ts
var zi = new class {
  constructor() {
    this.language = "auto";
    this.lexer = "auto";
    this.stats = null;
    this.events = {
      format: [],
      error: [],
      rules: [],
      parse: []
    };
    Ne.env === "node" && (Ne.cwd = process.cwd()), Ne.env === "browser" && ("esthetic" in window || vi(window, "esthetic", {
      configurable: !0,
      get() {
        return zi;
      }
    }));
  }
  get presets() {
    return si;
  }
  get table() {
    return r.data;
  }
  get definitions() {
    return Ut;
  }
  get detect() {
    return Qi;
  }
  get error() {
    return r.error;
  }
  get lines() {
    return r.numbers;
  }
  grammar(s) {
    return s ? (ye.extend(s), this) : ye.extend();
  }
  config(s) {
    if (!s)
      return Ne;
    for (let n in s)
      n in Ne && (Ne[n] = s[n]);
    return Ne.env === "browser" && Ne.globalThis === !1 && "esthetic" in window && delete window.esthetic, this;
  }
  on(s, n) {
    return this.events[s].push(n), this;
  }
  hook(s, n) {
    r.hooks[s] = [n];
  }
  format(s, n) {
    if (r.source = s, gt(n) && "language" in n && this.language !== n.language && He("global", "language", n.language) && (this.language = r.language = r.rules.language = n.language, this.lexer = r.lexer = Pe(r.language)), this.rules(n), this.lexer === "auto") {
      let o = this.detect(r.source);
      this.language = r.language = r.rules.language = o.language, this.lexer = r.lexer = Pe(o.language);
    }
    let c = ht(this.language), O = Ne.reportStats ? Dt(this.language, this.lexer) : null, l = r.document(c);
    if (r.error !== null)
      if (this.events.error.length > 0) {
        for (let o of this.events.error)
          o(r.error);
        return s;
      } else {
        if (Ne.throwErrors)
          throw r.error;
        return s;
      }
    let N = O === null ? null : this.stats = O(l.length);
    if (this.events.format.length > 0) {
      for (let o of this.events.format)
        if (o.call({ get data() {
          return r.data;
        } }, {
          get output() {
            return s;
          },
          get stats() {
            return N;
          },
          get rules() {
            return r.rules;
          }
        }) === !1)
          return s;
    }
    return l;
  }
  parse(s, n) {
    if (r.source = s, gt(n) && "language" in n && this.language !== n.language && He("global", "language", n.language) && (this.language = r.language = r.rules.language = n.language, this.lexer = r.lexer = Pe(r.language)), this.rules(n), this.lexer === "auto") {
      let o = this.detect(r.source);
      this.language = r.language = r.rules.language = o.language, this.lexer = r.lexer = Pe(o.language);
    }
    let c = ht(this.language), O = Ne.reportStats ? Dt(this.language, this.lexer) : null, l = r.document(c, 1);
    if (r.error !== null)
      if (this.events.error.length > 0) {
        for (let o of this.events.error)
          o(r.error);
        return [];
      } else {
        if (Ne.throwErrors)
          throw r.error;
        return [];
      }
    let N = O === null ? null : this.stats = O(r.count);
    if (this.events.parse.length > 0) {
      for (let o of this.events.parse)
        if (o({
          get data() {
            return r.data;
          },
          get stats() {
            return N;
          },
          get rules() {
            return r.rules;
          }
        }) === !1)
          return s;
    }
    return l;
  }
  rules(s) {
    return De(s) ? r.rules : (r.rules = Hi(s, this.events), this.language = r.language, this.lexer = r.lexer = Pe(r.language), r.rules);
  }
  liquid(s, n) {
    return this.language = r.language = r.rules.language = "liquid", this.lexer = r.lexer = Pe(r.language), this.format(s, n);
  }
  html(s, n) {
    return this.language = r.language = r.rules.language = "html", this.lexer = r.lexer = Pe(r.language), this.format(s, n);
  }
  xml(s, n) {
    return this.language = r.language = r.rules.language = "xml", this.lexer = r.lexer = Pe(r.language), this.format(s, n);
  }
  css(s, n) {
    return this.language = r.language = r.rules.language = "css", this.lexer = r.lexer = Pe(r.language), this.format(s, n);
  }
  json(s, n) {
    return this.language = r.language = r.rules.language = "json", this.lexer = r.lexer = Pe(r.language), this.format(s, n);
  }
  js(s, n) {
    return this.language = r.language = r.rules.language = "javascript", this.lexer = r.lexer = Pe(r.language), this.format(s, n);
  }
  ts(s, n) {
    return this.language = r.language = r.rules.language = "typescript", this.lexer = r.lexer = Pe(r.language), this.format(s, n);
  }
}();

export { zi as default };
